import fs from "node:fs";
import path from "node:path";
const root = path.resolve(process.argv[2]);
const ids = JSON.parse(fs.readFileSync(path.join(root, "data/fits/need.json"), "utf8"));
const cache = path.join(root, "data/fits/cache");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let ok = 0, fail = 0;
for (let i = 0; i < ids.length; i++) {
  const f = path.join(cache, `e${ids[i]}.json`);
  if (fs.existsSync(f)) { ok++; continue; }
  for (let t = 0; t < 4; t++) {
    try {
      const r = await fetch(`https://api.eveworkbench.com/v1/fits/${ids[i]}/eft`);
      if (r.status === 429) { await sleep(5000 * (t + 1)); continue; }
      if (!r.ok) throw new Error(String(r.status));
      fs.writeFileSync(f, JSON.stringify(await r.json()));
      ok++;
      break;
    } catch (e) {
      if (t === 3) fail++;
      await sleep(1500 * (t + 1));
    }
  }
  await sleep(300);
  if ((i + 1) % 25 === 0 || i === ids.length - 1) console.log(`${i + 1}/${ids.length} ok=${ok} fail=${fail}`);
}
