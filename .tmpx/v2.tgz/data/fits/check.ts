import fs from 'node:fs';
import { Sde, Category } from '../../src/data/sde';
import { parseEft } from '../../src/io/eft';
import { buildDogma } from '../../src/engine/fit';
import { resources, validate } from '../../src/engine/stats';

const pd = process.argv[2];
const raw = JSON.parse(fs.readFileSync(pd + '/' + fs.readdirSync(pd).find((f) => /^sde\..*\.json$/.test(f))!, 'utf8'));
const sde = new Sde(raw);
const skills = new Map(sde.typesInCategory(Category.Skill).map((t) => [t.id, 5]));
const blocks = JSON.parse(fs.readFileSync(process.argv[3], 'utf8')) as { key: string; eft: string }[];
const out: Record<string, { errs: string[]; cpu: string; pg: string; unknown: string[] }> = {};
for (const b of blocks) {
  try {
    const { fit, unknown } = parseEft(sde, b.eft);
    const d = buildDogma(sde, fit, { name: 'all5', skills });
    const r = resources(sde, fit, d);
    out[b.key] = { errs: validate(sde, fit, d, r), cpu: `${Math.round(r.cpu.used)}/${Math.round(r.cpu.total)}`, pg: `${Math.round(r.power.used)}/${Math.round(r.power.total)}`, unknown };
  } catch (e) {
    out[b.key] = { errs: [String(e)], cpu: '', pg: '', unknown: [] };
  }
}
console.log(JSON.stringify(out));
