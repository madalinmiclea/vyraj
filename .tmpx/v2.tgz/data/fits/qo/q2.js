import fs from "node:fs";
// src/ui/fold.ts
function fold(s) {
	return s.toLowerCase().replace(/[‘’‚‛′`´]/g, "'").replace(/[“”„‟″]/g, "\"");
}
// src/storage.ts
function loadJson(key, fallback) {
	try {
		const raw = localStorage.getItem(key);
		return raw ? JSON.parse(raw) : fallback;
	} catch {
		return fallback;
	}
}
// src/i18n/en.ts
const EN = {
	"Meniu": "Menu",
	"Nu pot încărca prețurile nici de la Fuzzwork, nici de la ESI.": "Could not load prices from Fuzzwork or from ESI.",
	"Spațiul de stocare al browserului e plin, ultima modificare nu s-a salvat. Șterge fit-uri vechi sau datele site-ului.": "Browser storage is full, the last change was not saved. Delete old fits or the site data.",
	"Sesiunea EVE a acestui caracter a expirat sau a fost revocată. Fă din nou login.": "This character's EVE session expired or was revoked. Log in again.",
	"+ Arată încă {n} din {rest}": "+ Show {n} more of {rest}",
	"Arată tot browserul": "Show the full browser",
	"Fă login cu EVE ca să-ți imporți skill-urile, implanturile și coada de antrenament. Până atunci, statisticile folosesc un caracter teoretic cu toate skill-urile la V.": "Log in with EVE to import your skills, implants and training queue. Until then, stats use a theoretical character with every skill at V.",
	"Vizitate recent": "Recently viewed",
	"Populare": "Popular",
	"/zi": "/day",
	"1 an": "1 year",
	"30 zile": "30 days",
	"<span class=\"num\">{time}</span> de antrenament · <span class=\"num\">{sp}</span> SP": "<span class=\"num\">{time}</span> of training · <span class=\"num\">{sp}</span> SP",
	"Activ": "Active",
	"Activă": "Active",
	"Actualizează": "Refresh",
	"Acum": "Now",
	"acum {n} h": "{n} h ago",
	"acum {n} min": "{n} min ago",
	"acum {n} zile": "{n} days ago",
	"Adaugă": "Add",
	"Adaugă nivelul următor în skill plan": "Add the next level to the skill plan",
	"Adaugă în skill plan": "Add to skill plan",
	"Adâncime": "Depth",
	"Adăugat în skill plan": "Added to skill plan",
	"Ai toate SKIN-urile din filtrul curent.": "You own every SKIN in the current filter.",
	"Ai tot ce trebuie": "You have everything you need",
	"ai {lvl}": "you have {lvl}",
	"Alege o navă": "Pick a ship",
	"Alege un item": "Pick an item",
	"Alege un item din browserul de iteme sau caută-l mai sus. Prețurile vin live din ordinele din Jita 4-4.": "Pick an item from the item browser or search for it above. Prices come live from the Jita 4-4 orders.",
	"Alege întâi o navă": "Pick a ship first",
	"Alerte preț": "Price alerts",
	"Alertă preț": "Price alert",
	"Alertă preț Jita": "Jita price alert",
	"Alertă salvată": "Alert saved",
	"Ambele": "Both",
	"Antrenament lipsă": "Missing training",
	"Apasă <b>Create new application</b>. Nume: ce vrei (ex: Vyraj). Descriere: „uz personal”.": "Press <b>Create new application</b>. Name: anything you like (e.g. Vyraj). Description: \"personal use\".",
	"Apasă pe o dronă din browser ca s-o adaugi.": "Click a drone in the browser to add it.",
	"Apasă „Salvează” pe un fit ca să apară aici.": "Press \"Save\" on a fit for it to show up here.",
	"Aplicația EVE (o singură dată)": "EVE application (one time only)",
	"Arme": "Weapons",
	"Armă": "Weapon",
	"Asigurare": "Insurance",
	"Asistență la distanță": "Remote assistance",
	"Atribut necunoscut: {name}": "Unknown attribute: {name}",
	"Atribute": "Attributes",
	"Bază": "Base",
	"Bonus misiuni": "Mission bonus",
	"bonus {name}": "{name} bonus",
	"Bonusuri": "Bonuses",
	"Browser iteme": "Item browser",
	"Buc / zi": "Units / day",
	"Buy → sell în Jita": "Buy → sell in Jita",
	"Calculez fiecare skill pe fit…": "Calculating every skill on the fit…",
	"Calculez valorile…": "Calculating values…",
	"Callback URL copiat": "Callback URL copied",
	"Cant.": "Qty",
	"Cap stabil la": "Cap stable at",
	"Capacitate": "Capacity",
	"Capacitor stabil la": "Capacitor stable at",
	"Capital / zi": "Capital / day",
	"Caracter": "Character",
	"caracter": "character",
	"Caracter actualizat": "Character updated",
	"caracter personalizat: poți schimba nivelurile": "custom character: you can change the levels",
	"caracter teoretic": "theoretical character",
	"Caracter: {name} · profil {profile}. Cea mai bună valoare e evidențiată.": "Character: {name} · profile {profile}. The best value is highlighted.",
	"Caractere": "Characters",
	"Caracterul nu e logat. Apasă „Login cu EVE”.": "The character is not logged in. Press \"Login with EVE\".",
	"Categorie": "Category",
	"Caută": "Search",
	"Caută mai sus un item ca să vezi ce skill-uri îți trebuie și cât durează.": "Search above for an item to see which skills you need and how long they take.",
	"Caută SKIN sau navă": "Search SKIN or ship",
	"Caută...": "Search...",
	"Ce am": "Trained",
	"Improvement skills": "Improvement skills",
	"Cel mai bun roll": "Best roll",
	"Cel mai ieftin": "Cheapest",
	"Cel mai mare buy": "Highest buy",
	"Cel mai mare rulaj": "Highest turnover",
	"Cel mai mic sell": "Lowest sell",
	"Cel mai scump": "Most expensive",
	"Cel mai slab roll": "Worst roll",
	"Cele mai ieftine": "Cheapest",
	"Cele mai scumpe": "Most expensive",
	"Cele mai tranzacționate": "Most traded",
	"Cele mai valoroase": "Most valuable",
	"cere": "requires",
	"Cerere": "Demand",
	"Cerere pe 7 zile față de 30 de zile.": "7 day demand vs 30 days.",
	"Cerințe directe": "Direct requirements",
	"Citesc asset-urile și prețurile": "Reading assets and prices",
	"Citesc prețurile din Jita": "Reading Jita prices",
	"Citesc wallet journal": "Reading the wallet journal",
	"Clasă": "Class",
	"click: schimbă starea": "click: change state",
	"Client ID salvat": "Client ID saved",
	"Copie creată: îi poți schimba nivelurile skill-urilor mai jos": "Copy created: you can change its skill levels below",
	"Adaugă caracter": "Add character",
	"Coada de skill-uri": "Skill queue",
	"Colecție": "Collection",
	"Colecție SKIN-uri": "SKIN collection",
	"Colecții complete": "Collections complete",
	"Colecții începute": "Collections started",
	"Compară": "Compare",
	"Compară fit-uri": "Compare fits",
	"Complete": "Complete",
	"Condiție": "Condition",
	"configurată": "configured",
	"Consum cap": "Cap usage",
	"Consum net": "Net usage",
	"Contracte": "Contracts",
	"Copiat în clipboard": "Copied to clipboard",
	"Copiază": "Copy",
	"Copiază din inventar, contract, EFT sau listă": "Copy from inventory, contract, EFT or a list",
	"Copiază DNA": "Copy DNA",
	"Copiază EFT": "Copy EFT",
	"Copiază Multibuy": "Copy Multibuy",
	"Copiază pentru EVE": "Copy for EVE",
	"Copiază planul": "Copy plan",
	"Copiază sell": "Copy sell",
	"Copiază total": "Copy total",
	"Copie editabilă": "Editable copy",
	"Corporație": "Corporation",
	"Cost Jita (sell min)": "Jita cost (sell min)",
	"Cost total": "Total cost",
	"Cota ta din volum %": "Your share of volume %",
	"CPU liber": "Free CPU",
	"Cresc": "Rising",
	"Cu LP-ul tău": "With your LP",
	"Cumperi cu buy order, vinzi cu sell order, după taxe, la {n}% din volumul zilnic.": "Buy with a buy order, sell with a sell order, after fees, at {n}% of the daily volume.",
	"Cumpăr instant din sell orders → vând instant în buy orders la destinație, după sales tax {t}%. Fără ordine de așteptat.": "Instant buy from sell orders → instant sell into buy orders at the destination, after {t}% sales tax. No waiting on orders.",
	"Cumpăr instant → vând instant, după sales tax {tax}%": "Instant buy → instant sell, after {tax}% sales tax",
	"Cumpăr la": "Buy at",
	"Cumpăr la buy max + broker {b}% → vând la sell min − broker {b}% − tax {t}%. Marja e raportată la costul de cumpărare.": "Buy at buy max + {b}% broker → sell at sell min − {b}% broker − {t}% tax. Margin is relative to the purchase cost.",
	"Câte o colecție pe rând: <code>Colecție: Navă, Navă, Navă</code>": "One collection per line: <code>Collection: Ship, Ship, Ship</code>",
	"Câștig cel mai mare": "Biggest gain",
	"Câștig la nivelul următor": "Gain at the next level",
	"Câștig pe zi de antrenament": "Gain per training day",
	"Da": "Yes",
	"Data": "Date",
	"Datele de fitting încă se încarcă": "Fitting data is still loading",
	"De cumpărat": "To buy",
	"Colecția mea": "My collection",
	"SKIN-uri nave": "Ship SKINs",
	"De cumpărat din Jita": "To buy in Jita",
	"Defensivă": "Defense",
	"Deschide": "Open",
	"Deschide tot": "Expand all",
	"Deschide „Ships” în browserul de iteme și apasă pe o navă. Apoi apasă pe module, muniție sau drone ca să le montezi. Poți și importa un fit EFT din joc sau din Pyfa.": "Open \"Ships\" in the item browser and click a ship. Then click modules, ammo or drones to fit them. You can also import an EFT fit from the game or from Pyfa.",
	"devine stabil": "becomes stable",
	"Din brut": "Of raw",
	"Direcție": "Direction",
	"Disponibil": "Available",
	"Distanță": "Distance",
	"Diverse": "Miscellaneous",
	"DNA copiat": "DNA copied",
	"Donații": "Donations",
	"DPS aplicat": "Applied DPS",
	"Drone": "Drones",
	"Durată": "Duration",
	"Durată (min)": "Duration (min)",
	"Durată capacitor": "Capacitor duration",
	"Efecte secundare": "Side effects",
	"EFT copiat": "EFT copied",
	"EFT se lipește în joc din Fitting → Import from clipboard și în Pyfa.": "EFT pastes into the game via Fitting → Import from clipboard and into Pyfa.",
	"ESI · delogat": "ESI · logged out",
	"Evaluare": "Appraisal",
	"Evaluează": "Appraise",
	"EWAR · Neutralizare": "EWAR · Neutralizing",
	"Exportat din Vyraj": "Exported from Vyraj",
	"Exportă": "Export",
	"Exportă fit": "Export fit",
	"Facțiune": "Faction",
	"Filtrează atribute...": "Filter attributes...",
	"Filtrează · click dreapta = Info": "Filter · right click = Info",
	"Fit importat": "Fit imported",
	"Fit importat din EVE": "Fit imported from EVE",
	"Fit nou": "New fit",
	"Fit salvat": "Fit saved",
	"Fit trimis în EVE": "Fit sent to EVE",
	"Fit încărcat de pe {name}": "Fit loaded from {name}",
	"Fit-uri": "Fits",
	"Fit-uri EVE": "EVE fits",
	"Fit-uri salvate": "Saved fits",
	"Fit-urile salvate în joc": "Fits saved in game",
	"Folosește": "Use",
	"Folosit": "Used",
	"Fără bounty sau misiuni în jurnal.": "No bounties or missions in the journal.",
	"fără charge": "no charge",
	"Fără istoric pentru itemul ăsta.": "No history for this item.",
	"fără mutație": "no mutation",
	"Fără ordere în Jita": "No orders in Jita",
	"fără ordine": "no orders",
	"fără ordine pe una din părți": "no orders on one of the sides",
	"Fără ordine în Jita": "No orders in Jita",
	"fără ordine în Jita acum": "no Jita orders right now",
	"Gata pe": "Done on",
	"Golește": "Clear",
	"Grid liber": "Free grid",
	"grup": "group",
	"Grup {v}": "Group {v}",
	"Hangare și bay-uri": "Hangars and bays",
	"Idei": "Ideas",
	"Ieftine": "Cheap",
	"Ieșit": "Out",
	"Implanturi, boostere și cargo": "Implants, boosters and cargo",
	"Importat; {n} linii necunoscute": "Imported; {n} unknown lines",
	"Importă": "Import",
	"Importă fit (EFT)": "Import fit (EFT)",
	"Importă listă": "Import list",
	"Importă listă SKIN-uri": "Import SKIN list",
	"Industrie": "Industry",
	"Info item": "Item info",
	"Info muniție": "Ammo info",
	"Intel Jita": "Jita Intel",
	"Interogăm piața din Jita 4-4": "Querying the Jita 4-4 market",
	"Intrat": "In",
	"Intră pe <a href=\"https://developers.eveonline.com/applications\" target=\"_blank\" rel=\"noopener\">developers.eveonline.com/applications</a> și loghează-te cu contul EVE.": "Go to <a href=\"https://developers.eveonline.com/applications\" target=\"_blank\" rel=\"noopener\">developers.eveonline.com/applications</a> and log in with your EVE account.",
	"ISK / zi": "ISK / day",
	"ISK tranzacționat / zi": "ISK traded / day",
	"ISK tranzacționat zilnic, media pe 30 de zile.": "ISK traded daily, 30 day average.",
	"ISK/oră": "ISK/hour",
	"ISK/oră PvE": "PvE ISK/hour",
	"Istoric preț {name}": "{name} price history",
	"Istoric tranzacții": "Trade history",
	"Item": "Item",
	"Item necunoscut": "Unknown item",
	"Item necunoscut în datele de fitting: {id}": "Unknown item in the fitting data: {id}",
	"Iteme": "Items",
	"Iteme analizate": "Items analysed",
	"Iteme cerute": "Required items",
	"Iteme listate în Jita": "Items listed in Jita",
	"Itemul deschis": "Current item",
	"Itemul există în joc, dar nu are niciun ordin activ în Jita (des întâlnit la module de officer și iteme rare). Verifică din nou mai târziu; prețurile se reîmprospătează la fiecare căutare.": "The item exists in game but has no active orders in Jita (common for officer modules and rare items). Check again later; prices refresh on every search.",
	"Itemul nu are atribute afișabile.": "This item has no displayable attributes.",
	"Itemul nu se poate fita.": "This item cannot be fitted.",
	"Jos": "Down",
	"Jurnal Abyssal": "Abyssal log",
	"La <b>Callback URL</b> pune exact:": "Under <b>Callback URL</b> enter exactly:",
	"La <b>Connection type</b> alege <b>Authentication &amp; API Access</b> și bifează scope-urile de mai jos.": "Under <b>Connection type</b> pick <b>Authentication &amp; API Access</b> and tick the scopes below.",
	"Limbă": "Language",
	"limita navei": "ship limit",
	"Lipește iteme": "Paste items",
	"Lipește un fit copiat din joc (Fitting → Copy to clipboard) sau din Pyfa.": "Paste a fit copied from the game (Fitting → Copy to clipboard) or from Pyfa.",
	"Lipsesc <span class=\"unit\">{n}</span> · {time}": "<span class=\"unit\">{n}</span> missing · {time}",
	"Lipsesc {n} skill-uri": "{n} skills missing",
	"Lipsește Client ID-ul aplicației EVE. Îl pui în secțiunea Setări login.": "The EVE application Client ID is missing. Add it in the Login settings section.",
	"Lista Multibuy copiată": "Multibuy list copied",
	"Locație {id}": "Location {id}",
	"Locații": "Locations",
	"Login-ul acestui caracter nu are toate permisiunile. Fă din nou login din ecranul Caracter.": "This character's login does not have all permissions. Log in again from the Character screen.",
	"Login cu EVE": "Login with EVE",
	"Login EVE eșuat ({status}): {text}": "EVE login failed ({status}): {text}",
	"Login EVE: răspuns invalid (state diferit). Încearcă din nou.": "EVE login: invalid response (state mismatch). Try again.",
	"Loot (lipește din inventar)": "Loot (paste from inventory)",
	"LP-ul meu": "My LP",
	"Marjă": "Margin",
	"Marjă buy → sell (cumpăr la buy, vând la sell)": "Buy → sell margin (buy at buy, sell at sell)",
	"Marjă min %": "Min margin %",
	"Mastery {lvl} completă": "Mastery {lvl} complete",
	"Mastery {lvl}: lipsesc <span class=\"unit\">{n}</span> skill-uri · {time}": "Mastery {lvl}: <span class=\"unit\">{n}</span> skills missing · {time}",
	"Masă": "Mass",
	"Maxim {max} × {group} activ": "Max {max} × {group} active",
	"Maxim {max} × {group} pe navă": "Max {max} × {group} per ship",
	"Media pe 7 zile față de 30 de zile, cu volum constant.": "7 day average vs 30 days, with steady volume.",
	"Medie": "Average",
	"Medie 30 zile": "30 day average",
	"Medie 30z": "30d average",
	"Medie 7z": "7d average",
	"Misiuni": "Missions",
	"Modul activ": "Active module",
	"module": "modules",
	"Multibuy copiat": "Multibuy copied",
	"Nava activă": "Active ship",
	"Nava „{name}” nu există în date.": "Ship \"{name}\" does not exist in the data.",
	"Navele asamblate din hangare, cu ce au montat": "Assembled ships in your hangars, with what they have fitted",
	"Navele mele": "My ships",
	"Navigație și țintire": "Navigation and targeting",
	"Navă": "Ship",
	"navă": "ship",
	"Navă pierdută (ISK)": "Ship lost (ISK)",
	"Navă, modul, dronă, implant...": "Ship, module, drone, implant...",
	"Nerecunoscute": "Unrecognised",
	"Nesincronizat": "Not synced",
	"Neîncepute": "Not started",
	"Nicio alertă": "No alerts",
	"Nicio armă activă.": "No active weapons.",
	"Nicio navă asamblată": "No assembled ships",
	"Nicio rută profitabilă peste prag.": "No profitable route above the threshold.",
	"Nicio scanare încă": "No scan yet",
	"Niciun caracter importat": "No character imported",
	"Niciun fit salvat": "No saved fits",
	"Niciun item nu conține „{q}”.": "No item contains \"{q}\".",
	"Niciun item recunoscut.": "No item recognised.",
	"Niciun modul din fit nu acceptă {name}.": "No module in the fit accepts {name}.",
	"Niciun run salvat.": "No runs saved.",
	"Niciun skill nu mai îmbunătățește DPS-ul pe fit-ul ăsta.": "No skill improves DPS on this fit any further.",
	"Niciun skill nu mai îmbunătățește nimic aici pe fit-ul ăsta.": "No skill improves anything here on this fit any further.",
	"Niciun skill nu mai îmbunătățește tank-ul pe fit-ul ăsta.": "No skill improves the tank on this fit any further.",
	"Niciun skill.": "No skills.",
	"Niciun SKIN nu se potrivește filtrului.": "No SKIN matches the filter.",
	"Niciuna": "None",
	"Nimeni nu vinde sau cumpără acum": "Nobody is buying or selling right now",
	"Nimic de afișat": "Nothing to show",
	"Nimic de cumpărat": "Nothing to buy",
	"Nimic găsit (aici sunt doar itemele de fitting și skill-urile).": "Nothing found (only fitting items and skills are listed here).",
	"Nimic peste praguri.": "Nothing above the thresholds.",
	"Nivel": "Level",
	"Nivel {v}": "Level {v}",
	"Nr. nave": "Ship count",
	"Nu": "No",
	"nu": "no",
	"Nu ai fit-uri salvate în joc.": "You have no fits saved in game.",
	"Nu ai niciun fit": "You have no fit",
	"Nu ai niciun fit de salvat": "You have no fit to save",
	"Nu ajunge calibrarea: ar fi {used} / {total}": "Not enough calibration: would be {used} / {total}",
	"Nu ajunge CPU: ar fi {used} / {total} tf": "Not enough CPU: would be {used} / {total} tf",
	"Nu ajunge drone bandwidth: ar fi {used} / {total} Mbit/s": "Not enough drone bandwidth: would be {used} / {total} Mbit/s",
	"Nu ajunge powergrid: ar fi {used} / {total} MW": "Not enough powergrid: would be {used} / {total} MW",
	"Nu am găsit corporația": "Corporation not found",
	"Nu am găsit itemul „{name}”.": "Item \"{name}\" not found.",
	"Nu am găsit nave asamblate în asset-urile tale.": "No assembled ships found in your assets.",
	"Nu am putut contacta serverul de prețuri (Fuzzwork). Verifică conexiunea și încearcă din nou.": "Could not reach the price server (Fuzzwork). Check your connection and try again.",
	"Nu am putut copia (clipboard blocat)": "Could not copy (clipboard blocked)",
	"Nu am putut încărca prețurile din Jita (Fuzzwork).": "Could not load Jita prices (Fuzzwork).",
	"Nu am recunoscut:": "Not recognised:",
	"Nu cere niciun skill.": "Requires no skills.",
	"Nu găsesc antetul EFT, de forma [Navă, Nume fit].": "EFT header not found, expected [Ship, Fit name].",
	"Nu găsesc {url}. Rulează \"npm run data\" ca să generezi datele.": "Cannot find {url}. Run \"npm run data\" to generate the data.",
	"Nu mai ai launcher hardpoints libere ({n})": "No free launcher hardpoints left ({n})",
	"Nu mai ai turret hardpoints libere ({n})": "No free turret hardpoints left ({n})",
	"Nu mai e loc în drone bay: ar fi {used} / {total} m³": "No room left in the drone bay: would be {used} / {total} m³",
	"Nu mai sunt sloturi {k} libere": "No free {k} slots left",
	"Nu mai sunt sloturi {k} libere.": "No free {k} slots left.",
	"Nume": "Name",
	"Nume copiat, caută-l în market": "Name copied, search for it in the market",
	"Numele fit-ului": "Fit name",
	"Ofensivă": "Offense",
	"Oferte {name}": "{name} offers",
	"Oportunități station trading": "Station trading opportunities",
	"Ordine": "Orders",
	"Ordine de antrenament": "Training order",
	"Ordine Jita": "Jita orders",
	"Ore active": "Active hours",
	"p.p.": "pp",
	"Pasiv shield": "Passive shield",
	"pauză": "paused",
	"Pe categorie": "By category",
	"Pe locație": "By location",
	"Pe navă": "By ship",
	"Pe piață": "On market",
	"Pe tier și vreme": "By tier and weather",
	"Pentru itemul ăsta nu am date (Show Info merge la nave, module, muniție, drone, implanturi și skill-uri)": "No data for this item (Show Info works for ships, modules, ammo, drones, implants and skills)",
	"Personalizat": "Custom",
	"peste sau egal cu": "at or above",
	"Piața globală PLEX": "Global PLEX market",
	"Piața Jita nescanată": "Jita market not scanned",
	"Piață": "Market",
	"Pierderi": "Losses",
	"Plan copiat (lipește-l în Skill Plans din joc)": "Plan copied (paste it into Skill Plans in game)",
	"Plan de antrenament ({sp} SP)": "Training plan ({sp} SP)",
	"Planul e gol. Adaugă skill-uri din lista de requirements, din grupurile de skill-uri sau din „Improvement skills” din Fitting.": "The plan is empty. Add skills from the requirements list, from the skill groups or from \"Improvement skills\" in Fitting.",
	"Poți lansa maxim {n} drone (skill-ul Drones)": "You can launch at most {n} drones (Drones skill)",
	"Poți monta maxim {n} × {group} pe navă.": "You can fit at most {n} × {group} per ship.",
	"Poți zbura fit-ul": "You can fly this fit",
	"Prea multe drone lansate: {n} / {max} (skill-ul Drones)": "Too many drones launched: {n} / {max} (Drones skill)",
	"Presiune de cumpărare": "Buy pressure",
	"Preț": "Price",
	"Preț 7z": "Price 7d",
	"Preț copiat în clipboard": "Price copied to clipboard",
	"Preț Jita": "Jita price",
	"Preț max (m ISK)": "Max price (m ISK)",
	"Preț median (sell)": "Median price (sell)",
	"Preț în creștere": "Rising price",
	"Prețuri {name}": "{name} prices",
	"Profil de damage (inamicul)": "Damage profile (the enemy)",
	"Profit / buc": "Profit / unit",
	"Profit / cursă": "Profit / trip",
	"Profit / zi": "Profit / day",
	"Profit mediu": "Average profit",
	"Profit total": "Total profit",
	"Progres": "Progress",
	"Pune un preț": "Enter a price",
	"Pune întâi Client ID-ul": "Enter the Client ID first",
	"Rachete": "Missiles",
	"Rasă": "Race",
	"Rază": "Range",
	"Rază arme": "Weapon range",
	"Rază țintire": "Targeting range",
	"Reparare / regen": "Repair / regen",
	"Reprocesare": "Reprocessing",
	"Requirements pentru orice item": "Requirements for any item",
	"Rescanează": "Rescan",
	"Resurse": "Resources",
	"Rezistență la EWAR": "EWAR resistance",
	"Rezultate": "Results",
	"Reîncarcă": "Reload",
	"Reîncărcare": "Recharge",
	"Reîncărcare cap": "Cap recharge",
	"Run nou": "New run",
	"Run salvat · profit {isk} ISK": "Run saved · profit {isk} ISK",
	"Run-uri": "Runs",
	"Rută": "Route",
	"Rămas": "Left",
	"Salvează": "Save",
	"Salvează alerta": "Save alert",
	"Salvează câteva fit-uri ca să le compari": "Save a few fits to compare them",
	"Salvează run-ul": "Save run",
	"Salvează, copiază <b>Client ID</b> și lipește-l aici. Nu ai nevoie de Secret Key (folosim PKCE).": "Save, copy the <b>Client ID</b> and paste it here. You do not need the Secret Key (PKCE is used).",
	"Scad": "Falling",
	"Scanarea citește ordinele din The Forge și istoricul pe 30 de zile pentru cele mai active iteme.": "The scan reads The Forge orders and the 30 day history for the most active items.",
	"Scanarea nu a întors date": "The scan returned no data",
	"Scanează Jita": "Scan Jita",
	"Scanăm piața Jita": "Scanning the Jita market",
	"Schimbare": "Change",
	"Scoate": "Remove",
	"Scumpe": "Expensive",
	"Se actualizează din EVE…": "Refreshing from EVE…",
	"Se termină în {time}": "Finishes in {time}",
	"Se încarcă asset-urile din joc…": "Loading in-game assets…",
	"Se încarcă fit-urile din joc…": "Loading in-game fits…",
	"Se încarcă prețurile…": "Loading prices…",
	"Selectează o țintă": "Select a target",
	"Selectează un caracter importat din EVE (ecranul Caracter).": "Select a character imported from EVE (Character screen).",
	"Semnătură": "Signature",
	"Semnătură cu painter": "Signature with painter",
	"Semnătură țintă": "Target signature",
	"Eficiență la distanță": "Efficiency at range",
	"modul": "module",
	"țintă": "target",
	"Sesiuni PvE": "PvE sessions",
	"Sincronizat {time}": "Synced {time}",
	"Sincronizez...": "Syncing...",
	"Se sincronizează automat din ESI la fiecare 10 minute. Click pentru sincronizare acum.": "Syncs automatically from ESI every 10 minutes. Click to sync now.",
	"Skill-uri": "Skills",
	"Skillbook-uri": "Skillbooks",
	"Skillbook-uri de cumpărat": "Skillbooks to buy",
	"SKIN-uri": "SKINs",
	"SKIN-uri deținute": "SKINs owned",
	"1 slot liber": "1 free slot",
	"{n} sloturi libere": "{n} free slots",
	"Mai mult": "More",
	"Rute recente": "Recent routes",
	"Alerte de preț": "Price alerts",
	"acum {p}": "now {p}",
	"Sloturi": "Slots",
	"Sloturi {k}": "{k} slots",
	"Sold": "Balance",
	"Statisticile sunt calculate cu All 5. Importă caracterul tău din ecranul Caracter.": "Stats are calculated with All 5. Import your character from the Character screen.",
	"Structură de jucător": "Player structure",
	"Structură staționară": "Stationary structure",
	"Structură {id}": "Structure {id}",
	"Strânge tot": "Collapse all",
	"sub sau egal cu": "at or below",
	"Subsisteme": "Subsystems",
	"Supraîncălzit": "Overheated",
	"Sus": "Up",
	"Tank activ": "Active tank",
	"Taxe buy → sell": "Buy → sell fees",
	"Taxe din skill-uri": "Fees from skills",
	"Taxă tranzacții": "Transaction tax",
	"Timp": "Time",
	"Tip": "Type",
	"Toate": "All",
	"total": "total",
	"Total copiat": "Total copied",
	"Total cumulat": "Running total",
	"Trade direct": "Direct trade",
	"Transport": "Hauling",
	"Transport între hub-uri": "Hauling between hubs",
	"Trimite fit-ul curent în EVE": "Send the current fit to EVE",
	"Unelte ISK": "ISK Tools",
	"Unitar": "Unit",
	"Valoare": "Value",
	"Valoare assets": "Asset value",
	"Valoarea din buy orders față de sell orders în carte.": "Value in buy orders vs sell orders in the book.",
	"Valori de bază": "Base values",
	"Venit PvE": "PvE income",
	"Venit PvE pe zi (30 zile)": "PvE income per day (30 days)",
	"Verificat": "Checked",
	"Verifică acum": "Check now",
	"Viteză": "Speed",
	"Viteză și navigație": "Speed and navigation",
	"Volum": "Volume",
	"Volum 7z": "Volume 7d",
	"Volum <span class=\"num\">{v}</span> · <span class=\"num\">{n}</span> ordine": "Volume <span class=\"num\">{v}</span> · <span class=\"num\">{n}</span> orders",
	"Volum buy / ordine": "Buy volume / orders",
	"Volum min / zi": "Min volume / day",
	"Volum pe zi": "Volume per day",
	"Volum sell / ordine": "Sell volume / orders",
	"Volum în creștere": "Rising volume",
	"Vreme": "Weather",
	"Vând la": "Sell at",
	"Vârf reîncărcare": "Peak recharge",
	"z": "d",
	"{n} în total": "{n} total",
	"În bay": "In bay",
	"Escadrile lansate din fighter bay, cele care contează la DPS": "Squadrons launched from the fighter bay, the ones that count for DPS",
	"Drone lansate în spațiu, cele care contează la DPS și bandwidth": "Drones launched in space, the ones that count for DPS and bandwidth",
	"Escadrile de rezervă, rămase în fighter bay": "Spare squadrons, kept in the fighter bay",
	"Drone de rezervă, rămase în drone bay": "Spare drones, kept in the drone bay",
	"{a} vs {b} buc/zi": "{a} vs {b} units/day",
	"{label} depășit: {used} / {total}": "{label} exceeded: {used} / {total}",
	"{name} adăugat la boostere": "{name} added to boosters",
	"{name} adăugat la implanturi": "{name} added to implants",
	"{name} adăugată în drone bay": "{name} added to the drone bay",
	"{name} adăugată în drone bay (nelansată: {why})": "{name} added to the drone bay (not launched: {why})",
	"{name} față de Jita": "{name} vs Jita",
	"{name} importat": "{name} imported",
	"{name} nu are mărimea potrivită pentru nava asta.": "{name} is not the right size for this ship.",
	"{name} nu e pentru nava asta.": "{name} is not for this ship.",
	"{name} nu se poate fita pe navă.": "{name} cannot be fitted to the ship.",
	"{name} poate folosi itemul": "{name} can use this item",
	"{name} {lvl} în skill plan": "{name} {lvl} added to skill plan",
	"{name} încărcat în {n} module": "{name} loaded into {n} modules",
	"{name}: lipsesc <span class=\"unit\">{n}</span> skill-uri · {time}": "{name}: <span class=\"unit\">{n}</span> skills missing · {time}",
	"{n} / {total} skill-uri": "{n} / {total} skills",
	"{n} active": "{n} active",
	"{n} buc/zi": "{n} units/day",
	"{n} intrări din {date}": "{n} entries since {date}",
	"{n} iteme": "{n} items",
	"{n} iteme listate · {m} analizate pe 30 zile": "{n} items listed · {m} analysed over 30 days",
	"{n} iteme nu au ordine de vânzare în Jita.": "{n} items have no sell orders in Jita.",
	"{n} module": "{n} modules",
	"{n} nave noi adăugate în colecții": "{n} new ships added to collections",
	"{n} niveluri": "{n} levels",
	"{n} oferte cu preț": "{n} priced offers",
	"{n} piese": "{n} pieces",
	"{n} piesă": "{n} piece",
	"{n} probleme": "{n} problems",
	"{n} run-uri": "{n} runs",
	"{n} rute": "{n} routes",
	"{n} skill-uri": "{n} skills",
	"{n} skill-uri · {v} la V": "{n} skills · {v} at V",
	"{n} SKIN-uri adăugate, {m} erau deja bifate": "{n} SKINs added, {m} were already ticked",
	"{n} SKIN-uri noi în colecție": "{n} new SKINs in the collection",
	"{n} tipuri · {q} bucăți": "{n} types · {q} units",
	"{n} zile": "{n} days",
	"{sp} SP nealocat": "{sp} unallocated SP",
	"În coadă până la {lvl}": "Queued up to {lvl}",
	"Încarc istoricul": "Loading history",
	"Începute": "Started",
	"Închide": "Close",
	"Încărcăm datele de fitting (SDE)": "Loading fitting data (SDE)",
	"Încărcăm SKIN-urile": "Loading SKINs",
	"Șterge": "Delete",
	"Ștergi fit-ul?": "Delete the fit?",
	"Ținte": "Targets",
	"Țintă": "Target",
	"„{name}” nu e în datele de fitting": "\"{name}\" is not in the fitting data",
	"„{name}” nu se poate folosi în fitting": "\"{name}\" cannot be used in fitting",
	"Temă": "Theme",
	"Activi / periculoși": "Active / dangerous",
	"Activitate": "Activity",
	"Alianță atacator": "Attacker alliance",
	"Alte obiecte": "Other objects",
	"Amenințare": "Threat",
	"Analizează": "Analyse",
	"Ascunde": "Hide",
	"Atacatori": "Attackers",
	"Atenție la: {list}": "Watch out in: {list}",
	"Calculez ruta": "Calculating the route",
	"Capitale pe scan: {list}": "Capitals on scan: {list}",
	"Capsule / h": "Pods / h",
	"Capsule": "Pods",
	"Caut {n} piloți": "Looking up {n} pilots",
	"Cea mai scurtă": "Shortest",
	"Cea mai sigură": "Safest",
	"Clase de nave": "Ship classes",
	"Corporație / alianță": "Corporation / alliance",
	"Când": "When",
	"Câteva kill-uri": "A few kills",
	"DPS estimat": "Estimated DPS",
	"Danger = procentul de nave de luptă din kill-urile pilotului (zKillboard). DPS-ul e o estimare din hardpoint-uri, mărimea navei și drone bandwidth, nu din fit-ul real.": "Danger = share of combat ships among the pilot's kills (zKillboard). DPS is an estimate from hardpoints, hull size and drone bandwidth, not from the real fit.",
	"Destinație": "Destination",
	"Detalii": "Details",
	"Estimare": "Estimate",
	"Grupări": "Groups",
	"Intel PvP": "PvP intel",
	"Istoricul zKillboard se încarcă doar pentru primii {n} piloți.": "zKillboard history is loaded only for the first {n} pilots.",
	"Kill-uri 7z": "Kills 7d",
	"Kill-urile pe sistem vin din ESI (ultima oră, actualizate de CCP o dată pe oră). Sistemele cu kill-uri primesc detalii din zKillboard: ce nave au murit, cine a atacat și dacă pare un gatecamp.": "Kills per system come from ESI (last hour, refreshed by CCP once an hour). Systems with kills get details from zKillboard: which ships died, who attacked and whether it looks like a gatecamp.",
	"Liniștit": "Quiet",
	"Lipește lista din Local sau rezultatul D-Scan": "Paste the Local list or the D-Scan result",
	"Lipește numele piloților din Local (unul pe rând) sau liniile copiate din D-Scan.": "Paste pilot names from Local (one per line) or the lines copied from D-Scan.",
	"Local și D-Scan": "Local and D-Scan",
	"Nave distruse / h": "Ships destroyed / h",
	"Nave": "Ships",
	"Navă atacator": "Attacker ship",
	"Navă preferată": "Favourite ship",
	"Necunoscut": "Unknown",
	"Nicio activitate PvP semnificativă pe rută în ultima oră.": "No significant PvP activity on the route in the last hour.",
	"Nicio navă pe scan.": "No ships on scan.",
	"Niciun kill în ultimele 60 de minute pe zKillboard.": "No kills in the last 60 minutes on zKillboard.",
	"Nimic de analizat": "Nothing to analyse",
	"Nu există rută prin stargate-uri între aceste sisteme (wormhole sau sistem izolat).": "There is no stargate route between these systems (wormhole or isolated system).",
	"Nume negăsite: {list}": "Names not found: {list}",
	"Număr": "Count",
	"Ocazional": "Occasional",
	"Tu": "You",
	"Caracterele tale": "Your characters",
	"Piloți din listă care sunt caractere logate în aplicație. Nu intră în calculul de risc.": "Pilots in the list that are characters logged into the app. They are not counted in the risk figures.",
	"Pe grid = sub 10.000 km. DPS-ul e o estimare din hardpoint-uri, mărimea navei și drone bandwidth, nu din fit-ul real; carrierele și fighterii nu sunt incluși.": "On grid = under 10,000 km. DPS is an estimate from hardpoints, hull size and drone bandwidth, not from the real fit; carriers and fighters are not included.",
	"Pe grid": "On grid",
	"Pericol pe rută și analiza Local / D-Scan": "Route danger and Local / D-Scan analysis",
	"Periculos": "Dangerous",
	"Pilot": "Pilot",
	"Piloți": "Pilots",
	"Pornire": "Start",
	"Posibil gatecamp în: {list}": "Possible gatecamp in: {list}",
	"Posibil gatecamp": "Possible gatecamp",
	"Preferință": "Preference",
	"Prin low/null": "Through low/null",
	"Risc": "Risk",
	"Securitate minimă": "Lowest security",
	"Sistem": "System",
	"Sisteme cu risc": "Risky systems",
	"Sistemul „{name}” nu există.": "System \"{name}\" does not exist.",
	"Smartbomb camp": "Smartbomb camp",
	"Suma DPS-ului estimat pentru nava cea mai folosită de fiecare pilot cu kill-uri. Estimare din hardpoint-uri și drone bandwidth, nu fit-ul real.": "Sum of the estimated DPS of each pilot's most used ship, for pilots with kills. Estimated from hardpoints and drone bandwidth, not the real fit.",
	"Suma DPS-ului estimat pentru navele văzute. Estimare din hardpoint-uri și drone bandwidth, nu fit-ul real.": "Sum of the estimated DPS of the ships seen. Estimated from hardpoints and drone bandwidth, not the real fit.",
	"Sărituri / h": "Jumps / h",
	"Sărituri": "Jumps",
	"Tipuri de nave": "Ship types",
	"Verifică ruta": "Check route",
	"Victimă": "Victim",
	"alianță": "alliance",
	"bonus navă": "hull bonus",
	"corporație": "corporation",
	"se încarcă...": "loading...",
	"zKillboard nu a răspuns ({msg}). Încearcă din nou peste un minut.": "zKillboard did not respond ({msg}). Try again in a minute.",
	"zKillboard...": "zKillboard...",
	"{n} activi": "{n} active",
	"{n} bule de warp pe scan": "{n} warp bubbles on scan",
	"O bulă de warp pe scan": "One warp bubble on scan",
	"{n} sărituri": "{n} jumps",
	"În joc, dă click în lista din Local sau din fereastra D-Scan, apasă Ctrl+A apoi Ctrl+C și lipește aici. Vyraj recunoaște singur ce ai lipit.": "In game, click the Local list or the D-Scan window, press Ctrl+A then Ctrl+C and paste here. Vyraj detects what you pasted on its own.",
	"încă {n}": "{n} left",
	"Actualizat la {time}.": "Updated at {time}.",
	"Actualizează toate": "Refresh all",
	"Antrenează": "Training",
	"Coada se termină": "Queue ends",
	"Coada se termină în 24h": "Queue ends within 24h",
	"Coadă goală": "Empty queue",
	"Coadă: {n} skill-uri · {time}": "Queue: {n} skills · {time}",
	"Cont și Omega": "Account and Omega",
	"Cont și Omega · {name}": "Account and Omega · {name}",
	"Conturi": "Accounts",
	"Cozi goale": "Empty queues",
	"Data o găsești în launcher sau pe secure.eveonline.com, la Account Management.": "You can find the date in the launcher or on secure.eveonline.com, under Account Management.",
	"Delogat": "Logged out",
	"ESI nu spune când expiră Omega și nici ce caractere sunt pe același cont. Vyraj detectează Alpha/Omega din skill-uri și viteza de antrenament; data de expirare o pui tu o dată pe cont, iar caracterele cu același nume de cont o împart.": "ESI does not tell when Omega expires, nor which characters share an account. Vyraj detects Alpha/Omega from skills and training speed; you enter the expiry date once per account, and characters with the same account name share it.",
	"Expirat {date}": "Expired {date}",
	"Locație": "Location",
	"Nume cont (caracterele cu același nume împart data Omega)": "Account name (characters with the same name share the Omega date)",
	"Omega activ": "Omega active",
	"Omega expiră": "Omega expires",
	"Omega expiră pe": "Omega expires on",
	"Omega expiră în 7 zile": "Omega expires within 7 days",
	"Pauză": "Paused",
	"Permisiuni lipsă": "Missing permissions",
	"SP total": "Total SP",
	"Salvat": "Saved",
	"Se actualizează…": "Refreshing…",
	"Setează": "Set",
	"Structură privată": "Private structure",
	"Toate caracterele": "All characters",
	"Unele caractere au fost logate înainte ca Vyraj să ceară locația și statusul online. Fă din nou login cu ele din „Adaugă caracter”, dreapta sus.": "Some characters were logged in before Vyraj asked for location and online status. Log in with them again from “Add character”, top right.",
	"ex: cont principal": "e.g. main account",
	"login acum {time}": "last login {time} ago",
	"zile": "days",
	"În antrenament": "Training",
	"În spațiu": "In space",
	"Șterge data": "Clear date",
	"Navigație": "Navigation",
	"Jump planner pentru capitale, tracker Pochven și conexiuni Thera / Turnur": "Jump planner for capitals, Pochven tracker and Thera / Turnur connections",
	"Cele mai puține salturi": "Fewest jumps",
	"Cel mai puțin combustibil": "Least fuel",
	"Evită sisteme": "Avoid systems",
	"ex: Tama, Amamake": "e.g. Tama, Amamake",
	"Oboseală acum (min)": "Current fatigue (min)",
	"Calculează": "Calculate",
	"Nu găsesc nave cu jump drive în datele SDE.": "No jump drive ships found in the SDE data.",
	"Rază jump": "Jump range",
	"Consum / LY": "Fuel / LY",
	"Combustibil": "Fuel",
	"Reducere oboseală": "Fatigue reduction",
	"Calculat pentru {name} cu skill-urile caracterului activ și modulele fit-ului (ex: Jump Drive Economizer). Treci cu mouse-ul peste rază și consum pentru detalii.": "Calculated for {name} with the active character's skills and the fit's modules (e.g. Jump Drive Economizer). Hover range and fuel for the breakdown.",
	"Calculez ruta de jump": "Calculating the jump route",
	"Nu găsesc sistemul „{name}”.": "System \"{name}\" not found.",
	"{name} e highsec: acolo nu se poate aprinde cyno, deci nu poți sări direct. Alege un sistem lowsec din apropiere și continuă pe porți.": "{name} is highsec: no cyno can be lit there, so you cannot jump in directly. Pick a nearby lowsec system and take the gates from there.",
	"În {name} nu se poate sări cu jump drive (Pochven, Zarzakh sau spațiu Jove).": "You cannot jump drive into {name} (Pochven, Zarzakh or Jove space).",
	"Nu există rută cu raza de {ly} LY. Antrenează Jump Drive Calibration sau alege alt punct de plecare.": "No route with a {ly} LY range. Train Jump Drive Calibration or pick another starting point.",
	"Din {name} ai {n} sisteme cyno în rază.": "From {name} you have {n} cyno systems in range.",
	"{n} salturi": "{n} jumps",
	"Salturi": "Jumps",
	"Distanță totală": "Total distance",
	"Izotopi": "Isotopes",
	"Cost combustibil (Jita)": "Fuel cost (Jita)",
	"Timp de așteptare": "Waiting time",
	"Oboseală la final": "Fatigue at the end",
	"Pornești din highsec: e permis, doar destinațiile trebuie să fie low/null.": "You start in highsec: that is allowed, only the destinations must be low/null.",
	"Din": "From",
	"În": "To",
	"Regiune": "Region",
	"Aștepți înainte": "Wait before",
	"Activare": "Activation",
	"Oboseală după": "Fatigue after",
	"Distanța e în linie dreaptă între sisteme. Combustibilul e rotunjit în sus la fiecare salt. Oboseala și timpul de activare urmează regulile actuale (max 5 h oboseală, max 30 min activare); „Aștepți înainte” presupune că sari imediat ce se termină activarea.": "Distance is the straight line between systems. Fuel is rounded up on every jump. Fatigue and activation timers follow the current rules (max 5 h fatigue, max 30 min activation); \"Wait before\" assumes you jump as soon as the activation timer ends.",
	"Încărcăm harta Pochven": "Loading the Pochven map",
	"Graniță": "Border",
	"Intern": "Internal",
	"Rol": "Role",
	"Nave / h": "Ships / h",
	"Porți către": "Gates to",
	"Te duce într-un sistem Home (Kino, Niarja sau Archee).": "Takes you to a Home system (Kino, Niarja or Archee).",
	"Te duce într-un sistem de graniță dintre două Krai.": "Takes you to a border system between two Krai.",
	"Te duce într-un sistem intern din Pochven.": "Takes you to an internal Pochven system.",
	"Te duce într-un sistem din Krai-ul numit.": "Takes you to a system in the named Krai.",
	"Ieșire din Pochven spre un sistem cu victorie Triglavian minoră.": "Exit from Pochven to a Triglavian minor victory system.",
	"Ieșire din Pochven lângă locul vechi al sistemului pe hartă.": "Exit from Pochven near the system's old map location.",
	"Sisteme": "Systems",
	"Cel mai mult PvE": "Most PvE",
	"Cel mai mult PvP": "Most PvP",
	"Activitate din ESI pe ultima oră, actualizată de CCP o dată pe oră ({ago}).": "Activity from ESI for the last hour, updated by CCP once an hour ({ago}).",
	"Se încarcă activitatea din ESI...": "Loading activity from ESI...",
	"Împărțirea pe Krai e fixă în datele jocului: CCP nu publică un „control de cladă” care să se schimbe, iar timer-ele structurilor jucătorilor nu sunt publice în ESI.": "The Krai split is fixed in the game data: CCP does not publish a changing \"clade control\", and player structure timers are not public in ESI.",
	"Filamente Pochven": "Pochven filaments",
	"Filament": "Filament",
	"Piloți max": "Max pilots",
	"Unde te duce": "Where it takes you",
	"Intrarea se mai face prin găuri de vierme: fiecare sistem Pochven are un C729 care apare la cel mult 3 salturi de vechea lui poziție, plus găuri X450, R081, U372 și F216 care se mută. Nu există o sursă publică live pentru aceste semnături; conexiunile Thera și Turnur sunt în tab-ul lor.": "You can also enter through wormholes: every Pochven system has a C729 that spawns at most 3 jumps from its old location, plus roaming X450, R081, U372 and F216 holes. There is no public live source for these signatures; Thera and Turnur connections are in their own tab.",
	"ESI nu a răspuns: {msg}": "ESI did not respond: {msg}",
	"Sistemul tău": "Your system",
	"Conexiunile vin de la EVE-Scout (Signal Cartel), scanate de voluntari. Cu sistemul tău completat, tabelul arată câte salturi pe porți ai până la fiecare ieșire.": "Connections come from EVE-Scout (Signal Cartel), scanned by volunteers. With your system filled in, the table shows how many gate jumps you are from each exit.",
	"Încărcăm conexiunile de la EVE-Scout": "Loading connections from EVE-Scout",
	"EVE-Scout nu a răspuns ({msg}). Încearcă din nou mai târziu.": "EVE-Scout did not respond ({msg}). Try again later.",
	"Nicio conexiune raportată acum": "No connections reported right now",
	"Conexiuni active": "Active connections",
	"Cea mai apropiată": "Closest",
	"Semnătură hub": "Hub signature",
	"Ieșire": "Exit",
	"Salturi de la tine": "Jumps from you",
	"Mărime max": "Max size",
	"Ore rămase": "Hours left",
	"Mod": "Mode",
	"Bonus navă": "Ship bonus",
	"Modul proiectat pe navă": "Module projected on the ship",
	"Flotă și efecte proiectate": "Fleet and projected effects",
	"Boost-uri flotă": "Fleet boosts",
	"Efecte proiectate": "Projected effects",
	"Modul": "Module",
	"Daună/ciclu": "Damage/cycle",
	"Cicluri": "Cycles",
	"Alege un modul din listă": "Pick a module from the list",
	"tuburi": "tubes",
	"boost flotă": "fleet boost",
	"Burst": "Burst",
	"proiectat: {name}": "projected: {name}",
	"{n} intrări · câștigat {in} · cheltuit {out}": "{n} entries · earned {in} · spent {out}",
	"se văd primele {n}": "showing the first {n}",
	"Sumă": "Amount",
	"Descriere": "Description",
	"Nicio intrare pentru filtrele alese.": "No entries match these filters.",
	"pe oră": "per hour",
	"pe săptămână": "per week",
	"pe zi": "per day",
	"istoric salvat din {date}": "history saved since {date}",
	"Câștigat": "Earned",
	"Cheltuit": "Spent",
	"EVE dă doar ultimele 30 de zile din jurnal. Vyraj păstrează local tot ce citește, așa că perioadele mai lungi se completează pe măsură ce deschizi Wallet. Acum ai date din {date}.": "EVE only returns the last 30 days of the journal. Vyraj keeps everything it reads locally, so longer periods fill in as you keep opening Wallet. You have data since {date}.",
	"Câștigat și cheltuit {bucket}": "Earned and spent {bucket}",
	"Toate perioadele": "All periods",
	"Perioadă": "Period",
	"Intrări": "Income",
	"Ieșiri": "Expenses",
	"Nicio intrare în perioada aleasă.": "No entries in this period.",
	"Market: ce ai cumpărat și vândut": "Market: what you bought and sold",
	"Cumpărat": "Bought",
	"Vândut": "Sold",
	"Jurnal": "Journal",
	"Export CSV": "Export CSV",
	"Toate tipurile": "All types",
	"Caută în descriere...": "Search description...",
	"24 ore": "24 hours",
	"7 zile": "7 days",
	"90 zile": "90 days",
	"Tot": "All",
	"Skill-urile care dau bonusurile navei": "Skills that give the ship's bonuses",
	"Mastery {lvl} pentru {ship} adăugat în skill plan": "Mastery {lvl} for {ship} added to the skill plan",
	"Trage ca să lărgești meniul · dublu click pentru lățimea inițială": "Drag to widen the menu · double click to reset",
	"{name} nu mai e logat în EVE (sesiunea a expirat sau a fost revocată). Fă din nou login din ecranul Caracter.": "{name} is no longer logged in to EVE (the session expired or was revoked). Log in again from the Character screen.",
	"Nu am putut încărca datele aplicației ({url}). Reîncarcă pagina; dacă tot nu merge, încearcă mai târziu.": "Could not load the app data ({url}). Reload the page; if it still fails, try again later.",
	"{name} adăugat în fighter bay": "{name} added to the fighter bay",
	"Nu mai e loc în fighter bay: ar fi {used} / {total} m³": "No room left in the fighter bay: would be {used} / {total} m³",
	"Nu mai ai tuburi de fighteri libere ({n})": "No free fighter tubes left ({n})",
	"Poți lansa maxim {n} escadrile {kind}": "You can launch at most {n} {kind} squadrons",
	"curent": "current",
	"Sesiunea EVE pentru {name} a expirat sau a fost revocată. Fă din nou login din meniul de caractere.": "The EVE session for {name} expired or was revoked. Log in again from the character menu.",
	"Niciun atribut nu conține „{q}”.": "No attribute contains “{q}”.",
	"Se încarcă itemele…": "Loading items…",
	"Ștergi caracterul din aplicație, împreună cu datele lui salvate în browser (istoric wallet, skill plan, SKIN-uri)?": "Remove the character from the app, together with its data saved in the browser (wallet history, skill plan, SKINs)?",
	"Salvează ca nou": "Save as new",
	"Păstrează fit-ul salvat și creează o copie nouă": "Keep the saved fit and create a new copy",
	"{name} adăugat în fighter bay (nelansat: {why})": "{name} added to the fighter bay (not launched: {why})",
	"Salvat ca fit nou: {name}": "Saved as a new fit: {name}",
	"Fit-ul nu încape cu skill-urile lui {name}: {why}": "The fit does not fit with {name}'s skills: {why}",
	"Volume împachetate": "Packaged volumes",
	"Taxa trebuie să fie între 0 și 100%": "The fee must be between 0 and 100%",
	"Rezultate pentru „{q}”": "Results for “{q}”",
	"primele {n} din {total}": "first {n} of {total}",
	"„{name}” se potrivește cu mai multe sisteme: {list}. Scrie numele complet.": "“{name}” matches several systems: {list}. Type the full name.",
	"Nu am evitat: {list} (nume necunoscute sau ambigue).": "Not avoided: {list} (unknown or ambiguous names).",
	"zKillboard nu a răspuns pentru {n} piloți (site căzut sau prea multe cereri). Nu știm nimic despre ei, nu-i considera inofensivi. Apasă din nou Analizează peste un minut.": "zKillboard did not answer for {n} pilots (site down or too many requests). We know nothing about them, do not assume they are harmless. Press Analyze again in a minute.",
	"zKillboard indisponibil": "zKillboard unavailable",
	"Neverificat": "Unchecked",
	"Alpha: antrenează la jumătate de viteză": "Alpha: trains at half speed",
	"Nu poți muta skill-ul înaintea precondițiilor lui": "You cannot move the skill above its prerequisites",
	"Am scos și {n} skill-uri care depindeau de el": "Also removed {n} skills that depended on it",
	"Pune durata run-ului în minute (minim 1).": "Enter the run duration in minutes (at least 1).",
	"{n} linii de loot nerecunoscute: {list}": "{n} unrecognized loot lines: {list}",
	"nicio intrare în jurnal": "no journal entries",
	"Marjă netă": "Net margin",
	"Profit buy → sell după taxe (buy order, apoi sell order)": "Buy → sell profit after fees (buy order, then sell order)",
	"Nu există buy orders în Jita, deci nu se poate calcula marja.": "There are no buy orders in Jita, so the margin cannot be calculated.",
	"Nu există sell orders în Jita, deci nu se poate calcula marja.": "There are no sell orders in Jita, so the margin cannot be calculated.",
	"Niciun ordin pe partea asta": "No orders on this side",
	"Fără sell orders": "No sell orders",
	"piața globală PLEX": "global PLEX market",
	"Suma tuturor intrărilor pozitive din perioadă ({n})": "Sum of all positive entries in the period ({n})",
	"Suma tuturor intrărilor negative din perioadă ({n})": "Sum of all negative entries in the period ({n})",
	"Venit total": "Total income",
	"Cheltuieli totale": "Total expenses",
	"Venit total minus cheltuieli totale": "Total income minus total expenses",
	"Graficul începe la {date}, prima zi cu date salvate local.": "The chart starts on {date}, the first day with locally saved data.",
	"Detectat din skill-uri sau din viteza de antrenament": "Detected from skills or training speed",
	"Detectat din viteza de antrenament": "Detected from training speed",
	"Nu se poate determina: niciun skill peste limita Alpha și nimic în antrenament acum": "Cannot be determined: no skill above the Alpha limit and nothing training right now",
	"Bulă de warp pe grid, la {dist}": "Warp bubble on grid, at {dist}",
	"{n} bule de warp pe grid, cea mai apropiată la {dist}": "{n} warp bubbles on grid, the closest at {dist}",
	"O bulă de warp în sistem, departe de tine (AU)": "One warp bubble in system, far from you (AU)",
	"{n} bule de warp în sistem, departe de tine (AU)": "{n} warp bubbles in system, far from you (AU)",
	"Prețurile sunt din scanarea de {age}. Ordinele din Jita se schimbă des, rescanează înainte să pui ordine.": "Prices come from the scan made {age}. Jita orders change often, rescan before placing orders.",
	"Nu am date ESI pentru caracter (delogat sau eroare la citire)": "No ESI data for this character (logged out or read error)",
	"Câștigat total": "Total earned",
	"Cheltuit total": "Total spent",
	"Tab gol": "Empty tab",
	"Modificări nesalvate": "Unsaved changes",
	"Închide tab-ul": "Close tab",
	"Tab nou": "New tab",
	"Poți avea maxim {n} fit-uri deschise. Închide un tab ca să deschizi altul.": "You can have at most {n} fits open. Close a tab to open another one.",
	"„{name}” are modificări nesalvate. Închizi tab-ul?": "\"{name}\" has unsaved changes. Close the tab?",
	"Implanturi": "Implants",
	"Boostere": "Boosters",
	"Proiectate": "Projected",
	"Comandă": "Command",
	"Note": "Notes",
	"Tuburi": "Tubes",
	"Apasă pe un fighter din browser ca să-l adaugi.": "Click a fighter in the browser to add it.",
	"Cantitate": "Quantity",
	"Cât timp tab-ul Cargo e deschis, orice item apăsat în browser intră în cargo.": "While the Cargo tab is open, any item you click in the browser goes into the cargo hold.",
	"Apasă pe un booster din browser ca să-l adaugi.": "Click a booster in the browser to add it.",
	"Cât timp tab-ul e deschis, modulele proiectabile apăsate în browser se adaugă aici.": "While this tab is open, projectable modules you click in the browser are added here.",
	"Cât timp tab-ul e deschis, burst charge-urile apăsate în browser se adaugă aici.": "While this tab is open, burst charges you click in the browser are added here.",
	"Note despre fit: rol, cum se zboară, ce mai trebuie în cargo…": "Notes about the fit: role, how to fly it, what else goes in the cargo…",
	"{name} adăugat în cargo": "{name} added to cargo",
	"{name} proiectat pe navă": "{name} projected onto the ship",
	"{name} adăugat la boost-uri": "{name} added to boosts",
	"Nu mai e loc în cargo: ar fi {used} / {total} m³": "Not enough cargo space: it would be {used} / {total} m³",
	"Link": "Link",
	"Copiază un link care deschide fit-ul direct în Vyraj": "Copy a link that opens the fit directly in Vyraj",
	"Link copiat. Cine îl deschide primește fit-ul într-un tab nou.": "Link copied. Whoever opens it gets the fit in a new tab.",
	"Browserul nu poate crea linkul de fit": "This browser can't create the fit link",
	"Copiază link": "Copy link",
	"Fit deschis din link: {name}": "Fit opened from link: {name}",
	"Linkul de fit nu e valid sau e incomplet.": "The fit link is invalid or incomplete.",
	"Anomalii": "Anomalies",
	"Viteza scade mult, tank-ul prin viteză nu mai ajută.": "Your speed drops a lot, speed tanking stops working.",
	"Nu poți face warp și MWD-ul se oprește.": "You cannot warp and your MWD shuts off.",
	"Pierzi țintele câteva secunde. Dronele și ECCM ajută.": "You lose your targets for a few seconds. Drones and ECCM help.",
	"Raza de țintire și scan resolution scad.": "Targeting range and scan resolution drop.",
	"Semnătura crește, deci primești mai mult damage.": "Your signature grows, so you take more damage.",
	"Îți golește capacitorul și oprește tank-ul activ.": "Drains your capacitor and shuts down your active tank.",
	"NPC-urile se repară între ele. Omoară întâi navele de suport.": "NPCs repair each other. Kill the support ships first.",
	"Omni: orice tip": "Omni: any type",
	"Tankează nelimitat": "Tanks indefinitely",
	"Rezistă {t}": "Holds {t}",
	"Nu rezistă: {t}": "Does not hold: {t}",
	"MWD activ": "MWD active",
	"Cap stabil {p}%": "Cap stable {p}%",
	"Cap gol în {t}": "Cap empty in {t}",
	"{p}% din DPS-ul tău e pe tipurile bune": "{p}% of your DPS is of the right types",
	"Tank PvE": "PvE tank",
	"Conținut": "Content",
	"Mixt": "Mixed",
	"DPS primit": "Incoming DPS",
	"Valori tipice": "Typical values",
	"EHP pe profil": "EHP vs profile",
	"Tank sustenabil": "Sustained tank",
	"Acoperire": "Coverage",
	"Damage primit": "Incoming damage",
	"limitat la {p}% de cap": "limited to {p}% by cap",
	"Timp până la moarte": "Time to die",
	"Damage de folosit": "Damage to use",
	"Fără EWAR important.": "No significant EWAR.",
	"DPS-ul și neut-ul sunt valori tipice pentru o cameră grea. Le poți schimba după site-ul tău.": "DPS and neut are typical values for a hard room. You can change them to match your site.",
	"Ordine market": "Market orders",
	"Ordinele tuturor caracterelor, cu alertă la outbid și undercut": "Orders of all your characters, with outbid and undercut alerts",
	"Ordine active": "Active orders",
	"Istoric ordine": "Order history",
	"Anulat": "Cancelled",
	"Cel mai bun": "Best price",
	"Citim istoricul ordinelor": "Loading order history",
	"Citim ordinele și registrul de market": "Loading your orders and the market book",
	"Completat": "Completed",
	"Concurență": "Competition",
	"Copiază prețul nou, apoi Modify Order în joc și Ctrl+V": "Copy the new price, then Modify Order in game and paste",
	"Cumpărat prin ordine": "Bought through orders",
	"Depășite": "Beaten",
	"EVE acceptă doar 4 cifre semnificative la preț, deci pasul minim (tick) crește cu prețul: 0,01 ISK sub 100 ISK, 1.000 ISK la milioane. Prețul nou e cel mai mic pas care te pune primul. ESI nu poate modifica ordine: copiezi prețul, apoi Modify Order în joc și lipești.": "EVE only accepts 4 significant digits in a price, so the minimum step (tick) grows with the price: 0.01 ISK below 100 ISK, 1,000 ISK in the millions. The new price is the smallest step that puts you first. ESI cannot modify orders: copy the price, then Modify Order in game and paste it.",
	"Egal": "Tied",
	"Escrow buy": "Buy escrow",
	"Executat": "Filled",
	"Expirat": "Expired",
	"Expiră în 24 h": "Expire within 24 h",
	"Expiră": "Expires",
	"Fă login cu EVE din ecranul Caracter ca să vezi ordinele de market.": "Log in with EVE from the Character screen to see your market orders.",
	"Fără permisiunea pentru ordine: {names}. Fă din nou login cu aceste caractere din meniul de caractere.": "No market orders permission: {names}. Log in again with these characters from the character menu.",
	"Niciun caracter logat": "No character logged in",
	"Niciun ordin activ.": "No active orders.",
	"Niciun ordin pentru filtrul ales.": "No orders match this filter.",
	"Niciun ordin închis în ultimele 90 de zile.": "No closed orders in the last 90 days.",
	"Notificare la outbid / undercut": "Notify on outbid / undercut",
	"Outbid ({n})": "Outbid ({n})",
	"Plasat": "Placed",
	"Preț copiat: {p}": "Price copied: {p}",
	"Preț nou": "New price",
	"Prețul meu": "My price",
	"Rămas de cumpărat": "Left to buy",
	"Se verifică…": "Checking…",
	"Singur": "Alone",
	"Stare": "State",
	"Undercut ({n})": "Undercut ({n})",
	"Valoare sell": "Sell value",
	"Verificat la {time}. Se reverifică singur la 5 minute cât timp aplicația e deschisă.": "Checked at {time}. Rechecked every 5 minutes while the app is open.",
	"Vândut prin ordine": "Sold through orders",
	"același preț": "same price",
	"expirat": "expired",
	"modificabil în {t}": "can modify in {t}",
	"rază": "range",
	"următorul, la {d}": "next one, {d} away",
	"{n} ordine depășite": "{n} orders beaten",
	"Ți-a dat cineva outbid": "Someone outbid you",
	"Ți-a dat cineva undercut": "Someone undercut you",
	"Colonii și timere": "Colonies and timers",
	"Profit pe lanțuri": "Chain profit",
	"Planificator lanț": "Chain planner",
	"Profit pe lanțuri P0-P4 la prețuri Jita și timer-ele de extracție pe toate caracterele": "P0-P4 chain profit at Jita prices and extraction timers across all characters",
	"Încărcăm coloniile": "Loading colonies",
	"Oprit": "Stopped",
	"{qty} / ciclu · ciclu {cycle} · {heads} capete": "{qty} / cycle · cycle {cycle} · {heads} heads",
	"Gol": "Empty",
	"Fă login cu EVE din meniul de caractere (dreapta sus) ca să vezi coloniile.": "Log in with EVE from the character menu (top right) to see your colonies.",
	"Următoarea expirare": "Next expiry",
	"Colonii": "Colonies",
	"Caractere cu colonii": "Characters with colonies",
	"Extractoare": "Extractors",
	"Expirate": "Expired",
	"Expiră în 24h": "Expiring in 24h",
	"P0 extras / zi": "P0 extracted / day",
	"Fără permisiunea pentru planete: {names}. Fă din nou login cu ele din „Adaugă caracter”, dreapta sus.": "No planets permission: {names}. Log in with them again from \"Add character\", top right.",
	"Planetă": "Planet",
	"Fabrici": "Factories",
	"Depozit": "Storage",
	"Actualizat în joc": "Updated in game",
	"Citim coloniile din ESI": "Reading colonies from ESI",
	"Nicio colonie găsită": "No colonies found",
	"Caracterele logate nu au colonii PI sau nu au încă permisiunea pentru planete.": "The logged-in characters have no PI colonies or don't have the planets permission yet.",
	"Timer-ele extractoarelor vin din ESI și sunt exacte. Fabricile și depozitele sunt instantanee de la ultima deschidere a coloniei în joc. Producția pe zi e estimată din cantitatea pe ciclu la Jita buy.": "Extractor timers come from ESI and are exact. Factories and storage are snapshots from the last time the colony was opened in game. Daily output is estimated from the quantity per cycle at Jita buy.",
	"Încărcăm prețurile Jita pentru PI": "Loading Jita prices for PI",
	"Cumpăr inputurile la": "Buy inputs at",
	"Vând produsul la": "Sell product at",
	"Taxă POCO (%)": "POCO tax (%)",
	"produs sau input": "product or input",
	"Cel mai bun acum: {name}, {isk} ISK/oră pe fabrică.": "Best right now: {name}, {isk} ISK/hour per factory.",
	"Produs": "Product",
	"Inputuri / ciclu": "Inputs / cycle",
	"Cost inputuri": "Input cost",
	"Taxe": "Taxes",
	"Profit / ciclu": "Profit / cycle",
	"Profit / oră": "Profit / hour",
	"fără preț": "no price",
	"Profitul e pentru o fabrică ce cumpără inputurile și vinde produsul. Taxa de export se aplică produsului, iar inputurile plătesc jumătate (import). Valori de bază pe nivel: {list} ISK. Click pe un rând pentru lanțul complet până la P0.": "Profit is for one factory that buys its inputs and sells the product. Export tax applies to the product and inputs pay half (import). Base values per tier: {list} ISK. Click a row for the full chain down to P0.",
	"Valoare Jita sell": "Jita sell value",
	"Volum produs": "Product volume",
	"Volum P0 necesar": "P0 volume needed",
	"Tipuri de P0": "P0 types",
	"Planete minime": "Minimum planets",
	"Lanțul complet": "Full chain",
	"P0 necesar și planete": "P0 needed and planets",
	"Planete": "Planets",
	"Combinație minimă de planete": "Minimum planet combination",
	"Unde merită să te oprești": "Where it pays to stop",
	"Taxă export": "Export tax",
	"Câștig față de nivelul anterior": "Gain over previous tier",
	"Valoarea întregului lanț vândut la fiecare nivel: dacă un nivel adaugă puțin față de cel anterior, poți vinde mai jos și economisești fabrici și transport. Taxa folosește {rate}% din tab-ul Profit pe lanțuri.": "Value of the whole chain sold at each tier: if a tier adds little over the previous one, you can sell lower and save factories and hauling. Tax uses {rate}% from the Chain profit tab.",
	"Alege un produs": "Pick a product",
	"BPC propriu": "Own BPC",
	"BPO calculat pe {n} runs, BPC pe toate run-urile rămase. Click pe un rând ca să-l deschizi în calculator.": "BPOs are calculated for {n} runs, BPCs for all remaining runs. Click a row to open it in the calculator.",
	"Bază / run": "Base / run",
	"Blueprint-urile mele": "My blueprints",
	"Calculator": "Calculator",
	"Calculez costul de producție": "Calculating the production cost",
	"Caracterul nu are blueprint-uri de manufacturing sau reaction (sau ESI încă nu le-a actualizat).": "The character has no manufacturing or reaction blueprints (or ESI has not updated them yet).",
	"Citesc blueprint-urile din EVE": "Reading blueprints from EVE",
	"Citesc joburile de industrie": "Reading industry jobs",
	"Comparație decryptori": "Decryptor comparison",
	"Cost / unitate": "Cost / unit",
	"Cost / încercare": "Cost / attempt",
	"Cost de manufacturing și invention comparat cu prețul de vânzare din Jita": "Manufacturing and invention cost compared with the Jita sell price",
	"Cost job": "Job cost",
	"Cost job invention": "Invention job cost",
	"Decryptor": "Decryptor",
	"Deschide în calculator": "Open in calculator",
	"Din {name}. Skill-uri: {skills}. Job cost = {p}% din EIV-ul produsului × cost index invention.": "From {name}. Skills: {skills}. Job cost = {p}% of the product EIV × invention cost index.",
	"Fără decryptor": "No decryptor",
	"Fără decryptor, cu skill-urile caracterului activ. Costul include datacores, job-ul de invention împărțit la șansă și manufacturing-ul cu ME 2 / TE 4.": "No decryptor, with the active character's skills. The cost includes datacores, the invention job divided by the chance, and manufacturing at ME 2 / TE 4.",
	"Fără rig": "No rig",
	"Gata în": "Done in",
	"ISK / oră": "ISK / hour",
	"ISK / oră ține cont doar de timpul de manufacturing. Click pe un rând ca să folosești acel decryptor.": "ISK / hour only counts manufacturing time. Click a row to use that decryptor.",
	"Invention ({n} unități)": "Invention ({n} units)",
	"Invention / unitate": "Invention / unit",
	"Invention din blueprint-urile tale": "Invention from your blueprints",
	"Jita sell după taxe": "Jita sell after fees",
	"Joburi active": "Active jobs",
	"Joburile pornite în joc apar aici după câteva minute (ESI le actualizează periodic).": "Jobs started in game show up here after a few minutes (ESI updates them periodically).",
	"Locul de producție": "Production site",
	"Manufacturing din blueprint-urile tale": "Manufacturing from your blueprints",
	"Material": "Material",
	"Materiale": "Materials",
	"Materiale la": "Materials at",
	"Niciun blueprint": "No blueprints",
	"Niciun blueprint de manufacturing": "No manufacturing blueprints",
	"Niciun job activ": "No active jobs",
	"Nu găsesc sistemul „{name}”; cost index-ul e 0.": "System \"{name}\" not found; the cost index is 0.",
	"Nu găsesc un blueprint care produce „{name}”.": "No blueprint found that produces \"{name}\".",
	"Preț unitar": "Unit price",
	"Produs T2 / T3": "T2 / T3 product",
	"Produs sau blueprint": "Product or blueprint",
	"Produsul nu are sell orders în Jita.": "The product has no sell orders in Jita.",
	"Profit / unitate": "Profit / unit",
	"Rig": "Rig",
	"Runs / BPC": "Runs / BPC",
	"Scrie numele unui item care se fabrică (navă, modul, muniție, componentă) sau deschide unul din Blueprint-urile mele.": "Type the name of a manufacturable item (ship, module, ammo, component) or open one from My blueprints.",
	"Structură + rig": "Structure + rig",
	"Sursă blueprint": "Blueprint source",
	"TE blueprint": "Blueprint TE",
	"Taxele de vânzare vin din skill-urile caracterului activ: sales tax {t}%, broker fee {b}%.": "Selling fees come from the active character's skills: sales tax {t}%, broker fee {b}%.",
	"Taxă facilitate %": "Facility tax %",
	"Timp job": "Job time",
	"Treci cu mouse-ul peste cost, profit, timp și cost job pentru detalii. Timpul folosește skill-urile caracterului activ ({name}).": "Hover cost, profit, time and job cost for details. Time uses the active character's skills ({name}).",
	"Unele materiale nu au preț în Jita și sunt socotite 0.": "Some materials have no Jita price and count as 0.",
	"Vânzare cu sell order (după broker și tax)": "Selling with a sell order (after broker fee and tax)",
	"Vânzare instant în buy orders (după tax)": "Instant sale into buy orders (after tax)",
	"bonus structură {n}%": "structure bonus {n}%",
	"cost / unitate": "cost / unit",
	"cost index {n}%": "cost index {n}%",
	"cost job / unitate": "job cost / unit",
	"ex: Hammerhead II": "e.g. Hammerhead II",
	"invention / unitate": "invention / unit",
	"materiale / unitate": "materials / unit",
	"taxă facilitate {t}% + SCC {s}%": "facility tax {t}% + SCC {s}%",
	"timp de bază": "base time",
	"valoare estimată EIV": "estimated item value (EIV)",
	"{name} nu face acest tip de job; bonusurile structurii pot să nu se aplice.": "{name} does not run this job type; structure bonuses may not apply.",
	"Încarc datele de industrie": "Loading industry data",
	"Șansă": "Chance",
	"Structură": "Structure",
	"Cost": "Cost",
	"Gata": "Ready",
	"buc": "pcs",
	"Pe pauză": "Paused",
	"În lucru": "In progress",
	"Randament și ISK/oră": "Yield and ISK/hour",
	"Valoare ore": "Ore value",
	"Asteroizi": "Asteroids",
	"Ore de lună": "Moon ores",
	"Gheață": "Ice",
	"Gaz": "Gas",
	"Ore": "Ore",
	"Vinde brut": "Sell raw",
	"Comprimă și vinde": "Compress and sell",
	"Reprocesează": "Reprocess",
	"Mining și reprocesare": "Mining and reprocessing",
	"ISK pe oră pe tip de ore din fit-ul și skill-urile tale, plus valoarea reprocesată față de vânzarea brută, la prețuri Jita": "ISK per hour per ore type from your fit and skills, plus reprocessed value versus selling raw, at Jita prices",
	"Mining": "Mining",
	"Încărcăm datele de mining și prețurile Jita": "Loading mining data and Jita prices",
	"deschis în Fitting": "open in Fitting",
	"Niciun fit de mining": "No mining fit",
	"Fă în Fitting un fit cu module de mining (lasere, strip minere, ice harvestere, gas scoop-uri sau drone de mining) și salvează-l sau lasă-l deschis. Aici apare apoi randamentul pe oră pentru fiecare tip de ore.": "Build a fit with mining modules in Fitting (lasers, strip miners, ice harvesters, gas scoops or mining drones) and save it or leave it open. The hourly yield for every ore type then shows up here.",
	"Crit-uri, medie": "Crits, average",
	"Reziduu pierdut": "Residue lost",
	"Hold plin în": "Hold full in",
	"Buy max (vânzare instant)": "Buy max (instant sell)",
	"Sell min (ordin de vânzare)": "Sell min (sell order)",
	"ex: Spodumain": "e.g. Spodumain",
	"Variante +5% / +10% / +15%": "+5% / +10% / +15% variants",
	"Cel mai bun ore": "Best ore",
	"Calculat cu skill-urile caracterului activ ({name}), modulele, crystalele, dronele active și boost-urile de flotă din fit (tab-ul Command din Fitting). Treci cu mouse-ul peste m³ / ciclu și durată pentru detalii.": "Calculated with the active character's skills ({name}), the fit's modules, crystals, active drones and fleet boosts (Command tab in Fitting). Hover m³ / cycle and duration for details.",
	"Modul / dronă": "Module / drone",
	"m³ / ciclu": "m³ / cycle",
	"Ciclu": "Cycle",
	"Crit · bonus": "Crit · bonus",
	"Reziduu · volum": "Residue · volume",
	"ISK pe oră pe tip de ore": "ISK per hour per ore type",
	"Unități/h": "Units/h",
	"Brut": "Raw",
	"Comprimat": "Compressed",
	"Reprocesat": "Reprocessed",
	"Randament": "Yield",
	"Cel mai bun /h": "Best /h",
	"Recomandare": "Advice",
	"Reprocesat folosește setările din tab-ul Reprocesare ({place}). Taxa de reprocesare e scăzută din valoare. Crystalele dau bonusul doar pe ore-ul lor; pentru restul randamentul e recalculat fără crystal.": "Reprocessed uses the settings from the Reprocessing tab ({place}). The reprocessing tax is taken off the value. Crystals only give their bonus on their own ore; for the rest the yield is recalculated without the crystal.",
	"Niciun ore pentru filtrele alese": "No ore matches the chosen filters",
	"stație NPC": "NPC station",
	"Rig {kind}": "Rig {kind}",
	"Unde reprocesezi": "Where you reprocess",
	"Loc": "Place",
	"Stație NPC (50%)": "NPC station (50%)",
	"Securitate": "Security",
	"Din clone: {name}": "From clone: {name}",
	"Din clone: niciunul": "From clone: none",
	"Fără implant": "No implant",
	"Taxă (%)": "Tax (%)",
	"Rig-urile și securitatea contează doar în structuri. Taxa o vezi în fereastra de reprocesare din joc (în stațiile NPC depinde de standing).": "Rigs and security only matter in structures. You can see the tax in the in-game reprocessing window (in NPC stations it depends on standing).",
	"Randament pe familie de ore": "Yield per ore family",
	"Reprocessing {a} și Reprocessing Efficiency {b} pentru {name}. Treci cu mouse-ul peste randament pentru detalii.": "Reprocessing {a} and Reprocessing Efficiency {b} for {name}. Hover the yield for details.",
	"Calculator reprocesare": "Reprocessing calculator",
	"Lipește ore, gheață sau ore comprimat din inventar": "Paste ore, ice or compressed ore from your inventory",
	"ex: Compressed Veldspar 120000": "e.g. Compressed Veldspar 120000",
	"Nu recunosc: {list}": "Not recognised: {list}",
	"Prețuri Jita": "Jita prices",
	"Reprocesarea câștigă cu {isk} față de vânzarea brută la buy.": "Reprocessing wins by {isk} over selling raw to buy orders.",
	"Vânzarea brută câștigă cu {isk} față de reprocesare (la buy).": "Selling raw wins by {isk} over reprocessing (to buy orders).",
	"Brut · buy": "Raw · buy",
	"Brut · sell": "Raw · sell",
	"Reprocesat · buy": "Reprocessed · buy",
	"Reprocesat · sell": "Reprocessed · sell",
	"Intrare": "Input",
	"Mineral": "Mineral",
	"Buy max": "Buy max",
	"Rămân nereprocesate (sub o porție): {list}": "Left unprocessed (under one batch): {list}",
	"Ignorat (nu e ore, gheață sau ore comprimat): {list}": "Ignored (not ore, ice or compressed ore): {list}",
	"Filtrează": "Filter",
	"unitate": "unit",
	"Brut ISK/m³": "Raw ISK/m³",
	"Comprimat ISK/m³": "Compressed ISK/m³",
	"Reprocesat ISK/m³": "Reprocessed ISK/m³",
	"Reprocesat vs brut": "Reprocessed vs raw",
	"fără ordine în Jita": "no orders in Jita",
	"Valori pe m³ de ore necomprimat, deci comparabile direct cu m³/h din tab-ul Randament. Reprocesat folosește setările de la Reprocesare ({place}) și skill-urile caracterului activ.": "Values per m³ of uncompressed ore, so they compare directly with m³/h from the Yield tab. Reprocessed uses the Reprocessing settings ({place}) and the active character's skills.",
	"Null sec / W-space": "Null sec / W-space",
	"bază reprocesare": "reprocessing base",
	"Jucători care au participat la kill. NPC-urile (sentry gun-uri, CONCORD, rați) apar separat.": "Players who took part in the kill. NPCs (sentry guns, CONCORD, rats) are shown separately.",
	"Doar NPC": "NPC only",
	"Nivelul de securitate al sistemului.": "The system's security level.",
	"Nave de jucători distruse în sistem în ultima oră, fără capsule. Sursa: ESI, actualizat de CCP o dată pe oră. Include și navele de gank omorâte de CONCORD.": "Player ships destroyed in the system in the last hour, pods excluded. Source: ESI, updated by CCP once an hour. Includes gank ships killed by CONCORD.",
	"Capsule distruse în sistem în ultima oră (ESI).": "Pods destroyed in the system in the last hour (ESI).",
	"NPC-uri (rați) omorâte de jucători în ultima oră (ESI). Arată cât de mult se face PvE aici, nu pericol.": "NPCs (rats) killed by players in the last hour (ESI). Shows PvE activity, not danger.",
	"Nave care au intrat în sistem prin stargate în ultima oră (ESI). Arată traficul.": "Ships that jumped into the system through a stargate in the last hour (ESI). Shows traffic.",
	"NPC uciși / h": "NPCs killed / h",
	"Omorât doar de NPC-uri (CONCORD, sentry gun-uri sau rați), fără jucători.": "Killed only by NPCs (CONCORD, sentry guns or rats), no players.",
	"{n} jucători": "{n} players",
	"{n} NPC (sentry gun, CONCORD, rați)": "{n} NPC (sentry guns, CONCORD, rats)",
	"Solo pe zKillboard: un singur jucător, NPC-urile nu se pun la socoteală.": "Solo on zKillboard: a single player, NPCs don't count.",
	"Afișez {n} din {total} kill-uri pe zKillboard în ultima oră (cele mai recente).": "Showing {n} of {total} kills on zKillboard in the last hour (most recent).",
	"{n} kill-uri pe zKillboard în ultima oră.": "{n} kills on zKillboard in the last hour.",
	"Scade rezistența EM pe shield, armor și hull. Capacitorul se reîncarcă de două ori mai repede.": "Lowers EM resistance on shield, armor and hull. The capacitor recharges twice as fast.",
	"Optimal și falloff mai mici la turete. Viteza maximă crește.": "Lower turret optimal and falloff. Maximum velocity goes up.",
	"Scade rezistența kinetic pe shield, armor și hull. Scan resolution crește.": "Lowers kinetic resistance on shield, armor and hull. Scan resolution goes up.",
	"Scade rezistența thermal pe shield, armor și hull. Armor HP crește.": "Lowers thermal resistance on shield, armor and hull. Armor HP goes up.",
	"Scade rezistența explosive pe shield, armor și hull. Shield HP crește.": "Lowers explosive resistance on shield, armor and hull. Shield HP goes up.",
	"Fără": "None",
	"Intensitate": "Intensity",
	"EHP față de spațiu normal: {d}%": "EHP vs normal space: {d}%",
	"Set {name}": "{name} set",
	"Apasă pe un implant din browser ca să-l adaugi.": "Click an implant in the browser to add it.",
	"SKIN-uri filtrate": "Filtered SKINs",
	"Deținut": "Owned",
	"Fără ordere": "No orders",
	"Niciun SKIN pentru filtrul ales.": "No SKIN matches the selected filter.",
	"Filtrează navă": "Filter ship",
	"Filtrează colecție": "Filter collection",
	"Șterge filtrul": "Clear filter",
	"{n} SKIN-uri": "{n} SKINs",
	"{n} nave": "{n} ships",
	"Nicio potrivire": "No matches",
	"Prețurile Jita sunt păstrate până le reîmprospătezi. Click pentru a le citi din nou.": "Jita prices are kept until you refresh them. Click to read them again.",
	"Prețuri Jita din {time}": "Jita prices from {time}",
	"Prețuri {hub} din {time}": "{hub} prices from {time}",
	"Prețurile hub-ului sunt păstrate până le reîmprospătezi. Click pentru a le citi din nou.": "Hub prices are kept until you refresh them. Click to read them again.",
	"Date din {time}": "Data from {time}",
	"Asset-urile și prețurile Jita sunt păstrate până le reîmprospătezi. Click pentru a le citi din nou.": "Assets and Jita prices are kept until you refresh them. Click to read them again.",
	"Ofertele LP și prețurile Jita sunt păstrate până le reîmprospătezi. Click pentru a le citi din nou.": "LP offers and Jita prices are kept until you refresh them. Click to read them again.",
	"Jurnalul și soldul sunt păstrate până le reîmprospătezi. Click pentru a le citi din nou din ESI.": "The journal and balance are kept until you refresh them. Click to read them again from ESI.",
	"Ordonează după": "Order by",
	"Nave deținute": "Ships owned",
	"Progres %": "Progress %",
	"Click pentru a copia: {name}": "Click to copy: {name}",
	"Copiat: {name}": "Copied: {name}",
	"Montat acum": "Fitted now",
	"Montat pe navă": "Fitted on the ship",
	"Înlocuiește în fit": "Replace in fit",
	"Comparat cu {name}, montat pe navă": "Compared with {name}, fitted on the ship",
	"{name} nu intră în același tip de slot": "{name} does not fit the same slot type",
	"{name} montat în locul lui {old}": "{name} fitted in place of {old}",
	"Încarcă în tab-ul curent un fit PvE publicat, cu module T2": "Load a published PvE fit with T2 modules into the current tab",
	"Încarcă în tab-ul curent un fit PvP publicat, cu module T2": "Load a published PvP fit with T2 modules into the current tab",
	"Fit {kind} publicat încărcat în tab-ul curent": "Published {kind} fit loaded in the current tab",
	"„{name}” are modificări nesalvate. Le pierzi și încarci „{next}” în tab-ul ăsta?": "“{name}” has unsaved changes. Discard them and load “{next}” in this tab?",
	"Nu există fit {kind} publicat pentru nava asta, am deschis unul generat din bonusurile și statisticile ei": "There is no published {kind} fit for this ship, so one was generated from its bonuses and stats",
	"Ce nu încape cu skill-urile caracterului apare cu roșu.": "Whatever does not fit with the character's skills is shown in red.",
	"Fit {kind} generat din bonusurile, sloturile, hardpoints, CPU și powergrid ale navei, cu module T2, pentru că nu am găsit un fit publicat. Modifică-l după cum zbori.": "{kind} fit generated from the ship's bonuses, slots, hardpoints, CPU and powergrid, with T2 modules, because no published fit was found. Adjust it to the way you fly.",
	"Fit publicat: „{title}”, sursa {url} . Modulele care au variantă T2 au fost trecute pe T2.": "Published fit: “{title}”, source {url} . Modules with a T2 variant were switched to T2.",
	"Fit {kind} compus din bonusurile și statisticile navei, pentru că nu există un fit publicat. Modulele care au variantă T2 au fost trecute pe T2.": "{kind} fit built from the ship's bonuses and stats, because no published fit exists. Modules with a T2 variant were switched to T2.",
	"„{name}” are modificări nesalvate. Le pierzi și începi un fit nou pe {ship}?": "“{name}” has unsaved changes. Discard them and start a new fit on {ship}?",
	"bonusuri (pe nivel de skill)": "bonuses (per skill level)",
	"Charges sunt T2 unde există, altfel faction.": "Charges are T2 where available, otherwise faction.",
	"Am scos modulele care nu aveau sloturi sau hardpoints libere pe navă ({n}).": "Removed modules that had no free slot or hardpoint on the ship ({n}).",
	"Ca să încapă în CPU și powergrid cu toate skill-urile la V, unele module au trecut pe varianta faction ({n}).": "To fit CPU and powergrid with all skills at V, some modules were switched to their faction variant ({n}).",
	"Unde nici faction nu a ajuns, unele module au rămas T1 sau meta ({n}).": "Where faction was not enough, some modules were kept T1 or meta ({n}).",
	"Ca să încapă în calibration, unele rig-uri au rămas T1 ({n}).": "To fit calibration, some rigs were kept T1 ({n}).",
	"Am redus dronele și încărcătura din cargo ca să încapă în bay.": "Drones and cargo were reduced to fit their bays.",
	"Scrie numele corporației și apasă Enter": "Type the corporation name and press Enter",
	"Confirmare": "Confirm",
	"Continuă": "Continue",
	"Anulează": "Cancel",
	"Pierde modificările": "Discard changes",
	"Luna anterioară": "Previous month",
	"Luna următoare": "Next month",
	"Azi": "Today",
	"Alege data": "Pick a date"
};
const lang = loadJson("eve-fit:ui:lang", navigator.language.toLowerCase().startsWith("ro") ? "ro" : "en") === "en" ? "en" : "ro";
document.documentElement.lang = lang;
function tx(text, vars) {
	const s = lang === "en" ? EN[text] ?? text : text;
	return vars ? s.replace(/\{(\w+)\}/g, (m, k) => k in vars ? String(vars[k]) : m) : s;
}
// src/data/sde.ts
const Category = {
	Ship: 6,
	Module: 7,
	Charge: 8,
	Skill: 16,
	Drone: 18,
	Implant: 20,
	Subsystem: 32,
	Fighter: 87
};
var Sde = class {
	build;
	types = /* @__PURE__ */ new Map();
	attributes = /* @__PURE__ */ new Map();
	effects = /* @__PURE__ */ new Map();
	groups = /* @__PURE__ */ new Map();
	units;
	cloneGrades;
	mutaplasmids = /* @__PURE__ */ new Map();
	buffs = /* @__PURE__ */ new Map();
	weathers;
	mutaplasmidsByBase = /* @__PURE__ */ new Map();
	abyssalBase = /* @__PURE__ */ new Map();
	attrByName = /* @__PURE__ */ new Map();
	effectByName = /* @__PURE__ */ new Map();
	typeByName = /* @__PURE__ */ new Map();
	constructor(raw) {
		this.build = raw.version.build;
		for (const g of raw.groups) this.groups.set(g.i, {
			id: g.i,
			name: g.n,
			categoryId: g.c
		});
		for (const a of raw.attributes) {
			this.attributes.set(a.i, {
				id: a.i,
				name: a.n,
				displayName: a.dn,
				defaultValue: a.def,
				stackable: a.st === 1,
				highIsGood: a.hi === 1,
				maxAttributeId: a.max,
				unitId: a.u,
				published: a.pub === 1,
				showWhenZero: a.z === 1,
				categoryId: a.cat
			});
			this.attrByName.set(a.n, a.i);
		}
		for (const e of raw.effects) {
			this.effects.set(e.i, {
				id: e.i,
				name: e.n,
				category: e.cat,
				modifiers: e.mods,
				durationAttributeId: e.dur,
				dischargeAttributeId: e.dis,
				rangeAttributeId: e.rng,
				falloffAttributeId: e.fal,
				resistanceAttributeId: e.res
			});
			this.effectByName.set(e.n, e.i);
		}
		for (const t of raw.types) {
			const group = this.groups.get(t.g);
			const attrs = /* @__PURE__ */ new Map();
			for (const [k, v] of Object.entries(t.a)) attrs.set(Number(k), v);
			this.types.set(t.i, {
				id: t.i,
				name: t.n,
				groupId: t.g,
				groupName: group?.name ?? "",
				categoryId: group?.categoryId ?? 0,
				marketGroupId: t.mg,
				metaGroupId: t.mt,
				metaLevel: t.ml,
				variationParentId: t.vp,
				raceId: t.r,
				factionId: t.f,
				attrs,
				effects: t.e
			});
			this.typeByName.set(fold(t.n), t.i);
		}
		this.units = new Map(Object.entries(raw.units ?? {}).map(([k, v]) => [Number(k), v]));
		this.cloneGrades = raw.cloneGrades.map((c) => ({
			id: c.i,
			name: c.n,
			skills: new Map(Object.entries(c.skills).map(([k, v]) => [Number(k), v]))
		}));
		for (const b of raw.buffs ?? []) this.buffs.set(b.i, b);
		this.weathers = raw.weathers ?? [];
		for (const m of raw.mutaplasmids ?? []) {
			const mp = {
				id: m.i,
				name: m.n,
				ranges: new Map(Object.entries(m.a).map(([k, v]) => [Number(k), v])),
				resultFor: new Map(m.m.flatMap((x) => x.from.map((f) => [f, x.to])))
			};
			this.mutaplasmids.set(mp.id, mp);
			for (const x of m.m) for (const f of x.from) {
				const list = this.mutaplasmidsByBase.get(f);
				if (list) list.push(mp);
				else this.mutaplasmidsByBase.set(f, [mp]);
				const bases = this.abyssalBase.get(x.to);
				if (bases) {
					if (!bases.includes(f)) bases.push(f);
				} else this.abyssalBase.set(x.to, [f]);
			}
		}
	}
	attrId(name) {
		const id = this.attrByName.get(name);
		if (id == null) throw new Error(tx("Atribut necunoscut: {name}", { name }));
		return id;
	}
	hasAttr(name) {
		return this.attrByName.has(name);
	}
	effectId(name) {
		return this.effectByName.get(name);
	}
	type(id) {
		const t = this.types.get(id);
		if (!t) throw new Error(tx("Item necunoscut în datele de fitting: {id}", { id }));
		return t;
	}
	findType(name) {
		const id = this.typeByName.get(fold(name.trim()));
		return id == null ? void 0 : this.types.get(id);
	}
	baseAttr(typeId, attrId) {
		return this.types.get(typeId)?.attrs.get(attrId) ?? this.attributes.get(attrId)?.defaultValue ?? 0;
	}
	hasEffect(typeId, effectName) {
		const id = this.effectByName.get(effectName);
		return id != null && (this.types.get(typeId)?.effects.includes(id) ?? false);
	}
	variations(typeId) {
		const t = this.types.get(typeId);
		if (!t) return [];
		const parent = t.variationParentId ?? t.id;
		if (!this.variationIndex) {
			this.variationIndex = /* @__PURE__ */ new Map();
			for (const x of this.types.values()) {
				const p = x.variationParentId ?? x.id;
				const list = this.variationIndex.get(p);
				if (list) list.push(x);
				else this.variationIndex.set(p, [x]);
			}
		}
		return [...this.variationIndex.get(parent) ?? [t]].sort((a, b) => (a.metaLevel ?? 0) - (b.metaLevel ?? 0) || a.name.localeCompare(b.name));
	}
	variationIndex;
	mutaplasmidsFor(baseTypeId) {
		return this.mutaplasmidsByBase.get(baseTypeId) ?? [];
	}
	isAbyssal(typeId) {
		return this.abyssalBase.has(typeId);
	}
	abyssalBases(abyssalTypeId) {
		return this.abyssalBase.get(abyssalTypeId) ?? [];
	}
	modesFor(shipId) {
		const ship = this.types.get(shipId);
		if (!ship) return [];
		return [...this.types.values()].filter((t) => t.groupId === 1306 && t.name.startsWith(`${ship.name} `)).sort((a, b) => a.name.localeCompare(b.name));
	}
	typesInCategory(categoryId) {
		return [...this.types.values()].filter((t) => t.categoryId === categoryId);
	}
};
// src/character/training.ts
const DEFAULT_ATTRIBUTES = {
	charisma: 20,
	intelligence: 20,
	memory: 20,
	perception: 20,
	willpower: 20
};
// src/character/characters.ts
function allLevels(sde, level) {
	const skills = new Map(sde.typesInCategory(Category.Skill).map((t) => [t.id, level]));
	return {
		id: level === 5 ? "all5" : "all0",
		name: level === 5 ? "All 5" : "All 0",
		kind: level === 5 ? "all5" : "all0",
		skills,
		sp: /* @__PURE__ */ new Map(),
		attributes: DEFAULT_ATTRIBUTES,
		implants: [],
		queue: []
	};
}
// src/engine/overrides.ts
const perLevel = (skill, attr) => skill.base(skill.dogma.sde.attrId(attr)) * skill.get("skillLevel");
const MISSILE_DAMAGE = {
	missileEMDmgBonus: "emDamage",
	missileExplosiveDmgBonus: "explosiveDamage",
	missileThermalDmgBonus: "thermalDamage",
	missileKineticDmgBonus2: "kineticDamage"
};
function propulsion(withSignature) {
	return (dogma, mod, penalized) => {
		const sde = dogma.sde;
		const ship = dogma.ship;
		ship.addModifier(sde.attrId("mass"), {
			source: mod,
			op: Op.ModAdd,
			fromAttr: sde.attrId("massAddition"),
			penalized: false
		});
		ship.addModifier(sde.attrId("maxVelocity"), {
			source: mod,
			op: Op.PostPercent,
			penalized,
			value: () => mod.get("speedFactor") * mod.get("speedBoostFactor") / ship.get("mass")
		});
		if (withSignature) ship.addModifier(sde.attrId("signatureRadius"), {
			source: mod,
			op: Op.PostPercent,
			fromAttr: sde.attrId("signatureRadiusBonus"),
			penalized
		});
	};
}
const HANDLERS$1 = {
	moduleBonusMicrowarpdrive: propulsion(true),
	moduleBonusAfterburner: propulsion(false),
	...Object.fromEntries(Object.entries(MISSILE_DAMAGE).map(([effect, attr]) => [effect, ((dogma, skill) => {
		const id = dogma.sde.attrId(attr);
		for (const charge of dogma.charges) {
			if (!charge.requiresSkill(skill.typeId)) continue;
			charge.addModifier(id, {
				source: skill,
				op: Op.PostPercent,
				penalized: false,
				value: () => perLevel(skill, "damageMultiplierBonus")
			});
		}
	})])),
	droneDmgBonus: (dogma, skill) => {
		const id = dogma.sde.attrId("damageMultiplier");
		for (const { item } of dogma.drones) {
			if (!item.requiresSkill(skill.typeId)) continue;
			item.addModifier(id, {
				source: skill,
				op: Op.PostPercent,
				penalized: false,
				value: () => perLevel(skill, "damageMultiplierBonus")
			});
		}
	},
	selfRof: (dogma, skill) => {
		const id = dogma.sde.attrId("speed");
		for (const mod of dogma.modules) {
			if (!mod.requiresSkill(skill.typeId)) continue;
			mod.addModifier(id, {
				source: skill,
				op: Op.PostPercent,
				penalized: false,
				value: () => perLevel(skill, "rofBonus")
			});
		}
	},
	slotModifier: (dogma, sub) => {
		for (const [slot, from] of [
			["hiSlots", "hiSlotModifier"],
			["medSlots", "medSlotModifier"],
			["lowSlots", "lowSlotModifier"]
		]) dogma.ship.addModifier(dogma.sde.attrId(slot), {
			source: sub,
			op: Op.ModAdd,
			fromAttr: dogma.sde.attrId(from),
			penalized: false
		});
	},
	hardPointModifierEffect: (dogma, sub) => {
		for (const [slot, from] of [["turretSlotsLeft", "turretHardPointModifier"], ["launcherSlotsLeft", "launcherHardPointModifier"]]) dogma.ship.addModifier(dogma.sde.attrId(slot), {
			source: sub,
			op: Op.ModAdd,
			fromAttr: dogma.sde.attrId(from),
			penalized: false
		});
	}
};
Object.keys(HANDLERS$1);
function applyOverrides(dogma, item, effect, penalized) {
	HANDLERS$1[effect.name]?.(dogma, item, penalized);
}
// src/engine/projected.ts
const allFiveCache = /* @__PURE__ */ new WeakMap();
function allFive(sde) {
	let skills = allFiveCache.get(sde);
	if (!skills) {
		skills = new Map(sde.typesInCategory(Category.Skill).map((t) => [t.id, 5]));
		allFiveCache.set(sde, skills);
	}
	return skills;
}
function projectedSource(sde, list) {
	return new Dogma(sde, {
		shipId: 0,
		skills: allFive(sde),
		modules: list.map((p, i) => ({
			typeId: p.typeId,
			state: "active",
			chargeId: p.chargeId,
			slotKey: `proj${i}`
		}))
	});
}
function resistance(target, source, effect) {
	const sde = target.sde;
	const id = effect.resistanceAttributeId ?? (sde.hasAttr("remoteResistanceID") ? source.get("remoteResistanceID") : 0);
	return id > 0 && sde.attributes.has(id) ? target.ship.attr(id) : 1;
}
function boost(item, attr, value, source) {
	const sde = item.dogma.sde;
	if (!sde.hasAttr(attr) || !value) return;
	item.addModifier(sde.attrId(attr), {
		source,
		op: Op.PostPercent,
		value: () => value,
		penalized: true
	});
}
const shipBoost = (pairs, offensive) => (target, source, effect, count) => {
	const res = offensive ? resistance(target, source, effect) : 1;
	for (let i = 0; i < count; i++) for (const [src, tgt] of pairs) boost(target.ship, tgt, source.get(src) * res, source);
};
const turretBoost = (offensive) => (target, source, effect, count) => {
	const res = offensive ? resistance(target, source, effect) : 1;
	const gunnery = target.sde.findType("Gunnery")?.id ?? 0;
	for (const m of target.modules) {
		if (!m.requiresSkill(gunnery)) continue;
		for (let i = 0; i < count; i++) for (const [src, tgt] of [
			["trackingSpeedBonus", "trackingSpeed"],
			["maxRangeBonus", "maxRange"],
			["falloffBonus", "falloff"]
		]) boost(m, tgt, source.get(src) * res, source);
	}
};
const HANDLERS = {
	remoteWebifierFalloff: shipBoost([["speedFactor", "maxVelocity"]], true),
	remoteTargetPaintFalloff: shipBoost([["signatureRadiusBonus", "signatureRadius"]], true),
	remoteSensorDampFalloff: shipBoost([["maxTargetRangeBonus", "maxTargetRange"], ["scanResolutionBonus", "scanResolution"]], true),
	remoteSensorBoostFalloff: shipBoost([
		["maxTargetRangeBonus", "maxTargetRange"],
		["scanResolutionBonus", "scanResolution"],
		["scanGravimetricStrengthPercent", "scanGravimetricStrength"],
		["scanMagnetometricStrengthPercent", "scanMagnetometricStrength"],
		["scanRadarStrengthPercent", "scanRadarStrength"],
		["scanLadarStrengthPercent", "scanLadarStrength"]
	], false),
	shipModuleTrackingDisruptor: turretBoost(true),
	shipModuleRemoteTrackingComputer: turretBoost(false),
	shipModuleGuidanceDisruptor: (target, source, effect, count) => {
		const res = resistance(target, source, effect);
		const mlo = target.sde.findType("Missile Launcher Operation")?.id ?? 0;
		for (const c of target.charges) {
			if (!c.requiresSkill(mlo)) continue;
			for (let i = 0; i < count; i++) for (const [src, tgt] of [
				["aoeCloudSizeBonus", "aoeCloudSize"],
				["aoeVelocityBonus", "aoeVelocity"],
				["missileVelocityBonus", "maxVelocity"],
				["explosionDelayBonus", "explosionDelay"]
			]) boost(c, tgt, source.get(src) * res, source);
		}
	}
};
function applyProjected(target, list) {
	const source = projectedSource(target.sde, list);
	list.forEach((p, i) => {
		const item = source.modules.find((m) => m.slotKey === `proj${i}`);
		if (!item || p.count <= 0) return;
		target.projected.push({
			item,
			count: p.count
		});
	});
	for (const { item, count } of target.projected) for (const effectId of item.type.effects) {
		const effect = target.sde.effects.get(effectId);
		if (effect) HANDLERS[effect.name]?.(target, item, effect, count);
	}
}
function projectedFlow(d) {
	const out = {
		shield: 0,
		armor: 0,
		hull: 0,
		capIn: 0,
		capOut: 0
	};
	const has = (item, name) => item.dogma.sde.hasEffect(item.typeId, name);
	for (const { item, count } of d.projected) {
		const seconds = item.get("duration") / 1e3;
		if (seconds <= 0) continue;
		const per = (attr) => item.get(attr) * count / seconds;
		if (has(item, "shipModuleRemoteShieldBooster") || has(item, "shipModuleAncillaryRemoteShieldBooster")) out.shield += per("shieldBonus");
		if (has(item, "shipModuleRemoteArmorRepairer") || has(item, "shipModuleAncillaryRemoteArmorRepairer") || has(item, "ShipModuleRemoteArmorMutadaptiveRepairer")) out.armor += per("armorDamageAmount");
		if (has(item, "shipModuleRemoteHullRepairer")) out.hull += per("structureDamageAmount");
		if (has(item, "shipModuleRemoteCapacitorTransmitter")) out.capIn += per("powerTransferAmount");
		if (has(item, "energyNeutralizerFalloff")) {
			const e = d.sde.effects.get(d.sde.effectId("energyNeutralizerFalloff"));
			out.capOut += per("energyNeutralizerAmount") * resistance(d, item, e);
		}
		if (has(item, "energyNosferatuFalloff")) out.capOut += per("powerTransferAmount");
	}
	return out;
}
function projectedCapCycles(d) {
	const out = [];
	const has = (item, name) => d.sde.hasEffect(item.typeId, name);
	for (const { item, count } of d.projected) {
		const duration = item.get("duration") / 1e3;
		if (duration <= 0) continue;
		const name = count > 1 ? `${item.type.name} ×${count}` : item.type.name;
		if (has(item, "shipModuleRemoteCapacitorTransmitter")) out.push({
			name,
			need: -item.get("powerTransferAmount") * count,
			duration
		});
		if (has(item, "energyNeutralizerFalloff")) {
			const e = d.sde.effects.get(d.sde.effectId("energyNeutralizerFalloff"));
			out.push({
				name,
				need: item.get("energyNeutralizerAmount") * resistance(d, item, e) * count,
				duration
			});
		}
		if (has(item, "energyNosferatuFalloff")) out.push({
			name,
			need: item.get("powerTransferAmount") * count,
			duration
		});
	}
	return out;
}
// src/engine/fleet.ts
const SKILL_FACTOR = 1.5;
function boostFactor(b) {
	return SKILL_FACTOR * (b.t2 ? 1.25 : 1) * (1 + b.shipBonus * 5 / 100) * (b.mindlink ? 1.25 : 1);
}
function fleetBuffs(sde, b) {
	if (!b?.charges.length) return [];
	const factor = boostFactor(b);
	const out = [];
	for (const chargeId of b.charges) for (let n = 1; n <= 4; n++) {
		const idAttr = `warfareBuff${n}ID`, multAttr = `warfareBuff${n}Multiplier`;
		if (!sde.hasAttr(idAttr) || !sde.hasAttr(multAttr)) continue;
		const id = sde.baseAttr(chargeId, sde.attrId(idAttr));
		const mult = sde.baseAttr(chargeId, sde.attrId(multAttr));
		if (id > 0 && mult) out.push({
			id,
			value: mult * factor
		});
	}
	return out;
}
// src/engine/dogma.ts
const Op = {
	PreAssign: -1,
	PreMul: 0,
	PreDiv: 1,
	ModAdd: 2,
	ModSub: 3,
	PostMul: 4,
	PostDiv: 5,
	PostPercent: 6,
	PostAssign: 7
};
const OP_ORDER = [
	Op.PreAssign,
	Op.PreMul,
	Op.PreDiv,
	Op.ModAdd,
	Op.ModSub,
	Op.PostMul,
	Op.PostDiv,
	Op.PostPercent,
	Op.PostAssign
];
const PENALTY_EXEMPT = /* @__PURE__ */ new Set([
	Category.Ship,
	Category.Charge,
	Category.Skill,
	Category.Implant,
	Category.Subsystem
]);
const EffectCategory = {
	Passive: 0,
	Active: 1,
	Target: 2,
	Area: 3,
	Online: 4,
	Overload: 5
};
const STATE_LEVEL = {
	offline: 0,
	online: 1,
	active: 2,
	overheated: 3
};
const PENALTY_DENOM = 2.67 ** 2;
function stackingFactor(index) {
	return Math.exp(-(index * index) / PENALTY_DENOM);
}
var DogmaItem = class {
	dogma;
	typeId;
	kind;
	state;
	slotKey;
	modifiers = /* @__PURE__ */ new Map();
	cache = /* @__PURE__ */ new Map();
	computing = /* @__PURE__ */ new Set();
	baseOverrides = /* @__PURE__ */ new Map();
	other;
	label;
	constructor(dogma, typeId, kind, state = "online", slotKey) {
		this.dogma = dogma;
		this.typeId = typeId;
		this.kind = kind;
		this.state = state;
		this.slotKey = slotKey;
	}
	get type() {
		return this.dogma.sde.type(this.typeId);
	}
	get categoryId() {
		return this.dogma.sde.types.get(this.typeId)?.categoryId ?? 0;
	}
	get groupId() {
		return this.dogma.sde.types.get(this.typeId)?.groupId ?? 0;
	}
	base(attrId) {
		return this.baseOverrides.get(attrId) ?? this.dogma.sde.baseAttr(this.typeId, attrId);
	}
	addModifier(attrId, mod) {
		const list = this.modifiers.get(attrId);
		if (list) list.push(mod);
		else this.modifiers.set(attrId, [mod]);
	}
	attr(attrId) {
		const cached = this.cache.get(attrId);
		if (cached != null) return cached;
		if (this.computing.has(attrId)) return this.base(attrId);
		this.computing.add(attrId);
		try {
			const value = this.compute(attrId);
			this.cache.set(attrId, value);
			return value;
		} finally {
			this.computing.delete(attrId);
		}
	}
	get(name) {
		return this.attr(this.dogma.sde.attrId(name));
	}
	trace(attrId) {
		const steps = [];
		return {
			base: this.base(attrId),
			steps,
			value: this.compute(attrId, steps)
		};
	}
	compute(attrId, steps) {
		let value = this.base(attrId);
		const step = (source, next, mult = false) => {
			steps?.push({
				source,
				before: value,
				after: next,
				mult
			});
			value = next;
		};
		const mods = this.modifiers.get(attrId);
		if (mods?.length) {
			const stackable = this.dogma.sde.attributes.get(attrId)?.stackable ?? true;
			for (const op of OP_ORDER) {
				const ofOp = mods.filter((m) => m.op === op);
				if (!ofOp.length) continue;
				const values = ofOp.map((m) => m.value ? m.value() : m.source.attr(m.fromAttr));
				switch (op) {
					case Op.PreAssign:
					case Op.PostAssign:
						step(ofOp[ofOp.length - 1].source, values[values.length - 1]);
						break;
					case Op.ModAdd:
						ofOp.forEach((m, i) => step(m.source, value + values[i]));
						break;
					case Op.ModSub:
						ofOp.forEach((m, i) => step(m.source, value - values[i]));
						break;
					default: {
						const toMult = (v) => op === Op.PostPercent ? 1 + v / 100 : op === Op.PreDiv || op === Op.PostDiv ? v === 0 ? 1 : 1 / v : v;
						const penalized = [];
						ofOp.forEach((m, i) => {
							const mult = toMult(values[i]);
							if (m.penalized && !stackable) penalized.push({
								source: m.source,
								mult
							});
							else step(m.source, value * mult, true);
						});
						const up = penalized.filter((x) => x.mult > 1).sort((a, b) => b.mult - a.mult);
						const down = penalized.filter((x) => x.mult < 1).sort((a, b) => a.mult - b.mult);
						for (const list of [up, down]) list.forEach((x, i) => step(x.source, value * (1 + (x.mult - 1) * stackingFactor(i)), true));
					}
				}
			}
		}
		const maxId = this.dogma.sde.attributes.get(attrId)?.maxAttributeId;
		if (maxId != null && maxId !== attrId && this.has(maxId)) value = Math.min(value, this.attr(maxId));
		return value;
	}
	has(attrId) {
		return this.baseOverrides.has(attrId) || (this.dogma.sde.types.get(this.typeId)?.attrs.has(attrId) ?? false);
	}
	requiresSkill(skillId) {
		return this.dogma.requiredSkillIds(this.typeId).includes(skillId);
	}
	invalidate() {
		this.cache.clear();
	}
};
const UNPENALIZED_BUFFS = /* @__PURE__ */ new Set([
	11,
	12,
	14,
	15,
	19,
	42,
	48
]);
function isBoosterSideEffect(name) {
	return /^booster.*Penalty/.test(name);
}
const REQ_SKILL_ATTRS = [
	"requiredSkill1",
	"requiredSkill2",
	"requiredSkill3",
	"requiredSkill4",
	"requiredSkill5",
	"requiredSkill6"
];
var Dogma = class {
	sde;
	ship;
	character;
	skills = [];
	implants = [];
	modules = [];
	charges = [];
	drones = [];
	mode;
	buffSources = [];
	projected = [];
	reqSkillCache = /* @__PURE__ */ new Map();
	boosterSides;
	constructor(sde, input) {
		this.sde = sde;
		this.boosterSides = input.boosterSides ?? {};
		this.ship = new DogmaItem(this, input.shipId, "ship");
		this.character = new DogmaItem(this, 0, "character");
		this.character.baseOverrides.set(sde.attrId("maxLockedTargets"), 2);
		for (const [skillId, level] of input.skills) {
			if (!sde.types.has(skillId)) continue;
			const skill = new DogmaItem(this, skillId, "skill");
			skill.baseOverrides.set(sde.attrId("skillLevel"), level);
			this.skills.push(skill);
		}
		for (const id of input.implants ?? []) if (sde.types.has(id)) this.implants.push(new DogmaItem(this, id, "implant"));
		for (const m of input.modules) {
			if (!sde.types.has(m.typeId)) continue;
			const mod = new DogmaItem(this, m.typeId, "module", m.state, m.slotKey);
			for (const [attr, v] of Object.entries(m.overrides ?? {})) mod.baseOverrides.set(Number(attr), v);
			this.modules.push(mod);
			if (m.chargeId && sde.types.has(m.chargeId)) {
				const charge = new DogmaItem(this, m.chargeId, "charge", m.state, m.slotKey);
				charge.other = mod;
				mod.other = charge;
				this.charges.push(charge);
			}
		}
		for (const d of input.drones ?? []) {
			if (!sde.types.has(d.typeId) || d.count <= 0) continue;
			this.drones.push({
				item: new DogmaItem(this, d.typeId, "drone", "active"),
				count: d.count
			});
		}
		if (input.mode && sde.types.has(input.mode)) this.mode = new DogmaItem(this, input.mode, "mode");
		this.applyAll();
		this.applyBuffs([...input.buffs ?? [], ...fleetBuffs(sde, input.fleet)]);
		if (input.projected?.length) applyProjected(this, input.projected);
	}
	applyBuffs(buffs) {
		const best = /* @__PURE__ */ new Map();
		for (const b of buffs) {
			const def = this.sde.buffs.get(b.id);
			if (!def) continue;
			const prev = best.get(b.id);
			if (prev == null || (def.agg === "Minimum" ? b.value < prev.value : b.value > prev.value)) best.set(b.id, {
				value: b.value,
				label: b.label
			});
		}
		for (const [id, { value, label }] of best) {
			const def = this.sde.buffs.get(id);
			const op = {
				PostPercent: Op.PostPercent,
				PostMul: Op.PostMul,
				PostAssignment: Op.PostAssign,
				ModAdd: Op.ModAdd,
				PreAssignment: Op.PreAssign
			}[def.op];
			if (op == null) continue;
			const source = new DogmaItem(this, 0, "buff");
			source.label = label;
			this.buffSources.push(source);
			const mod = {
				source,
				op,
				value: () => value,
				penalized: !UNPENALIZED_BUFFS.has(id)
			};
			const located = this.shipLocated;
			for (const attr of def.item) this.ship.addModifier(attr, mod);
			for (const attr of def.loc) for (const x of located) x.addModifier(attr, mod);
			for (const [attr, group] of def.locGroup) for (const x of located) if (x.groupId === group) x.addModifier(attr, mod);
			for (const [attr, skill] of def.locSkill) for (const x of located) if (x.requiresSkill(skill)) x.addModifier(attr, mod);
		}
	}
	requiredSkillIds(typeId) {
		let list = this.reqSkillCache.get(typeId);
		if (!list) {
			list = REQ_SKILL_ATTRS.map((n) => this.sde.types.get(typeId)?.attrs.get(this.sde.attrId(n)) ?? 0).filter((x) => x > 0);
			this.reqSkillCache.set(typeId, list);
		}
		return list;
	}
	get allItems() {
		return [
			this.ship,
			this.character,
			...this.skills,
			...this.implants,
			...this.modules,
			...this.charges,
			...this.drones.map((d) => d.item),
			...this.mode ? [this.mode] : []
		];
	}
	get shipLocated() {
		return [...this.modules, ...this.charges];
	}
	get owned() {
		return [
			...this.modules,
			...this.charges,
			...this.drones.map((d) => d.item)
		];
	}
	isEffectActive(item, effect) {
		if (effect.name === "skillEffect" || effect.name === "online") return false;
		const level = STATE_LEVEL[item.state];
		switch (item.kind) {
			case "module": {
				const lvl = item.categoryId === Category.Subsystem || item.slotKey?.startsWith("rig") ? Math.max(level, 1) : level;
				if (effect.category === EffectCategory.Passive || effect.category === EffectCategory.Online) return lvl >= 1;
				if (effect.category === EffectCategory.Active) return lvl >= 2;
				if (effect.category === EffectCategory.Overload) return lvl >= 3;
				return false;
			}
			case "charge": return effect.category === EffectCategory.Passive && level >= 1;
			default: return effect.category === EffectCategory.Passive;
		}
	}
	targets(source, m) {
		const bySkill = (list) => {
			const skill = m.s === -1 ? source.typeId : m.s;
			return skill ? list.filter((x) => x.requiresSkill(skill)) : [];
		};
		const located = m.d === "shipID" ? this.shipLocated : m.d === "charID" ? this.implants : [];
		switch (m.f) {
			case "ItemModifier": switch (m.d) {
				case "itemID": return [source];
				case "shipID": return [this.ship];
				case "charID": return [this.character];
				case "otherID": return source.other ? [source.other] : [];
				default: return [];
			}
			case "LocationModifier": return located;
			case "LocationGroupModifier": return located.filter((x) => x.groupId === m.g);
			case "LocationRequiredSkillModifier": return bySkill(located);
			case "OwnerRequiredSkillModifier": return m.d === "charID" ? bySkill(this.owned) : [];
			default: return [];
		}
	}
	applyAll() {
		for (const item of this.allItems) {
			if (!item.typeId) continue;
			const penalized = !PENALTY_EXEMPT.has(item.categoryId);
			for (const effectId of item.type.effects) {
				const effect = this.sde.effects.get(effectId);
				if (!effect || !this.isEffectActive(item, effect)) continue;
				if (item.kind === "implant" && isBoosterSideEffect(effect.name) && !this.boosterSides[item.typeId]?.includes(effect.name)) continue;
				for (const m of effect.modifiers) {
					if (m.op == null || m.to == null || m.from == null) continue;
					for (const target of this.targets(item, m)) target.addModifier(m.to, {
						source: item,
						op: m.op,
						fromAttr: m.from,
						penalized
					});
				}
				applyOverrides(this, item, effect, penalized);
			}
		}
	}
};
// src/engine/fit.ts
const SLOT_KINDS = [
	"high",
	"mid",
	"low",
	"rig",
	"subsystem"
];
const SLOT_EFFECTS = {
	high: "hiPower",
	mid: "medPower",
	low: "loPower",
	rig: "rigSlot",
	subsystem: "subSystem"
};
const SLOT_COUNT_ATTR = {
	high: "hiSlots",
	mid: "medSlots",
	low: "lowSlots",
	rig: "rigSlots"
};
function newFitId() {
	return Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}
function emptyFit(shipId, name = tx("Fit nou")) {
	return {
		id: newFitId(),
		name,
		shipId,
		slots: {
			high: [],
			mid: [],
			low: [],
			rig: [],
			subsystem: []
		},
		drones: [],
		cargo: [],
		implants: []
	};
}
function slotOf(sde, typeId) {
	return SLOT_KINDS.find((k) => sde.hasEffect(typeId, SLOT_EFFECTS[k]));
}
const subsystemPositions = /* @__PURE__ */ new Map();
function subsystemSlots(sde, shipId, max) {
	if (max <= 0) return 0;
	let n = subsystemPositions.get(shipId);
	if (n === void 0) {
		const fitsTo = sde.attrId("fitsToShipType");
		const slot = sde.attrId("subSystemSlot");
		const positions = /* @__PURE__ */ new Set();
		for (const t of sde.types.values()) if (t.categoryId === Category.Subsystem && sde.baseAttr(t.id, fitsTo) === shipId) positions.add(sde.baseAttr(t.id, slot));
		n = positions.size;
		subsystemPositions.set(shipId, n);
	}
	return n > 0 ? Math.min(n, Math.round(max)) : Math.round(max);
}
function slotCounts(sde, fit, dogma) {
	const ship = (dogma ?? new Dogma(sde, toDogmaInput(sde, fit, /* @__PURE__ */ new Map()))).ship;
	return {
		high: Math.round(ship.get(SLOT_COUNT_ATTR.high)),
		mid: Math.round(ship.get(SLOT_COUNT_ATTR.mid)),
		low: Math.round(ship.get(SLOT_COUNT_ATTR.low)),
		rig: Math.round(ship.get(SLOT_COUNT_ATTR.rig)),
		subsystem: subsystemSlots(sde, fit.shipId, ship.get("maxSubSystems"))
	};
}
function defaultState(sde, typeId) {
	return sde.type(typeId).effects.some((id) => sde.effects.get(id)?.category === EffectCategory.Active) ? "active" : "online";
}
const CHARGE_GROUP_ATTRS = [
	"chargeGroup1",
	"chargeGroup2",
	"chargeGroup3",
	"chargeGroup4",
	"chargeGroup5"
];
function canLoadCharge(sde, moduleId, chargeId) {
	const charge = sde.types.get(chargeId);
	if (!charge || charge.categoryId !== Category.Charge) return false;
	if (!CHARGE_GROUP_ATTRS.filter((n) => sde.hasAttr(n)).map((n) => sde.baseAttr(moduleId, sde.attrId(n))).filter((g) => g > 0).includes(charge.groupId)) return false;
	const modSize = sde.baseAttr(moduleId, sde.attrId("chargeSize"));
	const chargeSize = sde.baseAttr(chargeId, sde.attrId("chargeSize"));
	if (modSize > 0 && chargeSize > 0 && modSize !== chargeSize) return false;
	const capacity = sde.baseAttr(moduleId, sde.attrId("capacity"));
	const volume = sde.baseAttr(chargeId, sde.attrId("volume"));
	return capacity <= 0 || volume <= capacity;
}
function isFighterType(sde, typeId) {
	return sde.types.get(typeId)?.categoryId === Category.Fighter;
}
function squadSize(sde, typeId) {
	return Math.max(1, Math.round(sde.baseAttr(typeId, sde.attrId("fighterSquadronMaxSize"))) || 1);
}
function squadsFromFighters(sde, typeId, fighters) {
	return Math.max(1, Math.ceil(fighters / squadSize(sde, typeId)));
}
const FIGHTER_CLASSES = [
	["fighterSquadronIsLight", "fighterLightSlots"],
	["fighterSquadronIsSupport", "fighterSupportSlots"],
	["fighterSquadronIsHeavy", "fighterHeavySlots"]
];
function fighterClass(sde, typeId) {
	return FIGHTER_CLASSES.find(([flag]) => sde.hasAttr(flag) && sde.baseAttr(typeId, sde.attrId(flag)) > 0)?.[1];
}
function launchDrones(sde, fit, maxActive = 5) {
	const merged = [];
	for (const d of fit.drones) {
		const same = merged.find((x) => x.typeId === d.typeId);
		if (same) same.count += d.count;
		else merged.push({ ...d });
	}
	for (const d of merged) delete d.wanted;
	const shipAttr = (n) => sde.hasAttr(n) ? Math.round(sde.baseAttr(fit.shipId, sde.attrId(n))) : 0;
	let bandwidth = sde.baseAttr(fit.shipId, sde.attrId("droneBandwidth"));
	let slots = maxActive;
	let tubes = shipAttr("fighterTubes");
	const classLeft = new Map(FIGHTER_CLASSES.map(([, limit]) => [limit, shipAttr(limit)]));
	for (const d of merged) {
		if (isFighterType(sde, d.typeId)) {
			const cls = fighterClass(sde, d.typeId);
			const n = Math.max(0, Math.min(d.count, tubes, cls ? classLeft.get(cls) : tubes));
			d.active = n;
			tubes -= n;
			if (cls) classLeft.set(cls, classLeft.get(cls) - n);
			continue;
		}
		const per = sde.baseAttr(d.typeId, sde.attrId("droneBandwidthUsed"));
		const n = Math.max(0, Math.min(d.count, slots, per > 0 ? Math.floor(bandwidth / per) : d.count));
		d.active = n;
		bandwidth -= n * per;
		slots -= n;
	}
	fit.drones = merged;
}
function implantSlotKey(sde, id) {
	const booster = sde.baseAttr(id, sde.attrId("boosterness"));
	if (booster > 0) return `b${booster}`;
	const slot = sde.baseAttr(id, sde.attrId("implantness"));
	return slot > 0 ? `i${slot}` : `t${id}`;
}
function mergeImplants(sde, own, fitted) {
	const taken = new Set(fitted.map((id) => implantSlotKey(sde, id)));
	return [.../* @__PURE__ */ new Set([...own.filter((id) => !taken.has(implantSlotKey(sde, id))), ...fitted])];
}
function toDogmaInput(sde, fit, skills, implants = []) {
	const modules = SLOT_KINDS.flatMap((kind) => fit.slots[kind].flatMap((m, i) => m ? [{
		typeId: m.typeId,
		state: m.state,
		chargeId: m.chargeId,
		slotKey: `${kind}${i}`,
		overrides: m.mutation?.values
	}] : []));
	return {
		shipId: fit.shipId,
		skills,
		implants: mergeImplants(sde, implants, fit.implants),
		modules,
		drones: fit.drones.map((d) => ({
			typeId: d.typeId,
			count: d.active
		})),
		boosterSides: fit.boosterSides,
		mode: fit.mode,
		fleet: fit.fleet,
		projected: (fit.projected ?? []).filter((p) => p.count > 0).map((p) => ({
			typeId: p.typeId,
			count: p.count
		}))
	};
}
function buildDogma(sde, fit, character, buffs) {
	return new Dogma(sde, {
		...toDogmaInput(sde, fit, character.skills, character.implants),
		buffs
	});
}
// src/engine/capacitor.ts
function rechargeRate(capacity, tau, fraction) {
	if (tau <= 0) return 0;
	const c = Math.max(0, Math.min(1, fraction));
	return 10 * capacity / tau * (Math.sqrt(c) - c);
}
function capAfter(capacity, tau, cap, dt) {
	const root = 1 + (Math.sqrt(Math.max(0, cap) / capacity) - 1) * Math.exp(-5 * dt / tau);
	return capacity * root * root;
}
function discreteLasts(capacity, tau, cycles) {
	const active = cycles.filter((c) => c.duration > 0 && c.need !== 0);
	if (!active.length) return void 0;
	const next = active.map(() => 0);
	let cap = capacity;
	let t = 0;
	while (t < 86400) {
		let i = 0;
		for (let j = 1; j < active.length; j++) if (next[j] < next[i]) i = j;
		cap = capAfter(capacity, tau, cap, next[i] - t);
		t = next[i];
		if (active[i].need > 0 && cap < active[i].need) return t;
		cap = Math.min(capacity, cap - active[i].need);
		next[i] += active[i].duration;
	}
}
function simulateCapacitor(capacity, tau, usage, cycles = []) {
	const peakRecharge = capacity > 0 && tau > 0 ? 2.5 * capacity / tau : 0;
	const base = {
		capacity,
		rechargeTime: tau,
		peakRecharge,
		usage
	};
	if (usage <= 0) return {
		...base,
		stable: true,
		stableAt: 1
	};
	if (capacity <= 0 || tau <= 0) return {
		...base,
		stable: false,
		lastsSeconds: 0
	};
	if (usage <= peakRecharge) {
		const k = usage * tau / (10 * capacity);
		const s = (1 + Math.sqrt(Math.max(0, 1 - 4 * k))) / 2;
		return {
			...base,
			stable: true,
			stableAt: s * s
		};
	}
	const exact = discreteLasts(capacity, tau, cycles);
	if (exact != null) return {
		...base,
		stable: false,
		lastsSeconds: exact
	};
	let c = 1;
	let t = 0;
	const dt = .25;
	while (c > 0 && t < 86400) {
		c += (rechargeRate(capacity, tau, c) - usage) * dt / capacity;
		t += dt;
	}
	return {
		...base,
		stable: false,
		lastsSeconds: t
	};
}
// src/engine/stats.ts
const DAMAGE_TYPES = [
	"em",
	"thermal",
	"kinetic",
	"explosive"
];
const DAMAGE_ATTR = {
	em: "emDamage",
	thermal: "thermalDamage",
	kinetic: "kineticDamage",
	explosive: "explosiveDamage"
};
const zero = () => ({
	em: 0,
	thermal: 0,
	kinetic: 0,
	explosive: 0
});
const sum = (d) => d.em + d.thermal + d.kinetic + d.explosive;
const scale = (d, k) => ({
	em: d.em * k,
	thermal: d.thermal * k,
	kinetic: d.kinetic * k,
	explosive: d.explosive * k
});
const add = (a, b) => ({
	em: a.em + b.em,
	thermal: a.thermal + b.thermal,
	kinetic: a.kinetic + b.kinetic,
	explosive: a.explosive + b.explosive
});
const isOnline = (m) => m.state !== "offline";
const isFighter = (sde, typeId) => sde.types.get(typeId)?.categoryId === Category.Fighter;
function resources(sde, fit, d) {
	const ship = d.ship;
	const counts = slotCounts(sde, fit, d);
	const mods = d.modules;
	const turrets = mods.filter((m) => sde.hasEffect(m.typeId, "turretFitted")).length;
	const launchers = mods.filter((m) => sde.hasEffect(m.typeId, "launcherFitted")).length;
	const activeDrones = d.drones.filter((x) => !isFighter(sde, x.item.typeId)).reduce((a, x) => a + x.item.get("droneBandwidthUsed") * x.count, 0);
	const volume = (typeId) => sde.baseAttr(typeId, sde.attrId("volume"));
	const bayVolume = fit.drones.filter((x) => !isFighter(sde, x.typeId)).reduce((a, x) => a + volume(x.typeId) * x.count, 0);
	const squads = fit.drones.filter((x) => isFighter(sde, x.typeId));
	const squadSize = (typeId) => sde.baseAttr(typeId, sde.attrId("fighterSquadronMaxSize")) || 1;
	const fighterVolume = squads.reduce((a, x) => a + volume(x.typeId) * squadSize(x.typeId) * x.count, 0);
	const launchedSquads = squads.filter((x) => x.active > 0);
	const squadsOf = (attr) => launchedSquads.filter((x) => sde.baseAttr(x.typeId, sde.attrId(attr)) > 0).reduce((a, x) => a + x.active, 0);
	const slots = Object.fromEntries(SLOT_KINDS.map((k) => [k, {
		used: fit.slots[k].filter(Boolean).length,
		total: counts[k]
	}]));
	return {
		cpu: {
			used: mods.filter(isOnline).reduce((a, m) => a + m.get("cpu"), 0),
			total: ship.get("cpuOutput")
		},
		power: {
			used: mods.filter(isOnline).reduce((a, m) => a + m.get("power"), 0),
			total: ship.get("powerOutput")
		},
		calibration: {
			used: mods.reduce((a, m) => a + m.get("upgradeCost"), 0),
			total: ship.get("upgradeCapacity")
		},
		droneBandwidth: {
			used: activeDrones,
			total: ship.get("droneBandwidth")
		},
		droneBay: {
			used: bayVolume,
			total: ship.get("droneCapacity")
		},
		fighterBay: {
			used: fighterVolume,
			total: ship.get("fighterCapacity")
		},
		cargo: {
			used: fit.cargo.reduce((a, x) => a + volume(x.typeId) * x.count, 0),
			total: ship.get("capacity")
		},
		fighterTubes: {
			used: launchedSquads.reduce((a, x) => a + x.active, 0),
			total: Math.round(ship.get("fighterTubes"))
		},
		fighterLight: {
			used: squadsOf("fighterSquadronIsLight"),
			total: Math.round(ship.get("fighterLightSlots"))
		},
		fighterSupport: {
			used: squadsOf("fighterSquadronIsSupport"),
			total: Math.round(ship.get("fighterSupportSlots"))
		},
		fighterHeavy: {
			used: squadsOf("fighterSquadronIsHeavy"),
			total: Math.round(ship.get("fighterHeavySlots"))
		},
		turrets: {
			used: turrets,
			total: Math.round(ship.get("turretSlotsLeft"))
		},
		launchers: {
			used: launchers,
			total: Math.round(ship.get("launcherSlotsLeft"))
		},
		slots
	};
}
function validate(sde, fit, d, r) {
	const out = [];
	const over = (res, label) => {
		if (res.used > res.total + 1e-6) out.push(tx("{label} depășit: {used} / {total}", {
			label,
			used: round(res.used),
			total: round(res.total)
		}));
	};
	over(r.cpu, "CPU");
	over(r.power, "Powergrid");
	over(r.calibration, "Calibration");
	over(r.droneBandwidth, "Drone bandwidth");
	over(r.droneBay, "Drone bay");
	over(r.fighterBay, "Fighter bay");
	over(r.fighterTubes, "Fighter tubes");
	over(r.fighterLight, "Light fighters");
	over(r.fighterSupport, "Support fighters");
	over(r.fighterHeavy, "Heavy fighters");
	over(r.turrets, "Turret hardpoints");
	over(r.launchers, "Launcher hardpoints");
	for (const k of SLOT_KINDS) over(r.slots[k], tx("Sloturi {k}", { k }));
	const maxDrones = d.character.get("maxActiveDrones");
	const launched = fit.drones.filter((x) => !isFighter(sde, x.typeId)).reduce((a, x) => a + x.active, 0);
	if (launched > maxDrones) out.push(tx("Prea multe drone lansate: {n} / {max} (skill-ul Drones)", {
		n: launched,
		max: maxDrones
	}));
	const byGroup = /* @__PURE__ */ new Map();
	for (const m of d.modules) byGroup.set(m.groupId, (byGroup.get(m.groupId) ?? 0) + 1);
	for (const m of d.modules) {
		const max = sde.baseAttr(m.typeId, sde.attrId("maxGroupFitted"));
		if (max > 0 && (byGroup.get(m.groupId) ?? 0) > max) {
			out.push(tx("Maxim {max} × {group} pe navă", {
				max,
				group: sde.groups.get(m.groupId)?.name ?? tx("grup")
			}));
			byGroup.set(m.groupId, 0);
		}
	}
	const activeByGroup = /* @__PURE__ */ new Map();
	for (const m of d.modules.filter((x) => x.state === "active" || x.state === "overheated")) activeByGroup.set(m.groupId, (activeByGroup.get(m.groupId) ?? 0) + 1);
	for (const [g, n] of activeByGroup) {
		const sample = d.modules.find((m) => m.groupId === g);
		const max = sde.baseAttr(sample.typeId, sde.attrId("maxGroupActive"));
		if (max > 0 && n > max) out.push(tx("Maxim {max} × {group} activ", {
			max,
			group: sde.groups.get(g)?.name ?? tx("grup")
		}));
	}
	return out;
}
const FIGHTER_ABILITIES = [{
	effect: "fighterAbilityAttackM",
	prefix: "fighterAbilityAttackMissileDamage",
	multiplier: "fighterAbilityAttackMissileDamageMultiplier",
	duration: "fighterAbilityAttackMissileDuration",
	range: "fighterAbilityAttackMissileRangeOptimal"
}, {
	effect: "fighterAbilityMissiles",
	prefix: "fighterAbilityMissilesDamage",
	multiplier: "fighterAbilityMissilesDamageMultiplier",
	duration: "fighterAbilityMissilesDuration",
	range: "fighterAbilityMissilesRange"
}];
const TURRET_EFFECTS = [
	"targetAttack",
	"projectileFired",
	"targetDisintegratorAttack"
];
function chargeDamage(charge) {
	const out = zero();
	if (!charge) return out;
	for (const t of DAMAGE_TYPES) out[t] = charge.get(DAMAGE_ATTR[t]);
	return out;
}
function offense(sde, d) {
	const weapons = [];
	const push = (w) => {
		const same = weapons.find((x) => x.name === w.name && x.kind === w.kind);
		if (same) {
			same.count += w.count;
			same.volley = add(same.volley, w.volley);
			same.dps = add(same.dps, w.dps);
		} else weapons.push(w);
	};
	for (const m of d.modules) {
		if (m.state !== "active" && m.state !== "overheated") continue;
		const cycle = m.get("speed") / 1e3;
		if (cycle <= 0) continue;
		const label = m.other ? `${m.type.name} · ${m.other.type.name}` : m.type.name;
		if (TURRET_EFFECTS.some((e) => sde.hasEffect(m.typeId, e)) && m.other) {
			const volley = scale(chargeDamage(m.other), m.get("damageMultiplier"));
			push({
				name: label,
				count: 1,
				kind: "turret",
				volley,
				dps: scale(volley, 1 / cycle),
				range: m.get("maxRange"),
				falloff: m.get("falloff")
			});
		} else if (sde.hasEffect(m.typeId, "useMissiles") && m.other) {
			const volley = scale(chargeDamage(m.other), d.character.get("missileDamageMultiplier"));
			const range = m.other.get("maxVelocity") * (m.other.get("explosionDelay") / 1e3);
			push({
				name: label,
				count: 1,
				kind: "missile",
				volley,
				dps: scale(volley, 1 / cycle),
				range
			});
		}
	}
	for (const { item, count } of d.drones) {
		if (isFighter(sde, item.typeId)) {
			const size = item.get("fighterSquadronMaxSize") || 1;
			let volley = zero();
			let dps = zero();
			let range = 0;
			for (const ab of FIGHTER_ABILITIES) {
				if (!sde.hasEffect(item.typeId, ab.effect)) continue;
				const seconds = item.get(ab.duration) / 1e3;
				if (seconds <= 0) continue;
				const v = scale({
					em: item.get(ab.prefix + "EM"),
					thermal: item.get(ab.prefix + "Therm"),
					kinetic: item.get(ab.prefix + "Kin"),
					explosive: item.get(ab.prefix + "Exp")
				}, (item.get(ab.multiplier) || 1) * size * count);
				volley = add(volley, v);
				dps = add(dps, scale(v, 1 / seconds));
				range = Math.max(range, ab.range ? item.get(ab.range) : 0);
			}
			if (sum(dps) > 0) push({
				name: item.type.name,
				count,
				kind: "fighter",
				volley,
				dps,
				range: range || void 0
			});
			continue;
		}
		if (!sde.hasEffect(item.typeId, "targetAttack") && !sde.hasEffect(item.typeId, "projectileFired")) continue;
		const cycle = item.get("speed") / 1e3;
		if (cycle <= 0) continue;
		const volley = scale(chargeDamage(item), item.get("damageMultiplier") * count);
		push({
			name: item.type.name,
			count,
			kind: "drone",
			volley,
			dps: scale(volley, 1 / cycle),
			range: item.get("maxRange")
		});
	}
	const weaponDps = weapons.filter((w) => w.kind !== "drone" && w.kind !== "fighter").reduce((a, w) => a + sum(w.dps), 0);
	const droneDps = weapons.filter((w) => w.kind === "drone" || w.kind === "fighter").reduce((a, w) => a + sum(w.dps), 0);
	return {
		weapons,
		weaponDps,
		droneDps,
		totalDps: weaponDps + droneDps,
		totalVolley: weapons.reduce((a, w) => a + sum(w.volley), 0),
		dps: weapons.reduce((a, w) => add(a, w.dps), zero())
	};
}
const LAYERS = [
	"shield",
	"armor",
	"hull"
];
const RESONANCE = {
	shield: {
		em: "shieldEmDamageResonance",
		thermal: "shieldThermalDamageResonance",
		kinetic: "shieldKineticDamageResonance",
		explosive: "shieldExplosiveDamageResonance"
	},
	armor: {
		em: "armorEmDamageResonance",
		thermal: "armorThermalDamageResonance",
		kinetic: "armorKineticDamageResonance",
		explosive: "armorExplosiveDamageResonance"
	},
	hull: {
		em: "emDamageResonance",
		thermal: "thermalDamageResonance",
		kinetic: "kineticDamageResonance",
		explosive: "explosiveDamageResonance"
	}
};
const HP_ATTR = {
	shield: "shieldCapacity",
	armor: "armorHP",
	hull: "hp"
};
function profileWeights(p) {
	const total = p.em + p.thermal + p.kinetic + p.explosive || 1;
	return {
		em: p.em / total,
		thermal: p.thermal / total,
		kinetic: p.kinetic / total,
		explosive: p.explosive / total
	};
}
function defense(sde, d, profile) {
	const ship = d.ship;
	const w = profileWeights(profile);
	const layers = {};
	const factor = {};
	for (const l of LAYERS) {
		const res = zero();
		let f = 0;
		for (const t of DAMAGE_TYPES) {
			const resonance = ship.get(RESONANCE[l][t]);
			res[t] = 1 - resonance;
			f += w[t] * resonance;
		}
		factor[l] = f || 1;
		const hp = ship.get(HP_ATTR[l]);
		layers[l] = {
			hp,
			resists: res,
			ehp: hp / factor[l]
		};
	}
	const repairs = {
		shield: {
			raw: 0,
			effective: 0
		},
		armor: {
			raw: 0,
			effective: 0
		},
		hull: {
			raw: 0,
			effective: 0
		}
	};
	for (const m of d.modules) {
		if (m.state !== "active" && m.state !== "overheated") continue;
		const cycle = m.get("duration") / 1e3;
		if (cycle <= 0) continue;
		if (sde.hasEffect(m.typeId, "shieldBoosting") || sde.hasEffect(m.typeId, "fueledShieldBoosting")) repairs.shield.raw += m.get("shieldBonus") / cycle;
		else if (sde.hasEffect(m.typeId, "armorRepair")) repairs.armor.raw += m.get("armorDamageAmount") / cycle;
		else if (sde.hasEffect(m.typeId, "fueledArmorRepair")) {
			const paste = m.other ? m.get("chargedArmorDamageMultiplier") || 1 : 1;
			repairs.armor.raw += m.get("armorDamageAmount") * paste / cycle;
		} else if (sde.hasEffect(m.typeId, "structureRepair")) repairs.hull.raw += m.get("structureDamageAmount") / cycle;
	}
	const flow = projectedFlow(d);
	repairs.shield.raw += flow.shield;
	repairs.armor.raw += flow.armor;
	repairs.hull.raw += flow.hull;
	for (const l of LAYERS) repairs[l].effective = repairs[l].raw / factor[l];
	const rechargeSec = ship.get("shieldRechargeRate") / 1e3;
	const passiveRaw = rechargeSec > 0 ? 2.5 * layers.shield.hp / rechargeSec : 0;
	const passiveShield = {
		raw: passiveRaw,
		effective: passiveRaw / factor.shield
	};
	return {
		layers,
		hp: LAYERS.reduce((a, l) => a + layers[l].hp, 0),
		ehp: LAYERS.reduce((a, l) => a + layers[l].ehp, 0),
		repairs,
		passiveShield,
		activeTank: LAYERS.reduce((a, l) => a + repairs[l].effective, 0)
	};
}
function capacitor(sde, d) {
	const ship = d.ship;
	const drains = [];
	const cycles = [];
	for (const m of d.modules) {
		if (m.state !== "active" && m.state !== "overheated") continue;
		const effect = activeEffect(sde, m);
		if (!effect) continue;
		const duration = effect.durationAttributeId ? m.attr(effect.durationAttributeId) / 1e3 : 0;
		if (duration <= 0) continue;
		const need = effect.dischargeAttributeId ? m.attr(effect.dischargeAttributeId) : 0;
		if (need !== 0) {
			drains.push({
				name: m.type.name,
				perSecond: need / duration
			});
			cycles.push({
				need,
				duration
			});
		}
		if (effect.name === "powerBooster" && m.other) {
			drains.push({
				name: `${m.type.name} · ${m.other.type.name}`,
				perSecond: -m.other.get("capacitorBonus") / duration
			});
			cycles.push({
				need: -m.other.get("capacitorBonus"),
				duration
			});
		}
	}
	for (const p of projectedCapCycles(d)) {
		drains.push({
			name: p.name,
			perSecond: p.need / p.duration
		});
		cycles.push({
			need: p.need,
			duration: p.duration
		});
	}
	const usage = drains.reduce((a, x) => a + x.perSecond, 0);
	const grossUsage = drains.reduce((a, x) => a + Math.max(0, x.perSecond), 0);
	return {
		...simulateCapacitor(ship.get("capacitorCapacity"), ship.get("rechargeRate") / 1e3, usage, cycles),
		drains,
		grossUsage
	};
}
function activeEffect(sde, m) {
	return m.type.effects.map((id) => sde.effects.get(id)).find((e) => e && (e.category === 1 || e.category === 2) && e.durationAttributeId);
}
function navigation(d) {
	const ship = d.ship;
	const mass = ship.get("mass");
	const agility = ship.get("agility");
	return {
		maxVelocity: ship.get("maxVelocity"),
		mass,
		agility,
		alignTime: -Math.log(.25) * agility * mass / 1e6,
		warpSpeed: ship.get("warpSpeedMultiplier") * ship.get("baseWarpSpeed"),
		signatureRadius: ship.get("signatureRadius")
	};
}
function targeting(d) {
	const ship = d.ship;
	const [sensorType, sensorStrength] = [
		["Radar", ship.get("scanRadarStrength")],
		["Ladar", ship.get("scanLadarStrength")],
		["Magnetometric", ship.get("scanMagnetometricStrength")],
		["Gravimetric", ship.get("scanGravimetricStrength")]
	].reduce((a, b) => b[1] > a[1] ? b : a);
	return {
		maxRange: ship.get("maxTargetRange"),
		scanResolution: ship.get("scanResolution"),
		maxLocked: Math.min(ship.get("maxLockedTargets"), d.character.get("maxLockedTargets") || Infinity),
		sensorStrength,
		sensorType
	};
}
function heat(d) {
	return d.modules.filter((m) => m.state === "overheated").map((m) => {
		const damage = m.get("heatDamage");
		const hp = m.get("hp");
		const cycle = (m.get("speed") || m.get("duration")) / 1e3;
		return {
			name: m.type.name,
			slotKey: m.slotKey ?? "",
			damage,
			hp,
			cycle,
			cycles: damage > 0 ? Math.ceil(hp / damage) : Infinity
		};
	});
}
function computeStats(sde, fit, d, profile) {
	const res = resources(sde, fit, d);
	return {
		resources: res,
		warnings: validate(sde, fit, d, res),
		offense: offense(sde, d),
		defense: defense(sde, d, profile),
		capacitor: capacitor(sde, d),
		navigation: navigation(d),
		targeting: targeting(d),
		heat: heat(d)
	};
}
function round(n) {
	return Math.round(n * 100) / 100;
}
// src/engine/mutation.ts
function mutationRows(sde, m) {
	const mp = m.mutation && sde.mutaplasmids.get(m.mutation.mutaplasmidId);
	if (!mp) return [];
	return [...mp.ranges].flatMap(([attrId, [lo, hi]]) => {
		const base = sde.baseAttr(m.typeId, attrId);
		if (!base) return [];
		const a = sde.attributes.get(attrId);
		const [min, max] = [base * lo, base * hi].sort((x, y) => x - y);
		return [{
			attrId,
			name: a?.displayName || a?.name || String(attrId),
			base,
			min,
			max,
			value: m.mutation.values[attrId] ?? base,
			highIsGood: a?.highIsGood ?? true
		}];
	});
}
function mutate(sde, m, mp) {
	const values = {};
	for (const [attrId, [lo, hi]] of mp.ranges) {
		const base = sde.baseAttr(m.typeId, attrId);
		if (!base) continue;
		const [min, max] = [base * lo, base * hi].sort((x, y) => x - y);
		values[attrId] = Math.min(max, Math.max(min, base));
	}
	m.mutation = {
		mutaplasmidId: mp.id,
		values
	};
}
// src/io/eft.ts
function readMutations(lines) {
	const blocks = /* @__PURE__ */ new Map();
	const used = /* @__PURE__ */ new Set();
	for (let i = 0; i < lines.length; i++) {
		const head = lines[i].match(/^\[(\d+)\]\s+(.+)$/);
		if (!head || /\]$/.test(lines[i])) continue;
		const block = { attrs: /* @__PURE__ */ new Map() };
		used.add(i);
		const rest = [];
		for (let j = i + 1; j < lines.length && rest.length < 3 && lines[j]; j++) {
			rest.push(lines[j]);
			used.add(j);
		}
		block.base = rest[0];
		block.mutaplasmid = rest[1];
		for (const part of (rest[2] ?? "").split(",")) {
			const m = part.trim().match(/^(\S+)\s+(-?[\d.eE+-]+)$/);
			if (m) block.attrs.set(m[1], Number(m[2]));
		}
		blocks.set(Number(head[1]), block);
	}
	return {
		blocks,
		used
	};
}
function applyBlock(sde, m, block) {
	if (!block?.mutaplasmid) return;
	const mp = [...sde.mutaplasmids.values()].find((x) => x.name.toLowerCase() === block.mutaplasmid.toLowerCase());
	if (!mp || !mp.resultFor.has(m.typeId)) return;
	mutate(sde, m, mp);
	for (const row of mutationRows(sde, m)) {
		const name = sde.attributes.get(row.attrId)?.name;
		const v = name ? block.attrs.get(name) : void 0;
		if (v != null) m.mutation.values[row.attrId] = Math.min(row.max, Math.max(row.min, v));
	}
}
const EMPTY_LABEL = {
	low: "Low",
	mid: "Med",
	high: "High",
	rig: "Rig",
	subsystem: "Subsystem"
};
function parseEft(sde, text) {
	const lines = text.replace(/\r/g, "").split("\n").map((l) => l.trim());
	const headerIdx = lines.findIndex((l) => /^\[.+\]$/.test(l));
	if (headerIdx < 0) throw new Error(tx("Nu găsesc antetul EFT, de forma [Navă, Nume fit]."));
	const header = lines[headerIdx].slice(1, -1);
	const comma = header.indexOf(",");
	const shipName = (comma >= 0 ? header.slice(0, comma) : header).trim();
	const fitName = comma >= 0 ? header.slice(comma + 1).trim() : shipName;
	const ship = sde.findType(shipName);
	if (!ship || ship.categoryId !== Category.Ship) throw new Error(tx("Nava „{name}” nu există în date.", { name: shipName }));
	const fit = emptyFit(ship.id, fitName || shipName);
	const unknown = [];
	const { blocks, used } = readMutations(lines);
	for (let idx = headerIdx + 1; idx < lines.length; idx++) {
		const raw = lines[idx];
		if (!raw || used.has(idx)) continue;
		if (/^\[Empty .+ slot\]$/i.test(raw)) {
			const m = raw.match(/^\[Empty (\w+) slot\]$/i);
			const kind = Object.keys(EMPTY_LABEL).find((k) => EMPTY_LABEL[k].toLowerCase() === m?.[1].toLowerCase());
			if (kind) fit.slots[kind].push(null);
			continue;
		}
		let line = raw;
		const offline = /\/\s*offline$/i.test(line);
		line = line.replace(/\/\s*offline$/i, "").trim();
		const ref = line.match(/\s*\[(\d+)\]/);
		if (ref) line = line.replace(ref[0], "").trim();
		const block = ref ? blocks.get(Number(ref[1])) : void 0;
		const qty = line.match(/^(.*?)\s+x(\d+)$/i);
		if (qty) {
			const t = sde.findType(qty[1]);
			const count = Number(qty[2]);
			if (!t) {
				unknown.push(raw);
				continue;
			}
			if (t.categoryId === Category.Fighter) fit.drones.push({
				typeId: t.id,
				count: squadsFromFighters(sde, t.id, count),
				active: 0
			});
			else if (t.categoryId === Category.Drone) fit.drones.push({
				typeId: t.id,
				count,
				active: 0
			});
			else fit.cargo.push({
				typeId: t.id,
				count
			});
			continue;
		}
		const [modName, chargeName] = line.split(",").map((s) => s.trim());
		let t = sde.findType(modName);
		if (t && sde.isAbyssal(t.id)) t = block?.base && sde.findType(block.base) || sde.types.get(sde.abyssalBases(t.id)[0]) || t;
		if (!t) {
			unknown.push(raw);
			continue;
		}
		if (t.categoryId === Category.Implant) {
			fit.implants.push(t.id);
			continue;
		}
		if (t.groupId === 1306) {
			if (sde.modesFor(ship.id).some((m) => m.id === t.id)) fit.mode = t.id;
			else unknown.push(raw);
			continue;
		}
		const kind = slotOf(sde, t.id);
		if (!kind) {
			fit.cargo.push({
				typeId: t.id,
				count: 1
			});
			continue;
		}
		const charge = chargeName ? sde.findType(chargeName) : void 0;
		if (chargeName && !charge) unknown.push(raw);
		const mod = {
			typeId: t.id,
			state: offline ? "offline" : defaultState(sde, t.id),
			chargeId: charge && canLoadCharge(sde, t.id, charge.id) ? charge.id : void 0
		};
		applyBlock(sde, mod, block);
		fit.slots[kind].push(mod);
	}
	launchDrones(sde, fit);
	return {
		fit,
		unknown
	};
}
// src/services/realFits.ts
function toT2(sde, typeId) {
	const t = sde.types.get(typeId);
	if (!t || t.metaGroupId === 2) return typeId;
	return sde.variations(typeId).find((v) => v.metaGroupId === 2)?.id ?? typeId;
}
function factionOf(sde, typeId) {
	return sde.variations(typeId).filter((v) => v.metaGroupId === 4).map((v) => v.id);
}
function t1Of(sde, typeId, original) {
	const list = sde.variations(typeId);
	return (list.find((v) => v.variationParentId == null && v.metaGroupId !== 2) ?? list.find((v) => v.metaGroupId === 1))?.id ?? original;
}
function metaOf(sde, typeId) {
	return sde.variations(typeId).filter((v) => (v.metaGroupId === 1 || v.variationParentId == null && v.metaGroupId !== 2) && !/\bCivilian\b/.test(v.name)).map((v) => v.id);
}
const excess = (r) => Math.max(0, r.used - r.total) / Math.max(r.total, 1);
const fittingExcess = (r) => excess(r.cpu) + excess(r.power);
const calibrationExcess = (r) => excess(r.calibration);
function swapUntilFits(fit, measure, positions, choices, score) {
	const open = [...positions];
	let current = score(measure());
	let swaps = 0;
	while (current > 1e-9 && open.length) {
		let best = null;
		open.forEach((p, index) => {
			const m = fit.slots[p.k][p.i];
			const keep = m.typeId;
			for (const typeId of choices(p)) {
				if (typeId === keep) continue;
				m.typeId = typeId;
				const value = score(measure());
				if (!best || value < best.value) best = {
					index,
					typeId,
					value
				};
			}
			m.typeId = keep;
		});
		const chosen = best;
		if (!chosen || chosen.value >= current - 1e-9) break;
		const p = open.splice(chosen.index, 1)[0];
		fit.slots[p.k][p.i].typeId = chosen.typeId;
		current = chosen.value;
		swaps++;
	}
	return swaps;
}
function removeExtraModules(sde, fit, measure) {
	let removed = 0;
	const dropLast = (k, match) => {
		const list = fit.slots[k];
		for (let i = list.length - 1; i >= 0; i--) {
			const m = list[i];
			if (m && match(m.typeId)) {
				list[i] = null;
				removed++;
				return true;
			}
		}
		return false;
	};
	for (let guard = 0; guard < 40; guard++) {
		const r = measure();
		const k = SLOT_KINDS.find((x) => x !== "subsystem" && r.slots[x].used > r.slots[x].total);
		if (k) {
			if (!dropLast(k, () => true)) break;
			continue;
		}
		if (r.turrets.used > r.turrets.total) {
			if (!dropLast("high", (id) => sde.hasEffect(id, "turretFitted"))) break;
			continue;
		}
		if (r.launchers.used > r.launchers.total) {
			if (!dropLast("high", (id) => sde.hasEffect(id, "launcherFitted"))) break;
			continue;
		}
		break;
	}
	return removed;
}
function trimBays(sde, fit, measure) {
	let trimmed = false;
	for (let guard = 0; guard < 200; guard++) {
		const r = measure();
		const bay = r.droneBay.used > r.droneBay.total + 1e-6 ? (id) => sde.types.get(id)?.categoryId === Category.Drone : r.fighterBay.used > r.fighterBay.total + 1e-6 ? (id) => sde.types.get(id)?.categoryId === Category.Fighter : null;
		if (!bay) break;
		const d = [...fit.drones].reverse().find((x) => bay(x.typeId) && x.count > 0);
		if (!d) break;
		d.count--;
		d.active = Math.min(d.active, d.count);
		trimmed = true;
	}
	fit.drones = fit.drones.filter((d) => d.count > 0);
	for (let guard = 0; guard < 50; guard++) {
		const r = measure();
		if (r.droneBandwidth.used <= r.droneBandwidth.total + 1e-6) break;
		const d = [...fit.drones].reverse().find((x) => x.active > 0 && sde.types.get(x.typeId)?.categoryId === Category.Drone);
		if (!d) break;
		d.active--;
	}
	for (let guard = 0; guard < 20; guard++) {
		const r = measure();
		if (r.cargo.used <= r.cargo.total + 1e-6 || !fit.cargo.length) break;
		const factor = r.cargo.total / r.cargo.used;
		for (const c of fit.cargo) c.count = Math.floor(c.count * factor);
		fit.cargo = fit.cargo.filter((c) => c.count > 0);
		trimmed = true;
	}
	return trimmed;
}
const DAMAGE_ATTRS = [
	"emDamage",
	"thermalDamage",
	"kineticDamage",
	"explosiveDamage"
];
function damageOf(sde, typeId) {
	return DAMAGE_ATTRS.filter((n) => sde.hasAttr(n)).reduce((a, n) => a + sde.baseAttr(typeId, sde.attrId(n)), 0);
}
function strongest(sde, ids) {
	return [...ids].sort((a, b) => damageOf(sde, b) - damageOf(sde, a) || sde.type(a).name.localeCompare(sde.type(b).name))[0];
}
function upgradeCharge(sde, chargeId, fits) {
	const t = sde.types.get(chargeId);
	if (!t || t.metaGroupId === 2) return chargeId;
	const variants = sde.variations(chargeId).filter((v) => fits(v.id));
	const pick = (meta) => strongest(sde, variants.filter((v) => v.metaGroupId === meta).map((v) => v.id));
	if (t.metaGroupId === 4) return pick(2) ?? chargeId;
	return pick(2) ?? pick(4) ?? chargeId;
}
let chargePool = null;
function chargeFor(sde, moduleId, only) {
	chargePool ??= sde.typesInCategory(Category.Charge).filter((c) => c.metaGroupId === 2 || c.metaGroupId === 4).map((c) => c.id);
	const fit = chargePool.filter((id) => canLoadCharge(sde, moduleId, id) && (only == null || sde.types.get(id)?.metaGroupId === only));
	return strongest(sde, fit.filter((id) => sde.types.get(id)?.metaGroupId === 2)) ?? strongest(sde, fit.filter((id) => sde.types.get(id)?.metaGroupId === 4));
}
function loadCharges(sde, fit) {
	const cargo = /* @__PURE__ */ new Map();
	for (const c of fit.cargo) {
		const id = sde.types.get(c.typeId)?.categoryId === Category.Charge ? upgradeCharge(sde, c.typeId, () => true) : c.typeId;
		cargo.set(id, (cargo.get(id) ?? 0) + c.count);
	}
	const fromCargo = (moduleId) => [...cargo].filter(([id]) => canLoadCharge(sde, moduleId, id)).sort((a, b) => b[1] - a[1])[0]?.[0];
	for (const k of SLOT_KINDS) for (const m of fit.slots[k]) {
		if (!m) continue;
		const weapon = sde.hasEffect(m.typeId, "turretFitted") || sde.hasEffect(m.typeId, "launcherFitted");
		if (m.chargeId) m.chargeId = upgradeCharge(sde, m.chargeId, (id) => canLoadCharge(sde, m.typeId, id));
		else if (weapon) m.chargeId = fromCargo(m.typeId) ?? chargeFor(sde, m.typeId);
		if (weapon && m.chargeId && sde.types.get(m.chargeId)?.metaGroupId !== 2) m.chargeId = chargeFor(sde, m.typeId, 2) ?? m.chargeId;
	}
	const loaded = /* @__PURE__ */ new Map();
	for (const k of SLOT_KINDS) for (const m of fit.slots[k]) {
		if (!m?.chargeId) continue;
		const rounds = Math.floor(sde.baseAttr(m.typeId, sde.attrId("capacity")) / Math.max(sde.baseAttr(m.chargeId, sde.attrId("volume")), 1e-6));
		loaded.set(m.chargeId, (loaded.get(m.chargeId) ?? 0) + Math.max(1, rounds) * 10);
	}
	for (const [id, n] of loaded) if (!cargo.has(id)) cargo.set(id, n);
	fit.cargo = [...cargo].map(([typeId, count]) => ({
		typeId,
		count
	}));
}
function keepWithinLimits(sde, fit, upgraded) {
	const skills = allLevels(sde, 5).skills;
	const measure = () => resources(sde, fit, new Dogma(sde, toDogmaInput(sde, fit, skills)));
	const removed = removeExtraModules(sde, fit, measure);
	const originals = new Map(upgraded.map((p) => [`${p.k}:${p.i}`, p.original]));
	const positions = (rig) => SLOT_KINDS.filter((k) => k !== "subsystem" && k === "rig" === rig).flatMap((k) => fit.slots[k].map((m, i) => m && !m.mutation ? {
		k,
		i,
		original: originals.get(`${k}:${i}`) ?? m.typeId
	} : null)).filter((p) => !!p);
	const typeAt = (p) => fit.slots[p.k][p.i].typeId;
	const rigs = swapUntilFits(fit, measure, positions(true), (p) => [t1Of(sde, typeAt(p), p.original), ...metaOf(sde, typeAt(p))], calibrationExcess);
	const faction = swapUntilFits(fit, measure, positions(false), (p) => factionOf(sde, typeAt(p)), fittingExcess);
	const meta = swapUntilFits(fit, measure, positions(false).filter((p) => p.original !== typeAt(p)), (p) => [p.original], fittingExcess) + swapUntilFits(fit, measure, positions(false), (p) => metaOf(sde, typeAt(p)), fittingExcess);
	const trimmed = trimBays(sde, fit, measure);
	const r = measure();
	return {
		faction,
		meta,
		rigs,
		removed,
		trimmed,
		valid: fittingExcess(r) + calibrationExcess(r) < 1e-9 && SLOT_KINDS.every((k) => r.slots[k].used <= r.slots[k].total) && r.turrets.used <= r.turrets.total && r.launchers.used <= r.launchers.total
	};
}
function prepareFit(sde, shipId, kind, entry) {
	const { fit } = parseEft(sde, entry.eft);
	if (fit.shipId !== shipId) return null;
	const upgraded = [];
	for (const k of SLOT_KINDS) {
		if (k === "subsystem") continue;
		fit.slots[k].forEach((m, i) => {
			if (!m || m.mutation) return;
			const t2 = toT2(sde, m.typeId);
			if (t2 !== m.typeId) {
				upgraded.push({
					k,
					i,
					original: m.typeId
				});
				m.typeId = t2;
			}
		});
	}
	for (const d of fit.drones) if (sde.types.get(d.typeId)?.categoryId === Category.Drone) d.typeId = toT2(sde, d.typeId);
	loadCharges(sde, fit);
	const swaps = keepWithinLimits(sde, fit, upgraded);
	if (!swaps.valid) return null;
	const label = kind === "pve" ? "PvE" : "PvP";
	const title = entry.title?.trim() || fit.name;
	fit.name = `${sde.type(shipId).name} ${label}`;
	const generated = entry.source === "generated";
	const notes = [generated ? tx("Fit {kind} compus din bonusurile și statisticile navei, pentru că nu există un fit publicat. Modulele care au variantă T2 au fost trecute pe T2.", { kind: label }) : tx("Fit publicat: „{title}”, sursa {url} . Modulele care au variantă T2 au fost trecute pe T2.", {
		title,
		url: entry.source
	})];
	notes.push(tx("Charges sunt T2 unde există, altfel faction."));
	if (swaps.removed) notes.push(tx("Am scos modulele care nu aveau sloturi sau hardpoints libere pe navă ({n}).", { n: swaps.removed }));
	if (swaps.faction) notes.push(tx("Ca să încapă în CPU și powergrid cu toate skill-urile la V, unele module au trecut pe varianta faction ({n}).", { n: swaps.faction }));
	if (swaps.meta) notes.push(tx("Unde nici faction nu a ajuns, unele module au rămas T1 sau meta ({n}).", { n: swaps.meta }));
	if (swaps.rigs) notes.push(tx("Ca să încapă în calibration, unele rig-uri au rămas T1 ({n}).", { n: swaps.rigs }));
	if (swaps.trimmed) notes.push(tx("Am redus dronele și încărcătura din cargo ca să încapă în bay."));
	fit.notes = notes.join(" ");
	return {
		fit,
		source: entry.source,
		title,
		generated
	};
}
// src/engine/profiles.ts
const p = (group, name, em, thermal, kinetic, explosive) => ({
	id: `${group}/${name}`,
	name,
	group,
	em,
	thermal,
	kinetic,
	explosive
});
const UNIFORM = p("Generic", "Uniform", 25, 25, 25, 25);
const DAMAGE_PROFILES = [
	UNIFORM,
	p("Generic", "EM", 1, 0, 0, 0),
	p("Generic", "Thermal", 0, 1, 0, 0),
	p("Generic", "Kinetic", 0, 0, 1, 0),
	p("Generic", "Explosive", 0, 0, 0, 1),
	p("Abyssal", "All", 126, 427, 218, 230),
	p("Abyssal", "Angel", 450, 72, 80, 398),
	p("Abyssal", "Concord", 53, 559, 94, 295),
	p("Abyssal", "Drifter", 250, 250, 250, 250),
	p("Abyssal", "Drones", 250, 250, 250, 250),
	p("Abyssal", "Overmind", 0, 410, 590, 0),
	p("Abyssal", "Sansha", 569, 431, 0, 0),
	p("Abyssal", "Seeker", 402, 402, 98, 98),
	p("Abyssal", "Sleeper", 313, 313, 187, 187),
	p("Abyssal", "Triglavian", 0, 615, 0, 385),
	p("Asteroid", "Angel Cartel", 1838, 562, 2215, 3838),
	p("Asteroid", "Blood Raiders", 5067, 4214, 0, 0),
	p("Asteroid", "Guristas", 0, 1828, 7413, 0),
	p("Asteroid", "Rogue Drone", 394, 666, 1090, 1687),
	p("Asteroid", "Sanshas Nation", 5586, 4112, 0, 0),
	p("Asteroid", "Serpentis", 0, 5373, 4813, 0),
	p("Deadspace", "Angel Cartel", 369, 533, 1395, 3302),
	p("Deadspace", "Blood Raiders", 6040, 5052, 10, 15),
	p("Deadspace", "Guristas", 0, 1531, 9680, 0),
	p("Deadspace", "Rogue Drone", 276, 1071, 1069, 871),
	p("Deadspace", "Sanshas Nation", 3009, 2237, 0, 0),
	p("Deadspace", "Serpentis", 0, 3110, 1929, 0),
	p("Invasion", "Triglavian Subcaps", 0, 610, 0, 390),
	p("Invasion", "Drifter Entities", 250, 250, 250, 250),
	p("Invasion", "Sleeper Entities", 265, 265, 235, 235),
	p("Invasion", "Rogue Drone Entities", 250, 250, 250, 250),
	p("Mission", "Amarr Empire", 4464, 3546, 97, 0),
	p("Mission", "Caldari State", 0, 2139, 4867, 0),
	p("Mission", "CONCORD", 336, 134, 212, 412),
	p("Mission", "Gallente Federation", 9, 3712, 2758, 0),
	p("Mission", "Khanid", 612, 483, 43, 6),
	p("Mission", "Minmatar Republic", 1024, 388, 1655, 4285),
	p("Mission", "Mordus Legion", 25, 262, 625, 0),
	p("Mission", "Thukker", 0, 52, 10, 79),
	p("NPC", "Sansha Incursion", 1682, 1347, 3678, 3678),
	p("NPC", "Sleepers", 1472, 1472, 1384, 1384)
];
function findProfile(id) {
	return DAMAGE_PROFILES.find((x) => x.id === id) ?? UNIFORM;
}
// data/fits/q2.ts
const sde = new Sde(JSON.parse(fs.readFileSync(process.argv[2], "utf8")));
const CACHE = process.argv[3];
const traits = JSON.parse(fs.readFileSync(process.argv[5], "utf8"));
const onlyShips = process.argv[6] ? new Set(process.argv[6].split(",")) : null;
const oldFits = JSON.parse(fs.readFileSync(process.argv[4], "utf8"));
const ch = allLevels(sde, 5);
const profile = findProfile("Generic/Uniform");
const SHIELD = /* @__PURE__ */ new Set([
	"Shield Extender",
	"Shield Booster",
	"Ancillary Shield Booster",
	"Shield Hardener",
	"Flex Shield Hardener",
	"Shield Resistance Amplifier",
	"Shield Boost Amplifier",
	"Rig Shield"
]);
const ARMOR = /* @__PURE__ */ new Set([
	"Armor Plate",
	"Armor Repair Unit",
	"Ancillary Armor Repairer",
	"Armor Hardener",
	"Flex Armor Hardener",
	"Armor Coating",
	"Energized Armor Membrane",
	"Armor Resistance Shift Hardener",
	"Rig Armor"
]);
const TACKLE = /* @__PURE__ */ new Set(["Warp Scrambler", "Warp Disrupt Field Generator"]);
const TACKLE_HULLS = /* @__PURE__ */ new Set([
	"Frigate",
	"Assault Frigate",
	"Interceptor",
	"Destroyer",
	"Tactical Destroyer",
	"Command Destroyer",
	"Cruiser",
	"Heavy Assault Cruiser",
	"Strategic Cruiser",
	"Combat Battlecruiser",
	"Heavy Interdiction Cruiser",
	"Interdictor",
	"Combat Recon Ship",
	"Force Recon Ship",
	"Corvette",
	"Electronic Attack Ship",
	"Flag Cruiser"
]);
const GUNS = /* @__PURE__ */ new Set([
	"Energy Weapon",
	"Hybrid Weapon",
	"Projectile Weapon",
	"Precursor Weapon",
	"Vorton Projector"
]);
const BAD_TITLE = /\b(lol|troll|meme|joke|cheapest|funny|do\s?not|don'?t|test|bait|shit|crap|worst|useless|cringe|stupid|dumb|retard|kek|ezpz|yolo|wtf|rofl|fail)\b/i;
const PVP = /\b(pvp|solo|small[\s-]?gang|gang|kite|kiting|brawl|brawler|roam|roaming|fw|faction[\s-]?warfare|gank|ganking|doctrine|tackle|hunter|hunting|gatecamp|fleet)\b/i;
const PVE = /\b(pve|ratting|ratter|rat|mission|missions|l[1-5]|lvl\s?[1-5]|level\s?[1-5]|abyss|abyssal|filament|anom|anoms|anomaly|incursion|exploration|explo|relic|data|mining|miner|ore|ice|gas|hauling|hauler|burner|combat\s?sites?|ded|escalation|salvag\w*|sleeper|c[1-6]|tier\s?[0-6]|belt|crab|npc|epic\s?arc|agent|haven|sanctum|forsaken|rally|hub)\b/i;
function bonusText(shipId) {
	return (traits[shipId] ?? []).flatMap(([, b]) => b.map(([, t]) => t)).join(" | ");
}
const WEAPON_BONUS = /(turret|launcher|missile|rocket|torpedo|damage|rate of fire|vorton|disintegrator)/i;
function classify(name, tags, shipName) {
	const nm = name.split(shipName).join(" ");
	const t = tags.join(" | ");
	const pv = /\bpvp\b/i.test(t) || /\bpvp\b/i.test(nm), pe = /\bpve\b/i.test(t) || /\bpve\b/i.test(nm);
	if (pv && !pe) return "pvp";
	if (pe && !pv) return "pve";
	if (pv && pe) return null;
	const s = `${t} | ${nm}`;
	const a = PVP.test(s), b = PVE.test(s);
	if (a && !b) return "pvp";
	if (b && !a) return "pve";
	return null;
}
function yearsAgo(d) {
	const m = /(\d+|an?|a few)\s+(second|minute|hour|day|month|year)/i.exec(d || "");
	if (!m) return 10;
	const n = /^\d+$/.test(m[1]) ? +m[1] : 1;
	return m[2].toLowerCase() === "year" ? n : m[2].toLowerCase() === "month" ? n / 12 : 0;
}
const grp = (id) => sde.types.get(id)?.groupName ?? "";
const attr = (id, n) => sde.hasAttr(n) ? sde.baseAttr(id, sde.attrId(n)) : 0;
const isWeapon = (id) => sde.hasEffect(id, "turretFitted") && GUNS.has(grp(id)) || sde.hasEffect(id, "launcherFitted") && /^Missile Launcher/.test(grp(id)) && !/Defender|Bomb/.test(grp(id));
function check(fit, kind, shipId, hasDrones) {
	const mods = SLOT_KINDS.flatMap((k) => fit.slots[k].filter(Boolean).map((m) => m.typeId));
	if (mods.some((id) => /\bCivilian\b|Polarized/.test(sde.type(id).name))) return "civilian/polarized";
	const byGroup = /* @__PURE__ */ new Map();
	for (const id of mods) byGroup.set(sde.types.get(id).groupId, (byGroup.get(sde.types.get(id).groupId) ?? 0) + 1);
	for (const id of new Set(mods)) {
		const g = sde.types.get(id).groupId, n = byGroup.get(g);
		const lim = [
			attr(id, "maxGroupActive"),
			attr(id, "maxGroupOnline"),
			attr(id, "maxGroupFitted")
		].filter((x) => x > 0);
		if (lim.length && n > Math.min(...lim)) return `too many ${grp(id)}`;
	}
	const shield = mods.filter((id) => SHIELD.has(grp(id))).length, armor = mods.filter((id) => ARMOR.has(grp(id))).length;
	if (shield && armor) return "mixed tank";
	const ship = sde.type(shipId);
	const bonus = bonusText(shipId);
	const combat = WEAPON_BONUS.test(bonus);
	const d = new Dogma(sde, toDogmaInput(sde, fit, ch.skills));
	const r = resources(sde, fit, d);
	const counts = slotCounts(sde, fit, d);
	const used = (k) => fit.slots[k].filter(Boolean).length;
	if (used("mid") < counts.mid || used("low") < counts.low) return "empty mid/low";
	if (counts.rig && used("rig") < counts.rig - 1) return "empty rigs";
	if (kind === "pve" && mods.filter((id) => /^(Overdrive Injector System|Nanofiber Internal Structure)$/.test(grp(id))).length > 1) return "pve speed mods";
	if (combat) {
		const weapons = mods.filter(isWeapon);
		const tg = new Set(weapons.filter((id) => sde.hasEffect(id, "turretFitted")).map((id) => sde.types.get(id).groupId));
		const lg = new Set(weapons.filter((id) => sde.hasEffect(id, "launcherFitted")).map((id) => sde.types.get(id).groupId));
		if (tg.size > 1 || lg.size > 1) return "mixed weapons";
		if (new Set(weapons.map((id) => attr(id, "chargeSize")).filter((x) => x > 0)).size > 1) return "mixed weapon sizes";
		const droneBoat = d.ship.get("droneBandwidth") >= 25 && /drone/i.test(bonus) || d.ship.get("fighterTubes") > 0;
		const need = Math.max(r.turrets.total, r.launchers.total);
		if (!droneBoat && weapons.length < Math.max(1, need - 1)) return `weapons ${weapons.length}/${need}`;
		if (droneBoat && weapons.length < need - 1 && hasDrones && fit.drones.length === 0) return "drone boat without drones";
		if (!shield && !armor && !mods.some((id) => grp(id) === "Reinforced Bulkhead")) return "no tank";
		if (kind === "pvp" && TACKLE_HULLS.has(ship.groupName) && !mods.some((id) => TACKLE.has(grp(id)))) return "pvp without tackle";
	}
	if (kind === "pve" && /(mining laser|strip miner|modulated)/i.test(bonus) && !mods.some((id) => /Mining Laser|Strip Miner|Gas Cloud/.test(grp(id)))) return "mining hull without miners";
	return null;
}
function signature(fit) {
	return SLOT_KINDS.flatMap((k) => fit.slots[k].filter(Boolean).map((m) => m.typeId)).sort((a, b) => a - b).join(",");
}
function hasTackle(fit) {
	return SLOT_KINDS.some((k) => fit.slots[k].some((m) => m && TACKLE.has(grp(m.typeId))));
}
function distinctPicks(ranked, kindOf, tackle) {
	const res = {};
	const pve = ranked.pve ?? [], pvp = ranked.pvp ?? [];
	if (!pve.length || !pvp.length || pve[0].sig !== pvp[0].sig) {
		res.pve = pve[0];
		res.pvp = pvp[0];
		return res;
	}
	const top = pve[0];
	const owner = kindOf(top) === "pve" ? "pve" : kindOf(pvp[0]) === "pvp" ? "pvp" : tackle(top) ? "pvp" : "pve";
	const other = owner === "pve" ? "pvp" : "pve";
	res[owner] = (ranked[owner] ?? [])[0];
	res[other] = (ranked[other] ?? []).find((e) => e.sig !== top.sig);
	return res;
}
const files = fs.readdirSync(CACHE).filter((f) => /^s\d+\.json$/.test(f));
const out = {};
const reasons = /* @__PURE__ */ new Map();
for (const f of files) {
	const shipId = Number(f.slice(1, -5));
	const ship = sde.types.get(shipId);
	if (!ship || ship.categoryId !== Category.Ship) continue;
	if (onlyShips && !onlyShips.has(ship.name)) continue;
	const cands = JSON.parse(fs.readFileSync(`${CACHE}/${f}`, "utf8"));
	const ranked = {};
	for (const kind of ["pve", "pvp"]) {
		const scored = [];
		cands.forEach((c, i) => {
			if (BAD_TITLE.test(c.name)) {
				reasons.set("title", (reasons.get("title") ?? 0) + 1);
				return;
			}
			const k = classify(c.name, c.tags, ship.name);
			if (k && k !== kind) return;
			const efile = `${CACHE}/e${c.id}.json`;
			let eft = null;
			if (fs.existsSync(efile)) {
				const j = JSON.parse(fs.readFileSync(efile, "utf8"));
				if (j?.Eft) eft = j.Eft.replace(/\r\n/g, "\n");
			}
			if (!eft) return;
			const text = eft;
			let parsed;
			try {
				parsed = parseEft(sde, text);
			} catch {
				return;
			}
			if (parsed.unknown.length || parsed.fit.shipId !== shipId) {
				reasons.set("parse", (reasons.get("parse") ?? 0) + 1);
				return;
			}
			const bad = check(parsed.fit, kind, shipId, !!eft);
			if (bad) {
				reasons.set(bad.replace(/\d+\/\d+/, ""), (reasons.get(bad.replace(/\d+\/\d+/, "")) ?? 0) + 1);
				return;
			}
			const t2 = c.mods.filter((m) => / II$/.test(m)).length / Math.max(1, c.mods.length);
			const pre = (k ? 15 : -10) - .1 * i - 2 * Math.min(8, yearsAgo(c.date)) + 10 * t2;
			scored.push({
				c,
				i,
				k,
				eft,
				text,
				pre
			});
		});
		scored.sort((a, b) => b.pre - a.pre);
		const top = scored.slice(0, 25);
		const evald = [];
		for (const s of top) {
			const prepared = prepareFit(sde, shipId, kind, {
				eft: s.text,
				source: "x",
				title: s.c.name
			});
			if (!prepared) {
				reasons.set("invalid after prep", (reasons.get("invalid after prep") ?? 0) + 1);
				continue;
			}
			const st = computeStats(sde, prepared.fit, buildDogma(sde, prepared.fit, ch), profile);
			evald.push({
				...s,
				sig: signature(prepared.fit),
				tackle: hasTackle(prepared.fit),
				dps: st.offense.totalDps,
				ehp: st.defense.ehp,
				cap: st.capacitor.stable ? 1 : Math.min(1, (st.capacitor.lastsSeconds ?? 0) / 600),
				speed: st.navigation?.maxVelocity ?? 0
			});
		}
		if (!evald.length) continue;
		const mx = (k) => Math.max(1e-6, ...evald.map((e) => e[k]));
		const md = mx("dps"), me = mx("ehp"), ms = mx("speed");
		for (const e of evald) e.score = e.pre + 25 * e.dps / md + 15 * e.ehp / me + (kind === "pve" ? 5 * e.cap : 5 * e.speed / ms);
		evald.sort((a, b) => b.score - a.score);
		ranked[kind] = evald;
	}
	const pick = distinctPicks(ranked, (e) => e.k, (e) => e.tackle);
	for (const kind of ["pve", "pvp"]) {
		const best = pick[kind];
		if (!best) continue;
		out[shipId] ??= {};
		out[shipId][kind] = {
			eft: best.text.replace(/\n+$/, ""),
			source: `https://eveworkbench.com/fit/${best.c.id}`,
			title: best.c.name.trim()
		};
	}
}
let kept = 0;
let dropped = 0;
for (const [id, entry] of Object.entries(oldFits)) for (const kind of ["pve", "pvp"]) {
	const e = entry[kind];
	if (!e || e.source !== "generated" || out[id]?.[kind]) continue;
	if (onlyShips && !onlyShips.has(sde.types.get(Number(id))?.name ?? "")) continue;
	let parsed;
	try {
		parsed = parseEft(sde, e.eft);
	} catch {
		dropped++;
		continue;
	}
	const bad = parsed.unknown.length ? "parse" : check(parsed.fit, kind, Number(id), true);
	if (bad || !prepareFit(sde, Number(id), kind, e)) {
		dropped++;
		console.log("DROP generated", sde.types.get(Number(id))?.name, kind, bad);
		continue;
	}
	out[id] ??= {};
	out[id][kind] = e;
	kept++;
}
const eftSig = (eft) => {
	try {
		return signature(parseEft(sde, eft).fit);
	} catch {
		return eft;
	}
};
let same = 0;
for (const [id, entry] of Object.entries(out)) {
	if (!entry.pve || !entry.pvp || eftSig(entry.pve.eft) !== eftSig(entry.pvp.eft)) continue;
	same++;
	console.log("SAME after picks", sde.types.get(Number(id))?.name);
	delete entry[entry.pvp.source === "generated" ? "pvp" : entry.pve.source === "generated" ? "pve" : "pvp"];
}
console.log("identical pve/pvp removed", same);
const target = process.argv[7] ?? process.argv[4];
fs.writeFileSync(target, JSON.stringify(out, null, 1));
const pve = Object.values(out).filter((x) => x.pve).length;
const pvp = Object.values(out).filter((x) => x.pvp).length;
console.log("ships", Object.keys(out).length, "pve", pve, "pvp", pvp, "generated kept", kept, "dropped", dropped);
console.log([...reasons].sort((a, b) => b[1] - a[1]).slice(0, 12).map((r) => r.join(": ")).join(" | "));
for (const n of [
	"Ibis",
	"Rifter",
	"Drake",
	"Ishtar"
]) {
	const t = sde.findType(n);
	if (t && out[t.id]) {
		for (const k of ["pve", "pvp"]) if (out[t.id][k]) console.log(`--- ${n} ${k}: ${out[t.id][k].title}\n${out[t.id][k].eft}`);
	}
}
export {};
