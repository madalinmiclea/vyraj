import { Sde, Category } from '../../src/data/sde';
import { allLevels } from '../../src/character/characters';
import { prepareFit, type RealFitKind } from '../../src/services/realFits';
import { parseEft } from '../../src/io/eft';
import { buildDogma, slotCounts, SLOT_KINDS, toDogmaInput, type Fit } from '../../src/engine/fit';
import { Dogma } from '../../src/engine/dogma';
import { computeStats, resources } from '../../src/engine/stats';
import { findProfile } from '../../src/engine/profiles';
import fs from 'node:fs';
declare const process: any;

const sde = new Sde(JSON.parse(fs.readFileSync(process.argv[2], 'utf8')));
const CACHE = process.argv[3];
const traits: Record<string, [string, [string, string][]][]> = JSON.parse(fs.readFileSync(process.argv[5], 'utf8'));
const onlyShips = process.argv[6] ? new Set(process.argv[6].split(',')) : null;
const oldFits: Record<string, any> = JSON.parse(fs.readFileSync(process.argv[4], 'utf8'));
const ch = allLevels(sde, 5);
const profile = findProfile('Generic/Uniform');

const SHIELD = new Set(['Shield Extender', 'Shield Booster', 'Ancillary Shield Booster', 'Shield Hardener', 'Flex Shield Hardener', 'Shield Resistance Amplifier', 'Shield Boost Amplifier', 'Rig Shield']);
const ARMOR = new Set(['Armor Plate', 'Armor Repair Unit', 'Ancillary Armor Repairer', 'Armor Hardener', 'Flex Armor Hardener', 'Armor Coating', 'Energized Armor Membrane', 'Armor Resistance Shift Hardener', 'Rig Armor']);
const TACKLE = new Set(['Warp Scrambler', 'Warp Disrupt Field Generator']);
const TACKLE_HULLS = new Set(['Frigate', 'Assault Frigate', 'Interceptor', 'Destroyer', 'Tactical Destroyer', 'Command Destroyer', 'Cruiser', 'Heavy Assault Cruiser', 'Strategic Cruiser', 'Combat Battlecruiser', 'Heavy Interdiction Cruiser', 'Interdictor', 'Combat Recon Ship', 'Force Recon Ship', 'Corvette', 'Electronic Attack Ship', 'Flag Cruiser']);
const GUNS = new Set(['Energy Weapon', 'Hybrid Weapon', 'Projectile Weapon', 'Precursor Weapon', 'Vorton Projector']);
const BAD_TITLE = /\b(lol|troll|meme|joke|cheapest|funny|do\s?not|don'?t|test|bait|shit|crap|worst|useless|cringe|stupid|dumb|retard|kek|ezpz|yolo|wtf|rofl|fail)\b/i;
const PVP = /\b(pvp|solo|small[\s-]?gang|gang|kite|kiting|brawl|brawler|roam|roaming|fw|faction[\s-]?warfare|gank|ganking|doctrine|tackle|hunter|hunting|gatecamp|fleet)\b/i;
const PVE = /\b(pve|ratting|ratter|rat|mission|missions|l[1-5]|lvl\s?[1-5]|level\s?[1-5]|abyss|abyssal|filament|anom|anoms|anomaly|incursion|exploration|explo|relic|data|mining|miner|ore|ice|gas|hauling|hauler|burner|combat\s?sites?|ded|escalation|salvag\w*|sleeper|c[1-6]|tier\s?[0-6]|belt|crab|npc|epic\s?arc|agent|haven|sanctum|forsaken|rally|hub)\b/i;

function bonusText(shipId: number) { return (traits[shipId] ?? []).flatMap(([, b]) => b.map(([, t]) => t)).join(' | '); }
const WEAPON_BONUS = /(turret|launcher|missile|rocket|torpedo|damage|rate of fire|vorton|disintegrator)/i;

function classify(name: string, tags: string[], shipName: string): RealFitKind | null {
  const nm = name.split(shipName).join(' ');
  const t = tags.join(' | ');
  const pv = /\bpvp\b/i.test(t) || /\bpvp\b/i.test(nm), pe = /\bpve\b/i.test(t) || /\bpve\b/i.test(nm);
  if (pv && !pe) return 'pvp';
  if (pe && !pv) return 'pve';
  if (pv && pe) return null;
  const s = `${t} | ${nm}`;
  const a = PVP.test(s), b = PVE.test(s);
  if (a && !b) return 'pvp';
  if (b && !a) return 'pve';
  return null;
}

function yearsAgo(d: string) {
  const m = /(\d+|an?|a few)\s+(second|minute|hour|day|month|year)/i.exec(d || '');
  if (!m) return 10;
  const n = /^\d+$/.test(m[1]) ? +m[1] : 1;
  return m[2].toLowerCase() === 'year' ? n : m[2].toLowerCase() === 'month' ? n / 12 : 0;
}

const grp = (id: number) => sde.types.get(id)?.groupName ?? '';
const attr = (id: number, n: string) => (sde.hasAttr(n) ? sde.baseAttr(id, sde.attrId(n)) : 0);
const isWeapon = (id: number) => (sde.hasEffect(id, 'turretFitted') && GUNS.has(grp(id))) || (sde.hasEffect(id, 'launcherFitted') && /^Missile Launcher/.test(grp(id)) && !/Defender|Bomb/.test(grp(id)));

function check(fit: Fit, kind: RealFitKind, shipId: number, hasDrones: boolean): string | null {
  const mods = SLOT_KINDS.flatMap((k) => fit.slots[k].filter(Boolean).map((m) => m!.typeId));
  if (mods.some((id) => /\bCivilian\b|Polarized/.test(sde.type(id).name))) return 'civilian/polarized';
  const byGroup = new Map<number, number>();
  for (const id of mods) byGroup.set(sde.types.get(id)!.groupId, (byGroup.get(sde.types.get(id)!.groupId) ?? 0) + 1);
  for (const id of new Set(mods)) {
    const g = sde.types.get(id)!.groupId, n = byGroup.get(g)!;
    const lim = [attr(id, 'maxGroupActive'), attr(id, 'maxGroupOnline'), attr(id, 'maxGroupFitted')].filter((x) => x > 0);
    if (lim.length && n > Math.min(...lim)) return `too many ${grp(id)}`;
  }
  const shield = mods.filter((id) => SHIELD.has(grp(id))).length, armor = mods.filter((id) => ARMOR.has(grp(id))).length;
  if (shield && armor) return 'mixed tank';
  const ship = sde.type(shipId);
  const bonus = bonusText(shipId);
  const combat = WEAPON_BONUS.test(bonus);
  const d = new Dogma(sde, toDogmaInput(sde, fit, ch.skills));
  const r = resources(sde, fit, d);
  const counts = slotCounts(sde, fit, d);
  const used = (k: 'high' | 'mid' | 'low' | 'rig') => fit.slots[k].filter(Boolean).length;
  if (used('mid') < counts.mid || used('low') < counts.low) return 'empty mid/low';
  if (counts.rig && used('rig') < counts.rig - 1) return 'empty rigs';
  if (kind === 'pve' && mods.filter((id) => /^(Overdrive Injector System|Nanofiber Internal Structure)$/.test(grp(id))).length > 1) return 'pve speed mods';
  if (combat) {
    const weapons = mods.filter(isWeapon);
    const tg = new Set(weapons.filter((id) => sde.hasEffect(id, 'turretFitted')).map((id) => sde.types.get(id)!.groupId));
    const lg = new Set(weapons.filter((id) => sde.hasEffect(id, 'launcherFitted')).map((id) => sde.types.get(id)!.groupId));
    if (tg.size > 1 || lg.size > 1) return 'mixed weapons';
    const sizes = new Set(weapons.map((id) => attr(id, 'chargeSize')).filter((x) => x > 0));
    if (sizes.size > 1) return 'mixed weapon sizes';
    const droneBoat = (d.ship.get('droneBandwidth') >= 25 && /drone/i.test(bonus)) || d.ship.get('fighterTubes') > 0;
    const need = Math.max(r.turrets.total, r.launchers.total);
    if (!droneBoat && weapons.length < Math.max(1, need - 1)) return `weapons ${weapons.length}/${need}`;
    if (droneBoat && weapons.length < need - 1 && hasDrones && fit.drones.length === 0) return 'drone boat without drones';
    if (!shield && !armor && !mods.some((id) => grp(id) === 'Reinforced Bulkhead')) return 'no tank';
    if (kind === 'pvp' && TACKLE_HULLS.has(ship.groupName) && !mods.some((id) => TACKLE.has(grp(id)))) return 'pvp without tackle';
  }
  if (kind === 'pve' && /(mining laser|strip miner|modulated)/i.test(bonus) && !mods.some((id) => /Mining Laser|Strip Miner|Gas Cloud/.test(grp(id)))) return 'mining hull without miners';
  return null;
}

function signature(fit: Fit) {
  const mods = SLOT_KINDS.flatMap((k) => fit.slots[k].filter(Boolean).map((m) => m!.typeId));
  return mods.sort((a, b) => a - b).join(',');
}
function hasTackle(fit: Fit) {
  return SLOT_KINDS.some((k) => fit.slots[k].some((m) => m && TACKLE.has(grp(m.typeId))));
}
function distinctPicks<T extends { sig: string }>(ranked: Partial<Record<RealFitKind, T[]>>, kindOf: (e: T) => RealFitKind | null, tackle: (e: T) => boolean) {
  const res: Partial<Record<RealFitKind, T>> = {};
  const pve = ranked.pve ?? [], pvp = ranked.pvp ?? [];
  if (!pve.length || !pvp.length || pve[0].sig !== pvp[0].sig) { res.pve = pve[0]; res.pvp = pvp[0]; return res; }
  const top = pve[0];
  const owner: RealFitKind = kindOf(top) === 'pve' ? 'pve' : kindOf(pvp[0]) === 'pvp' ? 'pvp' : tackle(top) ? 'pvp' : 'pve';
  const other: RealFitKind = owner === 'pve' ? 'pvp' : 'pve';
  res[owner] = (ranked[owner] ?? [])[0];
  res[other] = (ranked[other] ?? []).find((e) => e.sig !== top.sig);
  return res;
}

const files = fs.readdirSync(CACHE).filter((f: string) => /^s\d+\.json$/.test(f));
const out: Record<string, any> = {};
const reasons = new Map<string, number>();
for (const f of files) {
  const shipId = Number(f.slice(1, -5));
  const ship = sde.types.get(shipId);
  if (!ship || ship.categoryId !== Category.Ship) continue;
  if (onlyShips && !onlyShips.has(ship.name)) continue;
  const cands = JSON.parse(fs.readFileSync(`${CACHE}/${f}`, 'utf8'));
  const ranked: Partial<Record<RealFitKind, any[]>> = {};
  for (const kind of ['pve', 'pvp'] as RealFitKind[]) {
    const scored: any[] = [];
    cands.forEach((c: any, i: number) => {
      if (BAD_TITLE.test(c.name)) { reasons.set('title', (reasons.get('title') ?? 0) + 1); return; }
      const k = classify(c.name, c.tags, ship.name);
      if (k && k !== kind) return;
      const efile = `${CACHE}/e${c.id}.json`;
      let eft: string | null = null;
      if (fs.existsSync(efile)) { const j = JSON.parse(fs.readFileSync(efile, 'utf8')); if (j?.Eft) eft = j.Eft.replace(/\r\n/g, '\n'); }
      if (!eft) return;
      const text = eft;
      let parsed;
      try { parsed = parseEft(sde, text); } catch { return; }
      if (parsed.unknown.length || parsed.fit.shipId !== shipId) { reasons.set('parse', (reasons.get('parse') ?? 0) + 1); return; }
      const bad = check(parsed.fit, kind, shipId, !!eft);
      if (bad) { reasons.set(bad.replace(/\d+\/\d+/, ''), (reasons.get(bad.replace(/\d+\/\d+/, '')) ?? 0) + 1); return; }
      const t2 = c.mods.filter((m: string) => / II$/.test(m)).length / Math.max(1, c.mods.length);
      const pre = (k ? 15 : -10) - 0.1 * i - 2 * Math.min(8, yearsAgo(c.date)) + 10 * t2;
      scored.push({ c, i, k, eft, text, pre });
    });
    scored.sort((a, b) => b.pre - a.pre);
    const top = scored.slice(0, 25);
    const evald: any[] = [];
    for (const s of top) {
      const prepared = prepareFit(sde, shipId, kind, { eft: s.text, source: 'x', title: s.c.name });
      if (!prepared) { reasons.set('invalid after prep', (reasons.get('invalid after prep') ?? 0) + 1); continue; }
      const st = computeStats(sde, prepared.fit, buildDogma(sde, prepared.fit, ch), profile);
      evald.push({ ...s, sig: signature(prepared.fit), tackle: hasTackle(prepared.fit), dps: st.offense.totalDps, ehp: st.defense.ehp, cap: st.capacitor.stable ? 1 : Math.min(1, (st.capacitor.lastsSeconds ?? 0) / 600), speed: st.navigation?.maxVelocity ?? 0 });
    }
    if (!evald.length) continue;
    const mx = (k: string) => Math.max(1e-6, ...evald.map((e) => e[k]));
    const md = mx('dps'), me = mx('ehp'), ms = mx('speed');
    for (const e of evald) e.score = e.pre + 25 * e.dps / md + 15 * e.ehp / me + (kind === 'pve' ? 5 * e.cap : 5 * e.speed / ms);
    evald.sort((a, b) => b.score - a.score);
    ranked[kind] = evald;
  }
  const pick = distinctPicks(ranked, (e) => e.k, (e) => e.tackle);
  for (const kind of ['pve', 'pvp'] as RealFitKind[]) {
    const best = pick[kind];
    if (!best) continue;
    out[shipId] ??= {};
    out[shipId][kind] = { eft: best.text.replace(/\n+$/, ''), source: `https://eveworkbench.com/fit/${best.c.id}`, title: best.c.name.trim() };
  }
}
let kept = 0, dropped = 0;
for (const [id, entry] of Object.entries(oldFits)) {
  for (const kind of ['pve', 'pvp'] as RealFitKind[]) {
    const e = (entry as any)[kind];
    if (!e || e.source !== 'generated' || out[id]?.[kind]) continue;
    if (onlyShips && !onlyShips.has(sde.types.get(Number(id))?.name ?? '')) continue;
    let parsed;
    try { parsed = parseEft(sde, e.eft); } catch { dropped++; continue; }
    const bad = parsed.unknown.length ? 'parse' : check(parsed.fit, kind, Number(id), true);
    if (bad || !prepareFit(sde, Number(id), kind, e)) { dropped++; console.log('DROP generated', sde.types.get(Number(id))?.name, kind, bad); continue; }
    out[id] ??= {};
    out[id][kind] = e;
    kept++;
  }
}
const eftSig = (eft: string) => { try { return signature(parseEft(sde, eft).fit); } catch { return eft; } };
let same = 0;
for (const [id, entry] of Object.entries(out)) {
  if (!entry.pve || !entry.pvp || eftSig(entry.pve.eft) !== eftSig(entry.pvp.eft)) continue;
  same++;
  console.log('SAME after picks', sde.types.get(Number(id))?.name);
  delete entry[entry.pvp.source === 'generated' ? 'pvp' : entry.pve.source === 'generated' ? 'pve' : 'pvp'];
}
console.log('identical pve/pvp removed', same);
const target = process.argv[7] ?? process.argv[4];
fs.writeFileSync(target, JSON.stringify(out, null, 1));
const pve = Object.values(out).filter((x: any) => x.pve).length, pvp = Object.values(out).filter((x: any) => x.pvp).length;
console.log('ships', Object.keys(out).length, 'pve', pve, 'pvp', pvp, 'generated kept', kept, 'dropped', dropped);
console.log([...reasons].sort((a, b) => b[1] - a[1]).slice(0, 12).map((r) => r.join(': ')).join(' | '));
for (const n of ['Ibis', 'Rifter', 'Drake', 'Ishtar']) { const t = sde.findType(n); if (t && out[t.id]) for (const k of ['pve', 'pvp']) if (out[t.id][k]) console.log(`--- ${n} ${k}: ${out[t.id][k].title}\n${out[t.id][k].eft}`); }
