import sys,re
path=sys.argv[1]; spec=sys.argv[2]
txt=open(path).read()
blocks=re.split(r'(?m)^(?=### )',txt)
fixes={}
cur=None
for line in open(spec).read().split("\n"):
    if line.startswith("@"):
        cur=line[1:].strip(); fixes.setdefault(cur,[])
    elif "=>" in line and cur:
        a,b=line.split("=>"); n=1
        m=re.match(r'^(\d+)\s*\*\s*(.*)$',a.strip())
        if m: n=int(m.group(1)); a=m.group(2)
        fixes[cur].append((a.strip(),b.strip(),n))
out=[]
for b in blocks:
    h=re.search(r'(?m)^\[(.+)\]$',b)
    key=h.group(1) if h else None
    if key in fixes:
        lines=b.split("\n")
        for a,c,n in fixes[key]:
            done=0
            for i,l in enumerate(lines):
                if done<n and l.strip()==a:
                    lines[i]=c; done+=1
            if done<n: print("MISS",key,a,file=sys.stderr)
        lines=[l for l in lines if l!="DEL"]
        b="\n".join(lines)
    out.append(b)
open(path,"w").write("".join(out))
