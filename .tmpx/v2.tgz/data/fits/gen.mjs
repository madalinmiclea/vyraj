import fs from "node:fs";
import path from "node:path";

const ROOT = path.resolve(process.argv[2]);
const mode = process.argv[3];
const pd = path.join(ROOT, "public/data");
const sde = JSON.parse(fs.readFileSync(path.join(pd, fs.readdirSync(pd).find(f => /^sde\..*\.json$/.test(f))), "utf8"));
const items = JSON.parse(fs.readFileSync(path.join(pd, fs.readdirSync(pd).find(f => /^items\..*\.json$/.test(f))), "utf8"));
const T = {}; sde.types.forEach(t => { T[t.n] = t; });
const I = {}; items.items.forEach(t => { I[t.n] = t; });
const OUT = path.join(ROOT, "src/data/shipFits.json");
const out = JSON.parse(fs.readFileSync(OUT, "utf8"));

const a = (t, k) => (t && t.a && t.a[k]) || 0;
const has = (t, e) => !!(t && t.e && t.e.includes(e));
const rack = t => has(t, 12) ? "hi" : has(t, 13) ? "mid" : has(t, 11) ? "low" : has(t, 2663) ? "rig" : has(t, 3772) ? "sub" : null;

function info(name) {
  const t = T[name];
  if (!t) return name + ": not in sde";
  const fit = out[I[name]?.t] || {};
  return `${name} H${a(t, 14)} M${a(t, 13)} L${a(t, 12)} R${a(t, 1137)} turrets${a(t, 102)} launchers${a(t, 101)} cpu${a(t, 48)} pg${a(t, 11)} drones${a(t, 283)}/${a(t, 1271)} calib${a(t, 1132)} rigsize${a(t, 1547)} have:${Object.keys(fit).join(",")}`;
}

function check(text) {
  const lines = text.split("\n");
  const head = /^\[([^,]+),\s*(.+)\]$/.exec(lines[0]);
  if (!head) return ["bad header"];
  const ship = T[head[1].trim()];
  if (!ship) return ["unknown ship " + head[1]];
  const errs = [];
  const cnt = { hi: 0, mid: 0, low: 0, rig: 0 };
  let cpu = 0, pg = 0, tur = 0, lau = 0, dv = 0, bw = 0, cal = 0;
  for (const raw of lines.slice(1)) {
    const l = raw.trim();
    if (!l) continue;
    const m = /^(.+?)\s+x(\d+)$/.exec(l);
    if (m) {
      const t = T[m[1]] || I[m[1]];
      if (!T[m[1]] && !I[m[1]]) errs.push("unknown " + m[1]);
      if (T[m[1]] && a(T[m[1]], 1272)) { dv += a(T[m[1]], 161) * +m[2]; }
      continue;
    }
    const [mod, ch] = l.split(",").map(s => s.trim());
    const t = T[mod];
    if (!t) { if (!I[mod]) errs.push("unknown " + mod); continue; }
    if (ch && !T[ch] && !I[ch]) errs.push("unknown charge " + ch);
    const r = rack(t);
    if (!r) continue;
    cnt[r]++;
    if (r === "rig") { cal += a(t, 1153); continue; }
    cpu += a(t, 50); pg += a(t, 30);
    if (has(t, 42)) tur++;
    if (has(t, 40)) lau++;
  }
  const lim = { hi: a(ship, 14), mid: a(ship, 13), low: a(ship, 12), rig: a(ship, 1137) };
  for (const k of Object.keys(cnt)) if (cnt[k] > lim[k]) errs.push(`${k} ${cnt[k]}>${lim[k]}`);
  if (tur > a(ship, 102)) errs.push(`turrets ${tur}>${a(ship, 102)}`);
  if (lau > a(ship, 101)) errs.push(`launchers ${lau}>${a(ship, 101)}`);
  if (cal > a(ship, 1132)) errs.push(`calibration ${cal}>${a(ship, 1132)}`);
  const usedCpu = Math.round(cpu), maxCpu = Math.round(a(ship, 48) * 1.25);
  const usedPg = Math.round(pg), maxPg = Math.round(a(ship, 11) * 1.25);
  if (dv > a(ship, 283)) errs.push(`dronebay ${dv}>${a(ship, 283)}`);
  return { errs, note: `slots ${cnt.hi}/${cnt.mid}/${cnt.low}/${cnt.rig} cpu ${usedCpu}/${maxCpu} pg ${usedPg}/${maxPg} (raw, before skill reductions)` };
}

if (mode === "info") {
  for (const n of process.argv.slice(4).join(" ").split(",")) {
    const nm = n.trim();
    console.log(info(nm));
  }
} else if (mode === "show") {
  for (const n of process.argv.slice(4).join(" ").split(",")) {
    const f = out[I[n.trim()]?.t];
    for (const k of ["pve", "pvp"]) if (f && f[k]) console.log(`--- ${n.trim()} ${k}: ${f[k].title}\n${f[k].eft}\n`);
  }
} else if (mode === "add") {
  const raw = fs.readFileSync(process.argv[4], "utf8");
  const src = raw.split(/^### /m).filter(b => b.trim()).map(b => {
    const nl = b.indexOf("\n");
    const [kind, ...rest] = b.slice(0, nl).trim().split(" ");
    const eft = b.slice(nl + 1).replace(/\s+$/, "");
    const title = /^\[[^,]+,\s*(.+)\]/.exec(eft)[1];
    return { kind, title, eft, force: rest.includes("force") };
  });
  let bad = 0;
  fs.writeFileSync("check.in.json", JSON.stringify(src.map((g, i) => ({ key: String(i), eft: g.eft }))));
  const { execFileSync } = await import("node:child_process");
  const eng = JSON.parse(execFileSync("node", ["check.bundle.mjs", pd, "check.in.json"], { maxBuffer: 1 << 26 }).toString());
  for (const [i, g] of src.entries()) {
    const r = check(g.eft);
    const e = eng[String(i)];
    r.errs.push(...e.errs, ...e.unknown.map(u => "engine-unknown " + u));
    r.note = `cpu ${e.cpu} pg ${e.pg}`;
    const ship = /^\[([^,]+),/.exec(g.eft)[1].trim();
    const warn = "";
    console.log((r.errs.length ? "ERR " : "ok  ") + ship + " " + g.kind + " " + r.note + warn + " " + r.errs.join("; "));
    if (r.errs.length) { bad++; continue; }
    const id = I[ship].t;
    out[id] = out[id] || {};
    if (out[id][g.kind] && !g.force) continue;
    out[id][g.kind] = { eft: g.eft, source: g.source || "generated", title: g.title };
  }
  if (!process.env.DRY) fs.writeFileSync(OUT, JSON.stringify(out, null, 1));
  console.log("bad", bad);
}
