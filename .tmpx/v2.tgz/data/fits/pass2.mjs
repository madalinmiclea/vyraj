import fs from "node:fs";
import path from "node:path";

const ROOT = path.resolve(process.argv[2]);
const OUT = path.join(ROOT, "src/data/shipFits.json");
const CACHE = path.join(ROOT, "data/fits/cache");
const pd = path.join(ROOT, "public/data");
const items = JSON.parse(fs.readFileSync(path.join(pd, fs.readdirSync(pd).find(f => /^items\..*\.json$/.test(f))), "utf8"));
const names = new Set(items.items.map(i => i.n));
const g = items.groups;
const mpath = m => { const a = []; while (m && g[m]) { a.unshift(g[m][0]); m = g[m][1]; } return a.join(">"); };
const ships = items.items.filter(i => i.c === "Ships" && !/Shuttle|Capsule/.test(i.n));
const out = JSON.parse(fs.readFileSync(OUT, "utf8"));

const INDUSTRIAL = /Haulers|Freighters|Mining|Industrial|Shuttles|Expedition|Exploration|Mining Frigate/;
const sleep = ms => new Promise(r => setTimeout(r, ms));

function eftValid(text) {
  const lines = text.split(/\r?\n/);
  if (!/^\[[^,\]]+,.*\]$/.test(lines[0].trim())) return false;
  let mods = 0;
  for (const raw of lines.slice(1)) {
    let l = raw.trim();
    if (!l || /^\[empty/i.test(l)) continue;
    l = l.replace(/\s*\/OFFLINE$/i, "").replace(/\s+x\d+$/, "");
    for (const p of l.split(",").map(s => s.trim())) if (p && !names.has(p)) return false;
    mods++;
  }
  return mods >= 3;
}
async function eft(id) {
  const f = path.join(CACHE, `e${id}.json`);
  if (fs.existsSync(f)) return JSON.parse(fs.readFileSync(f, "utf8"));
  const r = await fetch(`https://api.eveworkbench.com/v1/fits/${id}/eft`);
  await sleep(350);
  if (!r.ok) return null;
  const j = await r.json();
  fs.writeFileSync(f, JSON.stringify(j));
  return j;
}
const PVPHINT = /\b(pvp|solo|gang|kite|brawl|fleet|doctrine|tackle|hunter|camp|bomb|neut|scram|web|dps|alpha|siege|triage|logi|links|command|ecm|damp|td|gd|point)\b/i;
const PVEHINT = /\b(pve|rat|ratting|ratter|mission|l[1-5]|abyss|abyssal|anom|incursion|c[1-6]|crab|explo|exploration|hack|relic|data|salvage|mining|miner|ore|ice|gas|haul|hauler|cargo|transport|travel|tank|epic|sansha|blood|guristas|serpentis|angel|drifter|t[0-6]|calm|exotic|dark|firestorm|electrical|gamma)\b/i;

const HARDPVE = /\bpve\b|mission|\bl[1-5]\b|lvl\s?[1-5]|level\s?[1-5]|miner|mining|harvest|crab|ratting|ratter|abyss|exploration|explo|salvag|\bc[1-6]\b|incursion|\bt[0-6]\b|exotic|gamma|calm/i;
const HARDPVP = /\bpvp\b|gank|solo|small\s?gang|doctrine|fleet|kite|brawl|hunter|camp/i;
let added = 0;
for (const s of ships) {
  const f = path.join(CACHE, `s${s.t}.json`);
  if (!fs.existsSync(f)) continue;
  const fits = JSON.parse(fs.readFileSync(f, "utf8"));
  if (!fits.length) continue;
  const e = out[s.t] || {};
  const industrial = INDUSTRIAL.test(mpath(s.m)) || /^(Pioneer|Venture|Endurance|Prospect|Perseverance|Echelon|Primae)/.test(s.n);
  const used = new Set(Object.values(e).map(v => v.source));
  for (const kind of ["pve", "pvp"]) {
    if (e[kind]) continue;
    if (industrial && kind === "pvp") continue;
    const other = kind === "pve" ? PVPHINT : PVEHINT;
    const own = kind === "pve" ? PVEHINT : PVPHINT;
    const cands = fits.filter(x => !used.has(`https://eveworkbench.com/fit/${x.id}`)).map((x, i) => {
      const txt = x.name + " " + x.tags.join(" ");
      const o = other.test(txt), w = own.test(txt);
      if (kind === "pvp" && HARDPVE.test(txt)) return { x, score: -999 };
      if (kind === "pve" && HARDPVP.test(txt)) return { x, score: -999 };
      let score = -i;
      if (w) score += 30;
      if (o && !w) score -= 100;
      if (!o && !w) score += industrial ? (kind === "pve" ? 0 : -100) : (kind === "pvp" ? 0 : -100);
      if (/simulated|test\b/i.test(x.name)) score -= 20;
      return { x, score };
    }).filter(c => c.score > -60).sort((a, b) => b.score - a.score);
    for (const c of cands.slice(0, 6)) {
      const j = await eft(c.x.id);
      if (!j || j.Error || !j.Eft || !eftValid(j.Eft)) continue;
      e[kind] = { eft: j.Eft.replace(/\r\n/g, "\n").replace(/\n+$/, ""), source: `https://eveworkbench.com/fit/${c.x.id}`, title: c.x.name.trim() };
      used.add(e[kind].source);
      added++;
      console.log(s.n, kind, "<-", c.x.name.trim(), "|", c.x.tags.join(","));
      break;
    }
  }
  if (Object.keys(e).length) out[s.t] = e;
}
fs.writeFileSync(OUT, JSON.stringify(out, null, 1));
console.log("added", added, "pve", ships.filter(s => out[s.t]?.pve).length, "pvp", ships.filter(s => out[s.t]?.pvp).length, "neither", ships.filter(s => !out[s.t]).length);
