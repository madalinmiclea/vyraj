import fs from "node:fs";
const list = process.argv.slice(2).join(" ").split(",").map(s => s.trim()).filter(Boolean);
for (const s of list) {
  const f = `wiki/${s.replace(/ /g, "_")}.txt`;
  let txt = fs.existsSync(f) ? fs.readFileSync(f, "utf8") : "";
  if (!txt) {
    const r = await fetch(`https://wiki.eveuniversity.org/index.php?title=${encodeURIComponent(s.replace(/ /g, "_"))}&action=raw`);
    txt = r.ok ? await r.text() : "";
    fs.writeFileSync(f, txt);
    await new Promise(r => setTimeout(r, 400));
  }
  const m = /\|\s*bonuses=([\s\S]*?)\n\|/.exec(txt);
  console.log("=== " + s + ": " + (m ? m[1].replace(/<br\s*\/?>|'''|&nbsp;|•/g, " ").replace(/\s+/g, " ").trim() : "NO BONUS " + txt.slice(0, 80)));
}
