globalThis.localStorage = { getItem: () => null, setItem() {}, removeItem() {} };
Object.defineProperty(globalThis, 'navigator', { value: { language: 'ro' }, configurable: true });
globalThis.document = { documentElement: {} };
await import('./qo/q2.js');
