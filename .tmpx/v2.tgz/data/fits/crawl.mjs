import fs from "node:fs";
import path from "node:path";

const ROOT = path.resolve(process.argv[2]);
const OUT = path.join(ROOT, "src/data/shipFits.json");
const CACHE = path.join(ROOT, "data/fits/cache");
fs.mkdirSync(CACHE, { recursive: true });
const itemsFile = fs.readdirSync(path.join(ROOT, "public/data")).find(f => /^items\..*\.json$/.test(f));
const items = JSON.parse(fs.readFileSync(path.join(ROOT, "public/data", itemsFile), "utf8")).items;
const names = new Set(items.map(i => i.n));
const ships = items.filter(i => i.c === "Ships" && !/Shuttle|Capsule/.test(i.n)).sort((a, b) => a.n.localeCompare(b.n));

const sleep = ms => new Promise(r => setTimeout(r, ms));
async function req(url, opts, tries = 4) {
  for (let i = 0; i < tries; i++) {
    try {
      const r = await fetch(url, opts);
      if (r.status === 429) { await sleep(5000 * (i + 1)); continue; }
      if (!r.ok) throw new Error(r.status + " " + url);
      return await r.json();
    } catch (e) {
      if (i === tries - 1) throw e;
      await sleep(2000 * (i + 1));
    }
  }
}

async function search(shipId) {
  const f = path.join(CACHE, `s${shipId}.json`);
  if (fs.existsSync(f)) return JSON.parse(fs.readFileSync(f, "utf8"));
  const all = [];
  for (let skip = 0; skip < 600; skip += 100) {
    const j = await req("https://webapi.eveworkbench.com/Fit/PostSearchFits", {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json", Origin: "https://eveworkbench.com" },
      body: JSON.stringify({ skip, take: 100, shipId, sortField: "votes", sortOrder: "desc", minPrice: 0, maxPrice: 150000000000 })
    });
    await sleep(350);
    const res = (j.results || []).filter(r => r.shipId === shipId);
    all.push(...res.map(r => ({ id: r.id, name: r.name, tags: (r.tags || []).map(t => t.name.trim()), date: r.dateView, mods: [...r.highSlots, ...r.mediumSlots, ...r.lowSlots, ...r.rigSlots, ...(r.subsystemSlots || [])].map(m => m.name) })));
    if ((j.results || []).length < 100) break;
  }
  fs.writeFileSync(f, JSON.stringify(all));
  return all;
}

async function eft(id) {
  const f = path.join(CACHE, `e${id}.json`);
  if (fs.existsSync(f)) return JSON.parse(fs.readFileSync(f, "utf8"));
  const j = await req(`https://api.eveworkbench.com/v1/fits/${id}/eft`);
  await sleep(350);
  fs.writeFileSync(f, JSON.stringify(j));
  return j;
}

const PVP = /\b(pvp|solo|small[\s-]?gang|smallgang|gang|kite|kiting|kiter|brawl|brawler|brawling|roam|roaming|fw|faction[\s-]?warfare|gank|ganking|ganker|doctrine|nano|tackle|tackler|bait|blops|black[\s-]?ops|hunter|hunting|hic|dictor|interdict|bubble|logi\s?fleet|cyno|frat|gatecamp|gate[\s-]?camp|hellcamp|brawl|pew|fleet[\s-]?pvp|duel|tournament)/i;
const PVE = /\b(pve|ratting|ratter|rat|rats|mission|missions|missioning|mission[\s-]?runner|l[1-5]|lvl\s?[1-5]|level\s?[1-5]|abyss|abyssal|abyssals|filament|anom|anoms|anomaly|anomalies|incursion|incursions|exploration|explorer|explo|relic|data[\s-]?site|hacking|mining|miner|mine|ore|ice|gas|huffing|hauling|hauler|haul|burner|burners|combat[\s-]?sites?|ded|escalation|salvage|salvager|salvaging|sleeper|sleepers|c[1-6]|wormhole[\s-]?sites?|tier\s?[0-6]|cosmic|triglavian|edencom|homefront|pochven[\s-]?rat|belt|belts|crab|crabbing|npc|sansha|blood|guristas|serpentis|angel|drifter|sotiyo|epic[\s-]?arc|agent|courier|trade)/i;

function classify(fit, shipName) {
  const tags = fit.tags.join(" | ");
  const nm = fit.name.split(shipName).join(" ");
  const tPvp = /\bpvp\b/i.test(tags) || /\bpvp\b/i.test(nm);
  const tPve = /\bpve\b/i.test(tags) || /\bpve\b/i.test(nm);
  if (tPvp && !tPve) return "pvp";
  if (tPve && !tPvp) return "pve";
  if (tPvp && tPve) return null;
  const s = tags + " | " + nm;
  const a = PVP.test(s), b = PVE.test(s);
  if (a && !b) return "pvp";
  if (b && !a) return "pve";
  return null;
}

function yearsAgo(d) {
  const m = /(\d+|an?|a few)\s+(second|minute|hour|day|month|year)/i.exec(d || "");
  if (!m) return 99;
  const n = /^\d+$/.test(m[1]) ? +m[1] : 1;
  const u = m[2].toLowerCase();
  return u === "year" ? n : u === "month" ? n / 12 : 0;
}

function eftValid(text) {
  const lines = text.split(/\r?\n/);
  if (!/^\[[^,\]]+,.*\]$/.test(lines[0].trim())) return false;
  let mods = 0, bad = 0;
  for (const raw of lines.slice(1)) {
    let l = raw.trim();
    if (!l || /^\[(empty|Empty)/.test(l)) continue;
    l = l.replace(/\s*\/OFFLINE$/i, "").replace(/\s+x\d+$/, "");
    const parts = l.split(",").map(s => s.trim());
    for (const p of parts) if (p && !names.has(p)) bad++;
    mods++;
  }
  return mods > 0 && bad === 0;
}

function t2count(f) { return f.mods.filter(m => / II$/.test(m)).length; }

const out = fs.existsSync(OUT) ? JSON.parse(fs.readFileSync(OUT, "utf8")) : {};
const only = process.argv[3] ? new Set(process.argv[3].split(",")) : null;
let done = 0;
for (const s of ships) {
  if (only && !only.has(String(s.t)) && !only.has(s.n)) continue;
  done++;
  if (!only && out[s.t] && out[s.t].pve && out[s.t].pvp) continue;
  let fits;
  try { fits = await search(s.t); } catch (e) { console.log("ERR search", s.n, e.message); continue; }
  const entry = out[s.t] || {};
  for (const kind of ["pve", "pvp"]) {
    if (entry[kind]) continue;
    const cands = fits.map((f, i) => ({ f, i, k: classify(f, s.n) })).filter(c => c.k === kind);
    cands.forEach(c => {
      const y = yearsAgo(c.f.date);
      c.score = -c.i * 1.0 - (y > 4 ? 25 : y > 2 ? 8 : 0) + Math.min(t2count(c.f), 8) * 1.5;
    });
    cands.sort((a, b) => b.score - a.score);
    for (const c of cands.slice(0, 8)) {
      let j;
      try { j = await eft(c.f.id); } catch (e) { continue; }
      if (!j || j.Error || !j.Eft || !eftValid(j.Eft)) continue;
      entry[kind] = { eft: j.Eft.replace(/\r\n/g, "\n").replace(/\n+$/, ""), source: `https://eveworkbench.com/fit/${c.f.id}`, title: c.f.name.trim() };
      break;
    }
  }
  if (Object.keys(entry).length) out[s.t] = entry;
  console.log(done, s.n, fits.length, entry.pve ? "PVE" : "-", entry.pvp ? "PVP" : "-");
  if (done % 10 === 0) fs.writeFileSync(OUT, JSON.stringify(out, null, 1));
}
fs.writeFileSync(OUT, JSON.stringify(out, null, 1));
const n = ships.length, pve = ships.filter(s => out[s.t]?.pve).length, pvp = ships.filter(s => out[s.t]?.pvp).length;
console.log("TOTAL", n, "pve", pve, "pvp", pvp);
console.log("NEITHER", ships.filter(s => !out[s.t]).map(s => s.n).join(", "));
