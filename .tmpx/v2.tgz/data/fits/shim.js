globalThis.navigator ??= { language: 'en-US' };
globalThis.localStorage ??= { getItem: () => JSON.stringify('en'), setItem() {}, removeItem() {} };
globalThis.document ??= { documentElement: {} };
globalThis.location ??= { reload() {} };
