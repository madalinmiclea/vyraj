
import json,sys,os
os.chdir(os.path.expanduser('~/mnt/vyraj'))
BLOCK="\nconst PI_PIN_KINDS: Record<number, string> = { 1026: 'ext', 1027: 'cc', 1028: 'fac', 1029: 'store', 1030: 'pad', 1063: 'ecu' };\nconst PI_RAW_CATEGORY = 42;\nconst HARVESTED_TYPE = 709;\nconst EXTRACTOR_PLANET = 1632;\n\nconst keyed = (v: any): [number, Row][] => (Array.isArray(v) ? v.map((x: Row) => [Number(x._key ?? x.typeID), x._value ?? x] as [number, Row]) : Object.entries(v ?? {}).map(([k, x]) => [Number(k), x as Row]));\n\nexport function buildPi(dir: string) {\n    const schematics = readJsonl(dir, 'planetSchematics');\n    const types = readJsonl(dir, 'types');\n    const groups = readJsonl(dir, 'groups');\n    const dogma = readJsonl(dir, 'typeDogma');\n    const attr = (id: number, a: number): number | undefined => (dogma.get(id)?.dogmaAttributes ?? []).find((x: Row) => x.attributeID === a)?.value;\n    const tier = new Map<number, number>();\n    for (const [id, t] of types) if (t.published && groups.get(t.groupID)?.categoryID === PI_RAW_CATEGORY) tier.set(id, 0);\n    const rows = [...schematics].map(([id, s]) => {\n        const io = keyed(s.types);\n        const out = io.find(([, x]) => !x.isInput);\n        return { id, name: en(s.name ?? s.nameID), cycle: Number(s.cycleTime), out, ins: io.filter(([, x]) => x.isInput).map(([t, x]) => [t, Number(x.quantity)]) };\n    }).filter((r) => r.out && r.ins.length);\n    for (let pass = 0; pass < 6; pass++) {\n        for (const r of rows) {\n            const ts = r.ins.map(([t]) => tier.get(t));\n            if (ts.every((x) => x != null)) tier.set(r.out![0], Math.max(...(ts as number[])) + 1);\n        }\n    }\n    const outTypes: Record<number, [string, number, number]> = {};\n    for (const [id, t] of tier) outTypes[id] = [en(types.get(id)?.name), t, Number(types.get(id)?.volume ?? 0)];\n    const outSchematics = rows\n        .filter((r) => tier.has(r.out![0]))\n        .map((r) => [r.id, r.name, r.cycle, r.out![0], Number(r.out![1].quantity), r.ins])\n        .sort((a, b) => (a[0] as number) - (b[0] as number));\n    const planets: Record<number, [string, number[]]> = {};\n    const pins: Record<number, [string, string, number]> = {};\n    for (const [id, t] of types) {\n        const kind = PI_PIN_KINDS[t.groupID];\n        if (!kind) continue;\n        pins[id] = [en(t.name), kind, Number(t.capacity ?? 0)];\n        if (kind !== 'ext') continue;\n        const planet = attr(id, EXTRACTOR_PLANET);\n        const raw = attr(id, HARVESTED_TYPE);\n        if (!planet || !raw || !tier.has(raw)) continue;\n        const name = en(types.get(planet)?.name).replace(/^Planet \\((.*)\\)$/, '$1');\n        const entry = planets[planet] ?? (planets[planet] = [name, []]);\n        if (!entry[1].includes(raw)) entry[1].push(raw);\n    }\n    const counts = [0, 1, 2, 3, 4].map((n) => [...tier.values()].filter((x) => x === n).length);\n    if (counts[0] < 10 || counts[4] < 5 || Object.keys(planets).length < 8) throw new Error(`Datele PI din SDE par incomplete: ${counts.join('/')}`);\n    return { generated: new Date().toISOString(), source: 'sde', types: outTypes, schematics: outSchematics, planets, pins };\n}\n"
EN=open('data/_en-pi.txt').read()
log=[]
def edit(p, pairs):
    s=open(p).read()
    for old,new,guard in pairs:
        if guard and guard in s: log.append(p+': already '+guard[:40]); continue
        if old not in s: log.append(p+': MISSING anchor '+old[:60]); continue
        s=s.replace(old,new,1)
    open(p,'w').write(s)
edit('src/main.ts',[
 ("import { createSkinsView } from './views/skins';","import { createSkinsView } from './views/skins';\nimport { createPiView } from './views/pi';","createPiView } from"),
 ("  { id: 'skins', label: tx('SKIN-uri'), icon: 'skin', categories: null, lore: 'Raiment', clade: 'Svarog', order: 7 },\n","  { id: 'skins', label: tx('SKIN-uri'), icon: 'skin', categories: null, lore: 'Raiment', clade: 'Svarog', order: 7 },\n  { id: 'pi', label: 'Planetary Interaction', icon: 'planet', categories: null, lore: 'Rootweave', clade: 'Veles', order: 4 },\n","id: 'pi'"),
])
import re
s=open('src/main.ts').read()
s=re.sub(r"type ViewId = ([^;]*);", lambda m: m.group(0) if "'pi'" in m.group(1) else "type ViewId = %s | 'pi';" % m.group(1), s, count=1)
s=re.sub(r"const SIDE_VIEWS = \[([^\]]*)\] as const;", lambda m: m.group(0) if "'pi'" in m.group(1) else "const SIDE_VIEWS = [%s, 'pi'] as const;" % m.group(1), s, count=1)
s=re.sub(r"for \(const id of \[('fitting'[^\]]*)\] as const\)", lambda m: m.group(0) if "'pi'" in m.group(1) else "for (const id of [%s, 'pi'] as const)" % m.group(1), s)
if "mount(['pi']" not in s:
    i=s.index("  intel.setContext(ctx);")
    s=s[:i]+"  mount(['pi'], () => createPiView(viewEl('pi'), sidePane('pi')));\n"+s[i:]
open('src/main.ts','w').write(s)
s=open('src/character/sso.ts').read()
if 'esi-planets.manage_planets.v1' not in s:
    i=s.index('];', s.index('export const SCOPES'))
    s=s[:i]+"  'esi-planets.manage_planets.v1',\n"+s[i:]
    open('src/character/sso.ts','w').write(s)
edit('src/ui/icons.ts',[("  chevron: '<path d=\"m9 6 6 6-6 6\"/>',","  chevron: '<path d=\"m9 6 6 6-6 6\"/>',\n  planet: '<circle cx=\"12\" cy=\"12\" r=\"6.5\"/><path d=\"M3.2 15.5c-1.4 2 .2 3 3.6 2.4 3.6-.6 8.4-2.9 11.6-5.6 3-2.6 3.2-4.7.4-4.9\"/>',","  planet:")])
edit('src/style.css',[("@import './styles/roster.css';","@import './styles/roster.css';\n@import './styles/pi.css';","pi.css")])
s=open('src/data/manifest.ts').read()
s=re.sub(r"export type DataName = ([^;]*);", lambda m: m.group(0) if "'pi'" in m.group(1) else "export type DataName = %s | 'pi';" % m.group(1), s, count=1)
open('src/data/manifest.ts','w').write(s)
s=open('scripts/publish-data.ts').read()
s=re.sub(r"const NAMES = \[([^\]]*)\];", lambda m: m.group(0) if "'pi'" in m.group(1) else "const NAMES = [%s, 'pi'];" % m.group(1), s, count=1)
open('scripts/publish-data.ts','w').write(s)
p='scripts/skin-data.ts'; s=open(p).read()
if 'buildPi' not in s:
    s=s.replace("const MAP_OUT = path.join(RAW_DIR, 'map.json');","const MAP_OUT = path.join(RAW_DIR, 'map.json');\nconst PI_OUT = path.join(RAW_DIR, 'pi.json');",1)
    s=re.sub(r"const FILES = \[([^\]]*)\];", lambda m: "const FILES = [%s];" % (m.group(1)+''.join(", '%s'" % f for f in ['planetSchematics','typeDogma'] if "'%s'" % f not in m.group(1))), s, count=1)
    s=s.replace("\nexport async function generateSkins() {", BLOCK+"\nexport async function generateSkins() {",1)
    s=s.replace("        fs.writeFileSync(MAP_OUT, JSON.stringify(buildMap(dir)));","        fs.writeFileSync(MAP_OUT, JSON.stringify(buildMap(dir)));\n        fs.writeFileSync(PI_OUT, JSON.stringify(buildPi(dir)));",1)
    s=s.replace("data/masteries.json, data/map.json`))","data/masteries.json, data/map.json, data/pi.json`))",1)
    open(p,'w').write(s)
p='src/i18n/en.ts'; s=open(p).read()
add=[]
for line in EN.strip('\n').split('\n'):
    key=line.strip().split('": "')[0]+'":'
    if key in s: log.append('en dup skip '+key[:50])
    else: add.append(line)
if add:
    i=s.rstrip().rfind('};'); s=s[:i]+'\n'.join(add)+'\n'+s[i:]; open(p,'w').write(s)
m=json.load(open('public/data/manifest.json')); m['pi']='pi.c5cd8a9c71.json'
open('public/data/manifest.json','w').write(json.dumps(m,separators=(',',':')))
print('\n'.join(log) or 'clean')
